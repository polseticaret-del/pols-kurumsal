<?php
/**
 * Theme UI strings (not content). Content lives in block attributes and is
 * translated per page by Polylang; these are the few labels the templates
 * print themselves. Kept as a dictionary so both languages ship together.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function pols_lang() {
	if ( function_exists( 'pll_current_language' ) ) {
		$l = pll_current_language( 'slug' );
		if ( $l ) {
			return $l;
		}
	}
	return 0 === strpos( get_locale(), 'en' ) ? 'en' : 'tr';
}

function pols_t( $key ) {
	static $dict = array(
		'tr' => array(
			'skip'           => 'İçeriğe geç',
			'home'           => "Pol's, ana sayfa",
			'main_menu'      => 'Ana menü',
			'mobile_menu'    => 'Mobil menü',
			'menu_open'      => 'Menüyü aç',
			'menu_close'     => 'Menüyü kapat',
			'menu'           => 'Menü',
			'lang'           => 'Dil seçimi',
			'copied'         => 'E-posta adresi kopyalandı.',
			'pdf_soon_toast' => 'Katalog PDF dosyası yüklendiğinde buradan inecek.',
			'pdf_soon'       => 'PDF yakında',
			'pdf_download'   => 'PDF indir',
			'marquee_pause'  => 'Şeridi durdur',
			'marquee_play'   => 'Şeridi oynat',
			'cert_logos'     => 'Sertifika ve üyelik logoları',
			'badges'         => "Pol's rakamlarla",
			'episodes'       => 'Belgesel bölümleri',
			'legal'          => 'Yasal',
			'motto_plain'    => 'İyi gıda herkesin hakkı',
		),
		'en' => array(
			'skip'           => 'Skip to content',
			'home'           => "Pol's, home",
			'main_menu'      => 'Main menu',
			'mobile_menu'    => 'Mobile menu',
			'menu_open'      => 'Open menu',
			'menu_close'     => 'Close menu',
			'menu'           => 'Menu',
			'lang'           => 'Language',
			'copied'         => 'Email address copied.',
			'pdf_soon_toast' => 'The catalogue PDF will be available here shortly.',
			'pdf_soon'       => 'PDF coming soon',
			'pdf_download'   => 'Download PDF',
			'marquee_pause'  => 'Pause strip',
			'marquee_play'   => 'Play strip',
			'cert_logos'     => 'Certificate and membership logos',
			'badges'         => "Pol's in numbers",
			'episodes'       => 'Documentary episodes',
			'legal'          => 'Legal',
			'motto_plain'    => 'Good food is everyone’s right',
		),
	);
	$lang = pols_lang();
	$set  = isset( $dict[ $lang ] ) ? $dict[ $lang ] : $dict['tr'];
	return isset( $set[ $key ] ) ? $set[ $key ] : $key;
}

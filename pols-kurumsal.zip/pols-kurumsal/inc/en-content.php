<?php
/**
 * English page copy (corporate register). Used by "Pol's Kurulum" to build
 * the EN front page; afterwards the page is edited in the block editor like
 * the Turkish one. British spelling. Documentary titles stay Turkish: the
 * films are in Turkish.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function pols_en_content() {
	return array(
		'hero' => array(
			'anchor'   => 'home',
			'titleA'   => 'Adding value to',
			'titleB'   => 'the land we come from.',
			'motto'    => '“Goodness at its core.”',
			'mottoSub' => 'Ermenek, since 2017',
		),

		'about' => array(
			'anchor'  => 'about',
			'heading' => 'Goodness at its core.',
			'intro'   => "Guided by this belief, and by our aim to add value to the land we come from, Pol’s began its journey in 2017 in Ermenek, Karaman.\n\nBy closely following the changing dynamics of production in food and agriculture, emerging technologies and evolving consumer expectations, we aim to bring natural, reliable, high-quality and sustainable food to more people.\n\nFor us, Pol’s is more than a food brand: it is an approach to production that brings women’s employment, sustainability, the land, our growers and technology together in a single value chain.",
			'badges'  => array(
				array( 'big' => '2017', 'label' => 'founded in Ermenek' ),
				array( 'big' => '85%', 'label' => 'of our workforce are women' ),
				array( 'big' => '1,000+', 'label' => 'contract growers' ),
				array( 'big' => '30+', 'label' => 'export markets' ),
			),
		),

		'values' => array(
			'anchor' => 'values',
			'label'  => 'Our values',
			'items'  => array(
				array( 'title' => 'Women’s employment', 'sub' => '85% of our workforce are women!',
					'text' => "At Pol’s, we believe that a strong and sustainable working culture is built on diverse perspectives and strong teams.\n\nWomen make up 85% of the workforce at our factory, the foundation of our production capacity. We see supporting women’s presence in working life, and the value they bring to production, not only as part of our employment policy but as an essential part of our corporate culture.\n\nThe knowledge, experience and dedication of our women employees add value to Pol’s success, from our production processes to our approach to quality. Through a working environment that helps women take a stronger place in economic life, we continue to advance equal opportunity and an inclusive workplace culture.",
					'close' => 'At Pol’s, we are building our present through the work of women, and growing our future together.',
					'image' => 0, 'imageFile' => '16-kadin.webp', 'alt' => 'Women employees arranging freeze-dried strawberry slices on trays at the Pol’s facility' ),
				array( 'title' => 'Adding value to regional development', 'sub' => 'Drawing strength from Ermenek, growing together with the region!',
					'text' => "With our production facility in Ermenek, Karaman, we are committed to contributing to the economic and social development of the region in which we operate. For us, sustainable growth means more than increasing production capacity: it means creating lasting value for the region, our employees, our growers and society.\n\nWe see our production in Ermenek as an important part of regional development, and through the jobs and economic activity we create, we aim to strengthen the region’s productive capacity.\n\nWe value partnerships that support Ermenek’s local production and aim to help the region’s economic potential develop sustainably.",
					'close' => 'We produce, create jobs, build partnerships and grow together.',
					'image' => 0, 'imageFile' => '', 'alt' => '' ),
				array( 'title' => 'Contract farming', 'sub' => 'Turning effort into value, and production into a future!',
					'text' => "At Pol’s, we believe that sustainable production is built on strong, trust-based partnerships. Through our contract farming model, we build long-term relationships with our growers founded on mutual value, working together at every stage from production planning to maintaining quality standards. This approach allows us to support our growers’ effort and experience while building a reliable and sustainable production structure to Pol’s high quality standards.\n\nWith the aim of carrying local production strength into the future, we bring our growers’ knowledge and experience together with modern agricultural practices and our quality-led approach. With a sense of responsibility towards the land, our growers and the value of production, we aim to develop a sustainable, traceable and high-standard agricultural ecosystem, today and in the future.",
					'close' => '', 'image' => 0, 'imageFile' => '', 'alt' => '' ),
			),
		),

		'field-intro' => array(
			'anchor' => 'contract-farming',
			'text'   => 'Our training gardens.',
			'sub'    => 'Bringing knowledge to the land, growing the future together.',
			'body'   => 'Through the Pol’s Training Gardens, we aim to develop the knowledge and experience of local farmers and growers and to promote sustainable farming practices. We run hands-on training and information sessions across every stage of agricultural production, from cultivating and protecting the soil and efficient growing methods to harvesting and improving product quality. By introducing our growers to up-to-date farming practices, we help build a farming culture that preserves soil fertility, uses resources efficiently and carries value to future generations.',
		),

		'journey' => array(
			'anchor'  => 'journey',
			'heading' => 'Trust, from field to table!',
			'intro'   => 'Since day one, our Contract Farming model has safeguarded the quality of everything we produce. Follow the journey of our fruit.',
			'stops'   => array(
				array( 'title' => 'Agreement', 'text' => 'Production that begins with trust', 'image' => 0, 'imageFile' => '11-anlasma.webp', 'alt' => 'Two growers shaking hands at the edge of a strawberry field' ),
				array( 'title' => 'Training', 'text' => 'A future shaped by knowledge', 'image' => 0, 'imageFile' => '12-egitim.webp', 'alt' => 'Hands examining the soil between rows of strawberry plants' ),
				array( 'title' => 'Harvest', 'text' => 'Where effort meets the land', 'image' => 0, 'imageFile' => '13-hasat.webp', 'alt' => 'Women harvesting strawberries in the field' ),
				array( 'title' => 'Production', 'text' => 'Adding value from production to the future', 'image' => 0, 'imageFile' => '14-uretim.webp', 'alt' => 'Gloved hands sorting strawberries on the production line' ),
				array( 'title' => 'Table', 'text' => 'From the land to your table, with confidence', 'image' => 0, 'imageFile' => '15-sofra.webp', 'alt' => 'Freeze-dried fruit, jam and halva on a wooden table' ),
			),
			'note'       => 'Five stages, one commitment:',
			'noteAccent' => 'quality is never left to chance.',
		),

		'scrub' => array(
			'anchor'  => 'sustainability',
			'eyebrow' => 'Carbon footprint',
			'heading' => 'Measuring the footprint we leave.',
			'text'    => 'We measure our environmental impact through carbon footprint calculations and contribute to the green transition. By embedding environmental responsibility in our approach to sustainability, we are taking decisive steps towards a more liveable future.',
		),

		'freeze-dry' => array(
			'anchor'        => 'freeze-dry',
			'eyebrow'       => 'Freeze Dry',
			'heading'       => 'All of the fruit.',
			'headingAccent' => 'None of the water.',
			'steps'         => array(
				array( 'title' => 'Harvest', 'text' => 'Picked at peak ripeness from our contract orchards.', 'image' => 0, 'imageFile' => '21-fd-hasat.webp', 'alt' => 'Women picking strawberries in the field' ),
				array( 'title' => 'Washing and sorting', 'text' => 'Washed at our Ermenek facility and hand-sorted by our team.', 'image' => 0, 'imageFile' => '22-fd-yikama.webp', 'alt' => 'Strawberries passing under water on the washing line' ),
				array( 'title' => 'Individual quick freezing (IQF)', 'text' => 'Each piece is frozen rapidly and individually, preserving its texture and shape.', 'image' => 0, 'imageFile' => '23-fd-iqf.webp', 'alt' => 'Individually quick-frozen, frosted strawberries' ),
				array( 'title' => 'Vacuum drying', 'text' => 'Arranged on trays and dried under vacuum, the ice turns directly into vapour without ever becoming liquid.', 'image' => 0, 'imageFile' => '24-fd-kurutma.webp', 'alt' => 'Trays of frozen strawberries being loaded into a freeze dryer' ),
				array( 'title' => 'Packing', 'text' => 'Sealed in moisture-proof packaging, with no added sugar and no additives.', 'image' => 0, 'imageFile' => '25-fd-paket.webp', 'alt' => 'Freeze-dried strawberry slices being packed into Pol’s Freeze Fresh pouches' ),
			),
			'meterLabel'    => 'Water content',
			'note'          => 'Fresh strawberries are around 91% water. After freeze-drying only 1–4% moisture remains, while colour, aroma and shape are retained.',
		),

		'facts' => array(
			'anchor' => 'freeze-dry-facts',
			'items'  => array(
				array( 'big' => '97%', 'label' => 'of the fruit’s natural qualities retained' ),
				array( 'big' => '4,000 m²', 'label' => 'enclosed production facility in Ermenek' ),
				array( 'big' => 'Additive-free', 'label' => 'no added sugar, simply fruit' ),
			),
			'line'   => 'We are one of the few production facilities in Türkiye using freeze-drying technology.',
		),

		'certificates' => array(
			'anchor'     => 'certificates',
			'heading'    => 'Certified to international standards.',
			'countLabel' => 'certifications and memberships',
		),

		'catalogs' => array(
			'anchor'  => 'products',
			'heading' => 'Our catalogues',
			'intro'   => 'Up-to-date catalogues, prepared separately for industrial partners and retail.',
		),

		'media' => array(
			'anchor'    => 'media',
			'heading'   => 'News and media',
			'filmLabel' => 'Watch our brand film on YouTube',
			'feedMore'  => 'See all',
			'episodes'  => array(
				array( 'title' => 'Bağ Bahçe Burada, Bağımız da Burayla!', 'meta' => 'Hasat Zamanı documentary (in Turkish) · 10:19', 'url' => 'https://www.youtube.com/watch?v=-ZtSJUWMtfs' ),
				array( 'title' => 'Yatırımlarımız Meyvesini Veriyor', 'meta' => 'Hasat Zamanı documentary (in Turkish) · 9:27', 'url' => 'https://www.youtube.com/watch?v=3YKnyp4ryXc' ),
				array( 'title' => 'Burası Kadınların!', 'meta' => 'Hasat Zamanı documentary (in Turkish) · 9:16', 'url' => 'https://www.youtube.com/watch?v=uuTnbJ-FTIs' ),
				array( 'title' => 'Miras; Geleceğe Bıraktığımız Değer', 'meta' => 'Hasat Zamanı documentary (in Turkish) · 8:34', 'url' => 'https://www.youtube.com/watch?v=lDpNwANNYyU' ),
			),
		),

		'contact' => array(
			'anchor'    => 'contact',
			'heading'   => 'We’d love to hear from you.',
			'copyLabel' => 'Copy',
			'locations' => array(
				array( 'title' => 'Head Office', 'address' => "Kızılırmak Mah., 1446. Cad., No:12/19\n06530 Çankaya, Ankara, Türkiye", 'phone' => '+90 312 287 76 57', 'map' => 'https://www.google.com/maps/search/?api=1&query=K%C4%B1z%C4%B1l%C4%B1rmak+Mah+1446+Cad+No+12+%C3%87ankaya+Ankara', 'mapLabel' => 'Get directions ↗' ),
				array( 'title' => 'Istanbul Office', 'address' => "Hamidiye Mah., Cendere Cad., No:21\nSeba Central, Block A, Floor 6, No:24\n34408 Kağıthane, Istanbul, Türkiye", 'phone' => '', 'map' => 'https://www.google.com/maps/search/?api=1&query=Seba+Central+Cendere+Cad+21+K%C3%A2%C4%9F%C4%B1thane', 'mapLabel' => 'Get directions ↗' ),
				array( 'title' => 'Production Facility', 'address' => "Seyran Mah. Yağlısu Mevkii Küme Evler\nNo: 3-4, 70400 Ermenek, Karaman, Türkiye", 'phone' => '+90 850 216 76 57', 'map' => 'https://www.google.com/maps/search/?api=1&query=Seyran+Mah+Ya%C4%9Fl%C4%B1su+Mevkii+Ermenek+Karaman', 'mapLabel' => 'Get directions ↗' ),
			),
			'copyright' => '© 2026 Pol’s Gıda · Goodness at its core.',
			'legal'     => array(
				array( 'label' => 'Personal Data Protection (KVKK)', 'url' => '#' ),
				array( 'label' => 'Privacy Policy', 'url' => '#' ),
				array( 'label' => 'Cookie Preferences', 'url' => '#' ),
				array( 'label' => 'Back to top ↑', 'url' => '#top' ),
			),
		),
	);
}

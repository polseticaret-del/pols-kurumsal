<?php
/**
 * English page copy (corporate register). Used by "Pol's Kurulum" to build
 * the EN front page; afterwards the page is edited in the block editor like
 * the Turkish one. British spelling. Documentary titles stay Turkish: the
 * films are in Turkish.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function pols_en_content() {
	return array(
		'hero' => array(
			'anchor'   => 'home',
			'titleA'   => 'Adding value to',
			'titleB'   => 'the land we come from.',
			'motto'    => '“Good food is everyone’s right.”',
			'mottoSub' => 'Ermenek, since 2017',
		),

		'about' => array(
			'anchor'        => 'about',
			'heading'       => 'Good food is everyone’s right.',
			'badges'        => array(
				array( 'big' => '2017', 'label' => 'founded in Ermenek' ),
				array( 'big' => '80%', 'label' => 'of our workforce are women' ),
				array( 'big' => '1,000+', 'label' => 'contract growers' ),
				array( 'big' => '28', 'label' => 'export markets' ),
				array( 'big' => 'Guaranteed purchase', 'label' => 'for every contract grower' ),
			),
		),

		'values' => array(
			'anchor' => 'values',
			'label'  => 'Our values',
			'items'  => array(
				array( 'title' => 'Women’s employment', 'text' => 'Women make up 80% of our team. The inspiration we draw from this land is shaped by their hands.' ),
				array( 'title' => 'Regional development', 'text' => 'Through regular agronomic training and controlled farming practices, we strengthen local employment and sustain the productivity of the land.' ),
				array( 'title' => 'Contract farming', 'text' => 'Annual agreements with our growers ensure that quality is never left to chance, from field to table.' ),
			),
		),

		'field-intro' => array(
			'anchor' => 'contract-farming',
			'text'   => 'Our training gardens.',
		),

		'journey' => array(
			'anchor'  => 'journey',
			'heading' => 'Trust, from field to table.',
			'intro'   => 'Since day one, our Contract Farming model has safeguarded the quality of everything we produce. Follow the journey of our fruit.',
			'stops'   => array(
				array( 'title' => 'Agreement', 'text' => 'Before planting, we sign an annual agreement with each grower that guarantees the purchase of the harvest, ruling out unplanned production from the outset.', 'image' => 0, 'imageFile' => '11-anlasma.webp', 'alt' => 'Two growers shaking hands at the edge of a strawberry field' ),
				array( 'title' => 'Guidance', 'text' => 'Our agronomists work alongside growers from planting to harvest, applying responsible fertilisation and crop-protection practices that protect soil and water.', 'image' => 0, 'imageFile' => '12-egitim.webp', 'alt' => 'Hands examining the soil between rows of strawberry plants' ),
				array( 'title' => 'Harvest', 'text' => 'Our growers’ work is protected, and raw material reaches our facility to international standards.', 'image' => 0, 'imageFile' => '13-hasat.webp', 'alt' => 'Women harvesting strawberries in the field' ),
				array( 'title' => 'Production', 'text' => 'At our Ermenek facility, a workforce that is 80% women produces within a sustainable model that benefits the local community.', 'image' => 0, 'imageFile' => '14-uretim.webp', 'alt' => 'Gloved hands sorting strawberries on the production line' ),
				array( 'title' => 'Table', 'text' => 'From shelf to table: natural, reliable and ready to enjoy. This is where the journey ends.', 'image' => 0, 'imageFile' => '15-sofra.webp', 'alt' => 'Freeze-dried fruit, jam and halva on a wooden table' ),
			),
			'note'       => 'Five stages, one commitment:',
			'noteAccent' => 'quality is never left to chance.',
		),

		'scrub' => array(
			'anchor'  => 'sustainability',
			'heading' => 'Measuring the footprint we leave.',
			'text'    => 'We calculate our corporate carbon footprint and, together with our contract growers, apply responsible fertilisation and crop-protection practices to safeguard our soil and water resources.',
		),

		'freeze-dry' => array(
			'anchor'        => 'freeze-dry',
			'eyebrow'       => 'Freeze Dry',
			'heading'       => 'All of the fruit.',
			'headingAccent' => 'None of the water.',
			'steps'         => array(
				array( 'title' => 'Harvest', 'text' => 'Picked at peak ripeness from our contract orchards.', 'image' => 0, 'imageFile' => '21-fd-hasat.webp', 'alt' => 'Women picking strawberries in the field' ),
				array( 'title' => 'Washing and sorting', 'text' => 'Washed at our Ermenek facility and hand-sorted by our team.', 'image' => 0, 'imageFile' => '22-fd-yikama.webp', 'alt' => 'Strawberries passing under water on the washing line' ),
				array( 'title' => 'Individual quick freezing (IQF)', 'text' => 'Each piece is frozen rapidly and individually, preserving its texture and shape.', 'image' => 0, 'imageFile' => '23-fd-iqf.webp', 'alt' => 'Individually quick-frozen, frosted strawberries' ),
				array( 'title' => 'Vacuum drying', 'text' => 'Arranged on trays and dried under vacuum, the ice turns directly into vapour without ever becoming liquid.', 'image' => 0, 'imageFile' => '24-fd-kurutma.webp', 'alt' => 'Trays of frozen strawberries being loaded into a freeze dryer' ),
				array( 'title' => 'Packing', 'text' => 'Sealed in moisture-proof packaging, with no added sugar and no additives.', 'image' => 0, 'imageFile' => '25-fd-paket.webp', 'alt' => 'Freeze-dried strawberry slices being packed into Pol’s Freeze Fresh pouches' ),
			),
			'meterLabel'    => 'Water content',
			'note'          => 'Fresh strawberries are around 91% water. After freeze-drying only 1–4% moisture remains, while colour, aroma and shape are retained.',
		),

		'facts' => array(
			'anchor' => 'freeze-dry-facts',
			'items'  => array(
				array( 'big' => '97%', 'label' => 'of the fruit’s natural qualities retained' ),
				array( 'big' => '4,000 m²', 'label' => 'enclosed production facility in Ermenek' ),
				array( 'big' => 'Additive-free', 'label' => 'no added sugar, simply fruit' ),
			),
			'line'   => 'We are one of the few production facilities in Türkiye using freeze-drying technology.',
		),

		'certificates' => array(
			'anchor'     => 'certificates',
			'heading'    => 'Certified to international standards.',
			'countLabel' => 'certifications and memberships',
		),

		'catalogs' => array(
			'anchor'  => 'products',
			'heading' => 'Our catalogues',
			'intro'   => 'Up-to-date catalogues, prepared separately for industrial partners and retail.',
		),

		'media' => array(
			'anchor'    => 'media',
			'heading'   => 'News and media',
			'filmLabel' => 'Watch our brand film on YouTube',
			'feedMore'  => 'See all',
			'episodes'  => array(
				array( 'title' => 'Bağ Bahçe Burada, Bağımız da Burayla!', 'meta' => 'Hasat Zamanı documentary (in Turkish) · 10:19', 'url' => 'https://www.youtube.com/watch?v=-ZtSJUWMtfs' ),
				array( 'title' => 'Yatırımlarımız Meyvesini Veriyor', 'meta' => 'Hasat Zamanı documentary (in Turkish) · 9:27', 'url' => 'https://www.youtube.com/watch?v=3YKnyp4ryXc' ),
				array( 'title' => 'Burası Kadınların!', 'meta' => 'Hasat Zamanı documentary (in Turkish) · 9:16', 'url' => 'https://www.youtube.com/watch?v=uuTnbJ-FTIs' ),
				array( 'title' => 'Miras; Geleceğe Bıraktığımız Değer', 'meta' => 'Hasat Zamanı documentary (in Turkish) · 8:34', 'url' => 'https://www.youtube.com/watch?v=lDpNwANNYyU' ),
			),
		),

		'contact' => array(
			'anchor'    => 'contact',
			'heading'   => 'We’d love to hear from you.',
			'copyLabel' => 'Copy',
			'locations' => array(
				array( 'title' => 'Head Office', 'address' => "Kızılırmak Mah., 1446. Cad., No:12/19\nÇankaya, Ankara, Türkiye", 'phone' => '+90 312 287 76 57', 'map' => 'https://www.google.com/maps/search/?api=1&query=K%C4%B1z%C4%B1l%C4%B1rmak+Mah+1446+Cad+No+12+%C3%87ankaya+Ankara', 'mapLabel' => 'Get directions ↗' ),
				array( 'title' => 'Istanbul Office', 'address' => "Hamidiye Mah., Cendere Cad., No:21\nSeba Central, Block A, Floor 6, No:24\nKağıthane, Istanbul, Türkiye", 'phone' => '', 'map' => 'https://www.google.com/maps/search/?api=1&query=Seba+Central+Cendere+Cad+21+K%C3%A2%C4%9F%C4%B1thane', 'mapLabel' => 'Get directions ↗' ),
				array( 'title' => 'Production Facility', 'address' => "Seyran Mah. Yağlısu Mevkii Küme Evler\nNo: 3-4, 70400 Ermenek, Karaman, Türkiye", 'phone' => '+90 850 216 76 57', 'map' => 'https://www.google.com/maps/search/?api=1&query=Seyran+Mah+Ya%C4%9Fl%C4%B1su+Mevkii+Ermenek+Karaman', 'mapLabel' => 'Get directions ↗' ),
			),
			'copyright' => '© 2026 Pol’s Gıda · Good food is everyone’s right.',
			'legal'     => array(
				array( 'label' => 'Personal Data Protection (KVKK)', 'url' => '#' ),
				array( 'label' => 'Privacy Policy', 'url' => '#' ),
				array( 'label' => 'Cookie Preferences', 'url' => '#' ),
				array( 'label' => 'Back to top ↑', 'url' => '#top' ),
			),
		),
	);
}

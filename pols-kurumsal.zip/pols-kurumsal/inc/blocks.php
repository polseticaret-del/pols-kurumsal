<?php
/**
 * Registers every section block from inc/schema.php, plus the header.
 * All blocks are dynamic (save = null); markup comes from inc/render.php, so
 * the scroll-craft data-sc-* attributes stay in code and editors only touch
 * content.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'block_categories_all', function ( $cats ) {
	array_unshift( $cats, array( 'slug' => 'pols', 'title' => "Pol's bölümleri", 'icon' => null ) );
	return $cats;
} );

add_action( 'init', function () {
	wp_register_script(
		'pols-editor',
		POLS_URI . '/assets/js/editor.js',
		array( 'wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-server-side-render', 'wp-data', 'wp-i18n' ),
		POLS_VERSION,
		true
	);

	$ui = array();
	foreach ( pols_schema() as $slug => $def ) {
		$ui[ 'pols/' . $slug ] = array(
			'title'  => $def['title'],
			'icon'   => $def['icon'],
			'fields' => $def['fields'],
		);
		register_block_type( 'pols/' . $slug, array(
			'api_version'     => 3,
			'title'           => $def['title'],
			'description'     => $def['description'],
			'category'        => 'pols',
			'icon'            => $def['icon'],
			'attributes'      => pols_block_attributes( $slug ),
			// The section id is our own "anchor" attribute (schema), edited in the
			// sidebar; core anchor support would add a second, conflicting field.
			'supports'        => array( 'anchor' => false, 'html' => false, 'customClassName' => false ),
			'editor_script'   => 'pols-editor',
			'render_callback' => function ( $attrs ) use ( $slug ) {
				$attrs = wp_parse_args( $attrs, pols_block_defaults( $slug ) );
				$fn    = 'pols_render_' . str_replace( '-', '_', $slug );
				return function_exists( $fn ) ? $fn( $attrs ) : '';
			},
		) );
	}

	register_block_type( 'pols/header', array(
		'api_version'     => 3,
		'title'           => "Pol's · Üst menü",
		'description'     => 'Logo, menü (Görünüm → Menüler → "Ana menü"), dil seçimi ve mobil menü.',
		'category'        => 'pols',
		'icon'            => 'menu',
		'attributes'      => array(),
		'supports'        => array( 'html' => false, 'multiple' => false ),
		'editor_script'   => 'pols-editor',
		'render_callback' => 'pols_render_header',
	) );
	$ui['pols/header'] = array( 'title' => "Pol's · Üst menü", 'icon' => 'menu', 'fields' => array() );

	wp_localize_script( 'pols-editor', 'POLS_BLOCKS', array(
		'blocks'  => $ui,
		'seedUrl' => POLS_URI . '/seed/media/',
	) );
} );

<?php
/**
 * Block schema: the single source for every section block.
 *
 *   title / icon / description   inserter metadata
 *   fields                       editor sidebar controls (rendered by editor.js)
 *   defaults                     attribute defaults = the approved TR copy
 *
 * Media fields store an attachment ID; a sibling "<key>File" string names the
 * bundled fallback in /seed/media, so a block renders correctly before (or
 * without) the media import. Repeater items carry the same pair.
 *
 * Field types: text, textarea, url, media (image|video), toggle, select,
 * repeater (fields, itemLabel).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function pols_schema() {
	static $s = null;
	if ( null !== $s ) {
		return $s;
	}

	$fruit_options = array();
	foreach ( pols_fruits() as $k => $f ) {
		$fruit_options[] = array( 'value' => $k, 'label' => $f['label'] );
	}

	$badge_colors = array(
		array( 'value' => 'orange-btn', 'label' => 'Turuncu (koyu)' ),
		array( 'value' => 'orange', 'label' => 'Turuncu' ),
		array( 'value' => 'forest', 'label' => 'Orman yeşili' ),
		array( 'value' => 'green-mid', 'label' => 'Yeşil' ),
		array( 'value' => 'peach', 'label' => 'Şeftali' ),
		array( 'value' => 'berry', 'label' => 'Vişne' ),
	);

	$s = array(

		'hero' => array(
			'title'       => 'Pol\'s · Giriş',
			'icon'        => 'cover-image',
			'description' => 'Kaydırdıkça oynayan video, başlık ve motto.',
			'fields'      => array(
				array( 'key' => 'titleA', 'type' => 'text', 'label' => 'Başlık (1. kısım)' ),
				array( 'key' => 'titleB', 'type' => 'text', 'label' => 'Başlık (turuncu kısım)' ),
				array( 'key' => 'motto', 'type' => 'text', 'label' => 'Motto' ),
				array( 'key' => 'mottoSub', 'type' => 'text', 'label' => 'Motto alt satırı' ),
				array( 'key' => 'imageOnly', 'type' => 'toggle', 'label' => 'Video kullanma, sadece görsel göster' ),
				array( 'key' => 'video', 'type' => 'media', 'media' => 'video', 'label' => 'Video (masaüstü, mp4)' ),
				array( 'key' => 'videoMobile', 'type' => 'media', 'media' => 'video', 'label' => 'Video (mobil, dikey mp4)' ),
				array( 'key' => 'poster', 'type' => 'media', 'media' => 'image', 'label' => 'Poster (videonun ilk karesi)' ),
				array( 'key' => 'posterMobile', 'type' => 'media', 'media' => 'image', 'label' => 'Poster (mobil)' ),
				array( 'key' => 'plate', 'type' => 'media', 'media' => 'image', 'label' => 'Bulanık zemin: videonun SON karesi (masaüstü)' ),
				array( 'key' => 'plateMobile', 'type' => 'media', 'media' => 'image', 'label' => 'Bulanık zemin: videonun SON karesi (mobil)' ),
			),
			'defaults'    => array(
				'anchor' => 'giris',
				'plate' => 0, 'plateFile' => '01-hero-end.webp',
				'plateMobile' => 0, 'plateMobileFile' => '01-hero-m-end.webp',
				'titleA' => 'Doğduğumuz topraklara',
				'titleB' => 'değer katıyoruz.',
				'motto' => '“İyi gıda herkesin hakkı.”',
				'mottoSub' => 'Ermenek, 2017\'den beri',
				'imageOnly' => false,
				'video' => 0, 'videoFile' => '01-hero.mp4',
				'videoMobile' => 0, 'videoMobileFile' => '01-hero-m.mp4',
				'poster' => 0, 'posterFile' => '01-hero.webp',
				'posterMobile' => 0, 'posterMobileFile' => '01-hero-m.webp',
			),
		),

		// Slogan + figures on the frosted lake (user direction 2026-09-28: no
		// paragraphs, no fruits, no icons).
		'about' => array(
			'title'       => 'Pol\'s · Hakkımızda (slogan + rakamlar)',
			'icon'        => 'id',
			'description' => 'Tek satır slogan ve altında rakamlar; bulanık göl zemini üzerinde.',
			'fields'      => array(
				array( 'key' => 'heading', 'type' => 'text', 'label' => 'Slogan' ),
				array( 'key' => 'badges', 'type' => 'repeater', 'label' => 'Rakamlar', 'itemLabel' => 'big', 'fields' => array(
					array( 'key' => 'big', 'type' => 'text', 'label' => 'Büyük yazı (ör. 2017, %80, 1.000+)' ),
					array( 'key' => 'label', 'type' => 'text', 'label' => 'Alt yazı' ),
				) ),
			),
			'defaults'    => array(
				'anchor' => 'hakkimizda',
				'heading' => 'İyi gıda herkesin hakkı.',
				'badges' => array(
					array( 'big' => '2017', 'label' => 'Ermenek\'te kuruluş' ),
					array( 'big' => '%80', 'label' => 'kadın çalışan' ),
					array( 'big' => '1.000+', 'label' => 'sözleşmeli çiftçi' ),
					array( 'big' => '28', 'label' => 'ülkeye ihracat' ),
					array( 'big' => 'Alım garantisi', 'label' => 'her sözleşmeli çiftçimize' ),
				),
			),
		),

		'values' => array(
			'title'       => 'Pol\'s · Değerlerimiz',
			'icon'        => 'heart',
			'description' => 'Ekran sabitlenir, değerler sırayla geçer.',
			'fields'      => array(
				array( 'key' => 'label', 'type' => 'text', 'label' => 'Üst etiket' ),
				array( 'key' => 'items', 'type' => 'repeater', 'label' => 'Değerler', 'itemLabel' => 'title', 'fields' => array(
					array( 'key' => 'title', 'type' => 'text', 'label' => 'Başlık' ),
					array( 'key' => 'text', 'type' => 'textarea', 'label' => 'Metin' ),
				) ),
			),
			'defaults'    => array(
				'anchor' => 'degerler',
				'label' => 'Değerlerimiz',
				'items' => array(
					array( 'title' => 'Kadın emeği', 'text' => 'Ekibimizin %80\'i kadın. Bu topraklardan aldığımız ilhamı yine kadın eliyle şekillendiriyoruz.' ),
					array( 'title' => 'Bölgesel kalkınma', 'text' => 'Bölge çiftçisine düzenli zirai eğitim veriyor, kontrollü tarımla yerel istihdamı güçlendiriyoruz. Doğalı bu.' ),
					array( 'title' => 'Sözleşmeli tarım', 'text' => 'Çiftçimizle her yıl anlaşıyor, tarladan sofraya uzanan yolda kaliteyi şansa bırakmıyoruz.' ),
				),
			),
		),

		'field-intro' => array(
			'title'       => 'Pol\'s · Tek cümle (arka plan görselli)',
			'icon'        => 'format-quote',
			'description' => 'Tam ekran tek cümle; zirveden önceki sessizlik.',
			'fields'      => array(
				array( 'key' => 'text', 'type' => 'text', 'label' => 'Cümle' ),
				array( 'key' => 'image', 'type' => 'media', 'media' => 'image', 'label' => 'Arka plan görseli' ),
			),
			'defaults'    => array(
				'anchor' => 'sozlesmeli-tarim',
				'text' => 'Her şey bir tarlada başlar.',
				'image' => 0, 'imageFile' => '09-tarla-bg.webp',
			),
		),

		'journey' => array(
			'title'       => 'Pol\'s · Meyvelerin yolculuğu',
			'icon'        => 'location-alt',
			'description' => 'Yatay kayan duraklar; meyve rotada ilerler, her durakta mühür basılır ve bir sonraki meyveye dönüşür.',
			'fields'      => array(
				array( 'key' => 'heading', 'type' => 'text', 'label' => 'Başlık' ),
				array( 'key' => 'intro', 'type' => 'textarea', 'label' => 'Giriş metni' ),
				array( 'key' => 'stops', 'type' => 'repeater', 'label' => 'Duraklar', 'itemLabel' => 'title', 'fields' => array(
					array( 'key' => 'title', 'type' => 'text', 'label' => 'Durak adı (1–2 kelime)' ),
					array( 'key' => 'text', 'type' => 'textarea', 'label' => 'Metin' ),
					array( 'key' => 'image', 'type' => 'media', 'media' => 'image', 'label' => 'Görsel (3:4)' ),
					array( 'key' => 'alt', 'type' => 'text', 'label' => 'Görsel açıklaması (alt)' ),
				) ),
				array( 'key' => 'note', 'type' => 'text', 'label' => 'Kapanış notu' ),
				array( 'key' => 'noteAccent', 'type' => 'text', 'label' => 'Kapanış notu (turuncu)' ),
			),
			'defaults'    => array(
				'anchor' => 'yolculuk',
				'heading' => 'Tarladan sofraya güven.',
				'intro' => 'Kurulduğumuz ilk günden beri kalitemizi Sözleşmeli Tarım modeliyle güvence altına alıyoruz. Meyvelerimizin yolculuğunu birlikte izleyelim.',
				'stops' => array(
					array( 'title' => 'Anlaşma', 'text' => 'Ekimden önce çiftçimizle yıllık anlaşma yapıyor, alım garantisi veriyoruz. Plansız üretimin önüne ilk burada geçiyoruz.', 'image' => 0, 'imageFile' => '11-anlasma.webp', 'alt' => 'Çilek tarlasının kenarında tokalaşan iki çiftçi' ),
					array( 'title' => 'Eğitim', 'text' => 'Ziraat mühendislerimiz ekimden hasada tarlada. Doğru gübreleme ve ilaçlamayla toprağı ve suyu koruyoruz.', 'image' => 0, 'imageFile' => '12-egitim.webp', 'alt' => 'Çilek sıraları arasında toprağı inceleyen eller' ),
					array( 'title' => 'Hasat', 'text' => 'Çiftçimizin emeği korunur, uluslararası standartlarda hammadde tesisimize ulaşır.', 'image' => 0, 'imageFile' => '13-hasat.webp', 'alt' => 'Tarlada çilek hasadı yapan kadınlar' ),
					array( 'title' => 'Üretim', 'text' => 'Ermenek\'teki tesisimizde, %80\'i kadın ekibimizle ve yöre halkı için sürdürülebilir bir iş modeliyle üretiyoruz.', 'image' => 0, 'imageFile' => '14-uretim.webp', 'alt' => 'Üretim hattında çilek ayıklayan eldivenli eller' ),
					array( 'title' => 'Sofra', 'text' => 'Raftan sofranıza; doğal ve güvenilir. Yolculuk sofranızda tamamlanır.', 'image' => 0, 'imageFile' => '15-sofra.webp', 'alt' => 'Ahşap masada kurutulmuş meyve, reçel ve helva' ),
				),
				'note' => 'Beş durak, tek söz:',
				'noteAccent' => 'kaliteyi şansa bırakmıyoruz.',
			),
		),

		'scrub' => array(
			'title'       => 'Pol\'s · Video + metin (Sürdürülebilirlik)',
			'icon'        => 'video-alt3',
			'description' => 'Kaydırdıkça oynayan tam ekran video ve sağ altta metin.',
			'fields'      => array(
				array( 'key' => 'heading', 'type' => 'text', 'label' => 'Başlık' ),
				array( 'key' => 'text', 'type' => 'textarea', 'label' => 'Metin' ),
				array( 'key' => 'imageOnly', 'type' => 'toggle', 'label' => 'Video kullanma, sadece görsel göster' ),
				array( 'key' => 'video', 'type' => 'media', 'media' => 'video', 'label' => 'Video (masaüstü)' ),
				array( 'key' => 'videoMobile', 'type' => 'media', 'media' => 'video', 'label' => 'Video (mobil)' ),
				array( 'key' => 'poster', 'type' => 'media', 'media' => 'image', 'label' => 'Poster' ),
				array( 'key' => 'posterMobile', 'type' => 'media', 'media' => 'image', 'label' => 'Poster (mobil)' ),
				array( 'key' => 'plate', 'type' => 'media', 'media' => 'image', 'label' => 'Bulanık zemin: videonun SON karesi (masaüstü)' ),
				array( 'key' => 'plateMobile', 'type' => 'media', 'media' => 'image', 'label' => 'Bulanık zemin: videonun SON karesi (mobil)' ),
			),
			'defaults'    => array(
				'anchor' => 'surdurulebilirlik',
				'plate' => 0, 'plateFile' => '07-doga-end.webp',
				'plateMobile' => 0, 'plateMobileFile' => '07-doga-m-end.webp',
				'heading' => 'Dünyada bıraktığımız izi ölçüyoruz.',
				'text' => 'Kurumsal karbon ayak izimizi hesaplıyor, sözleşmeli çiftçilerimizle doğru gübreleme ve ilaçlama uygulayarak toprağımızı ve su kaynaklarımızı koruyoruz.',
				'imageOnly' => false,
				'video' => 0, 'videoFile' => '07-doga.mp4',
				'videoMobile' => 0, 'videoMobileFile' => '07-doga-m.mp4',
				'poster' => 0, 'posterFile' => '07-doga.webp',
				'posterMobile' => 0, 'posterMobileFile' => '07-doga-m.webp',
			),
		),

		'freeze-dry' => array(
			'title'       => 'Pol\'s · Freeze Dry süreci',
			'icon'        => 'performance',
			'description' => 'Sabitlenen süreç anlatımı ve su göstergesi.',
			'fields'      => array(
				array( 'key' => 'eyebrow', 'type' => 'text', 'label' => 'Üst etiket' ),
				array( 'key' => 'heading', 'type' => 'text', 'label' => 'Başlık' ),
				array( 'key' => 'headingAccent', 'type' => 'text', 'label' => 'Başlık (turuncu)' ),
				array( 'key' => 'steps', 'type' => 'repeater', 'label' => 'Adımlar', 'itemLabel' => 'title', 'fields' => array(
					array( 'key' => 'title', 'type' => 'text', 'label' => 'Adım' ),
					array( 'key' => 'text', 'type' => 'textarea', 'label' => 'Açıklama' ),
					array( 'key' => 'image', 'type' => 'media', 'media' => 'image', 'label' => 'Görsel (16:9)' ),
					array( 'key' => 'alt', 'type' => 'text', 'label' => 'Görsel açıklaması (alt)' ),
				) ),
				array( 'key' => 'dryStep', 'type' => 'text', 'label' => 'Su göstergesinin boşaldığı adım no (1–5)' ),
				array( 'key' => 'meterLabel', 'type' => 'text', 'label' => 'Gösterge etiketi' ),
				array( 'key' => 'waterFrom', 'type' => 'text', 'label' => 'Başlangıç su oranı (%)' ),
				array( 'key' => 'waterTo', 'type' => 'text', 'label' => 'Bitiş nem oranı (%)' ),
				array( 'key' => 'note', 'type' => 'textarea', 'label' => 'Gösterge notu' ),
			),
			'defaults'    => array(
				'anchor' => 'freeze-dry',
				'eyebrow' => 'Freeze Dry',
				'heading' => 'Meyvenin kendisi.',
				'headingAccent' => 'Sadece suyu yok.',
				'steps' => array(
					array( 'title' => 'Hasat', 'text' => 'Sözleşmeli bahçelerimizden, tam olgunlukta ve özenle toplanır.', 'image' => 0, 'imageFile' => '21-fd-hasat.webp', 'alt' => 'Tarlada çilek toplayan kadınlar' ),
					array( 'title' => 'Yıkama ve ayıklama', 'text' => 'Ermenek\'teki tesisimizde yıkanır, ekibimizin elinde tek tek ayıklanır.', 'image' => 0, 'imageFile' => '22-fd-yikama.webp', 'alt' => 'Yıkama hattında su altından geçen çilekler' ),
					array( 'title' => 'Şok dondurma (IQF)', 'text' => 'Her tanesi ayrı ayrı, hızla dondurulur. Böylece meyvenin dokusu ve şekli korunur.', 'image' => 0, 'imageFile' => '23-fd-iqf.webp', 'alt' => 'Tek tek dondurulmuş, buzlanmış çilekler' ),
					array( 'title' => 'Vakumda kurutma', 'text' => 'Tepsilere dizilir, vakum kabinlerinde kurutulur. Buz, sıvıya dönüşmeden doğrudan buhara geçer.', 'image' => 0, 'imageFile' => '24-fd-kurutma.webp', 'alt' => 'Freeze dry kabinine yerleştirilen çilek tepsileri' ),
					array( 'title' => 'Paketleme', 'text' => 'Nemden korunan ambalajlara, şeker ilavesiz ve katkısız olarak paketlenir.', 'image' => 0, 'imageFile' => '25-fd-paket.webp', 'alt' => 'Kurutulmuş çilek dilimlerinin Pol\'s Freeze Fresh paketlerine doldurulması' ),
				),
				'dryStep' => '4',
				'meterLabel' => 'Çilekteki su',
				'waterFrom' => '91',
				'waterTo' => '3',
				'note' => 'Taze çilek yaklaşık %91 sudur. Kurutma sonunda %1–4 nem kalır; renk, aroma ve şekil yerinde durur.',
			),
		),

		'facts' => array(
			'title'       => 'Pol\'s · Rakam şeridi (koyu)',
			'icon'        => 'chart-bar',
			'description' => 'Üç büyük rakam ve bir cümle.',
			'fields'      => array(
				array( 'key' => 'items', 'type' => 'repeater', 'label' => 'Rakamlar', 'itemLabel' => 'big', 'fields' => array(
					array( 'key' => 'big', 'type' => 'text', 'label' => 'Büyük yazı (ör. %97)' ),
					array( 'key' => 'label', 'type' => 'text', 'label' => 'Açıklama' ),
				) ),
				array( 'key' => 'line', 'type' => 'textarea', 'label' => 'Alt cümle' ),
			),
			'defaults'    => array(
				'anchor' => 'fd-facts',
				'items' => array(
					array( 'big' => '%97', 'label' => 'meyvenin kendine has nitelikleri korunur' ),
					array( 'big' => '4.000 m²', 'label' => 'Ermenek\'te kapalı üretim tesisi' ),
					array( 'big' => 'Katkısız', 'label' => 'şeker ilavesiz, doğal atıştırmalık' ),
				),
				'line' => 'Türkiye\'de freeze dry teknolojisini kullanan sayılı üretim tesislerinden biriyiz.',
			),
		),

		'certificates' => array(
			'title'       => 'Pol\'s · Sertifikalar',
			'icon'        => 'awards',
			'description' => 'Kayan logo şeridi. Logolar "Sertifikalar" içerik türünden gelir.',
			'fields'      => array(
				array( 'key' => 'heading', 'type' => 'text', 'label' => 'Başlık' ),
				array( 'key' => 'countLabel', 'type' => 'text', 'label' => 'Sayı yanındaki yazı' ),
			),
			'defaults'    => array(
				'anchor' => 'sertifikalar',
				'heading' => 'Uluslararası standartlarda, belgeli üretim.',
				'countLabel' => 'belge ve üyelik',
			),
		),

		'catalogs' => array(
			'title'       => 'Pol\'s · Kataloglar',
			'icon'        => 'book-alt',
			'description' => 'Üç eşit katalog kartı. Kartlar "Kataloglar" içerik türünden gelir.',
			'fields'      => array(
				array( 'key' => 'heading', 'type' => 'text', 'label' => 'Başlık' ),
				array( 'key' => 'intro', 'type' => 'textarea', 'label' => 'Giriş' ),
			),
			'defaults'    => array(
				'anchor' => 'urunler',
				'heading' => 'Kataloglarımız',
				'intro' => 'Endüstriyel üreticiler ve perakende için ayrı hazırlanmış güncel kataloglarımız.',
			),
		),

		'media' => array(
			'title'       => 'Pol\'s · Medya',
			'icon'        => 'format-video',
			'description' => 'Reklam filmi, belgesel bölümleri ve sosyal medya.',
			'fields'      => array(
				array( 'key' => 'heading', 'type' => 'text', 'label' => 'Başlık' ),
				array( 'key' => 'filmUrl', 'type' => 'url', 'label' => 'Reklam filmi bağlantısı' ),
				array( 'key' => 'filmLabel', 'type' => 'text', 'label' => 'Film yazısı' ),
				array( 'key' => 'filmPoster', 'type' => 'media', 'media' => 'image', 'label' => 'Film kapak görseli' ),
				array( 'key' => 'episodes', 'type' => 'repeater', 'label' => 'Belgesel bölümleri', 'itemLabel' => 'title', 'fields' => array(
					array( 'key' => 'title', 'type' => 'text', 'label' => 'Bölüm başlığı' ),
					array( 'key' => 'meta', 'type' => 'text', 'label' => 'Alt yazı (dizi · süre)' ),
					array( 'key' => 'url', 'type' => 'url', 'label' => 'YouTube bağlantısı' ),
				) ),
				array( 'key' => 'socials', 'type' => 'repeater', 'label' => 'Sosyal medya', 'itemLabel' => 'label', 'fields' => array(
					array( 'key' => 'label', 'type' => 'text', 'label' => 'Ad' ),
					array( 'key' => 'url', 'type' => 'url', 'label' => 'Bağlantı' ),
				) ),
			),
			'defaults'    => array(
				'anchor' => 'medya',
				'heading' => 'Bizden haberler',
				'filmUrl' => 'https://www.youtube.com/watch?v=qCuoG32CR1g',
				'filmLabel' => 'Reklam filmimizi YouTube\'da izleyin',
				'filmPoster' => 0, 'filmPosterFile' => '01-hero.webp',
				'episodes' => array(
					array( 'title' => 'Bağ Bahçe Burada, Bağımız da Burayla!', 'meta' => 'Hasat Zamanı · 10:19', 'url' => 'https://www.youtube.com/watch?v=-ZtSJUWMtfs' ),
					array( 'title' => 'Yatırımlarımız Meyvesini Veriyor', 'meta' => 'Hasat Zamanı · 9:27', 'url' => 'https://www.youtube.com/watch?v=3YKnyp4ryXc' ),
					array( 'title' => 'Burası Kadınların!', 'meta' => 'Hasat Zamanı · 9:16', 'url' => 'https://www.youtube.com/watch?v=uuTnbJ-FTIs' ),
					array( 'title' => 'Miras; Geleceğe Bıraktığımız Değer', 'meta' => 'Hasat Zamanı · 8:34', 'url' => 'https://www.youtube.com/watch?v=lDpNwANNYyU' ),
				),
				'socials' => array(
					array( 'label' => 'LinkedIn', 'url' => 'https://www.linkedin.com/company/polss' ),
					array( 'label' => 'YouTube', 'url' => 'https://www.youtube.com/channel/UCDVOf56bM8_xRs_LG5R2p7g' ),
					array( 'label' => 'Instagram', 'url' => 'https://www.instagram.com/polsgurme/' ),
				),
			),
		),

		'contact' => array(
			'title'       => 'Pol\'s · İletişim ve alt bilgi',
			'icon'        => 'email',
			'description' => 'Turuncu kapanış: e-posta, adresler ve alt bilgi.',
			'fields'      => array(
				array( 'key' => 'heading', 'type' => 'text', 'label' => 'Başlık' ),
				array( 'key' => 'email', 'type' => 'text', 'label' => 'E-posta' ),
				array( 'key' => 'copyLabel', 'type' => 'text', 'label' => 'Kopyala butonu' ),
				array( 'key' => 'locations', 'type' => 'repeater', 'label' => 'Adresler', 'itemLabel' => 'title', 'fields' => array(
					array( 'key' => 'title', 'type' => 'text', 'label' => 'Başlık' ),
					array( 'key' => 'address', 'type' => 'textarea', 'label' => 'Adres (satır başı = yeni satır)' ),
					array( 'key' => 'phone', 'type' => 'text', 'label' => 'Telefon (görünen)' ),
					array( 'key' => 'map', 'type' => 'url', 'label' => 'Harita bağlantısı' ),
					array( 'key' => 'mapLabel', 'type' => 'text', 'label' => 'Harita yazısı' ),
				) ),
				array( 'key' => 'copyright', 'type' => 'text', 'label' => 'Telif satırı' ),
				array( 'key' => 'legal', 'type' => 'repeater', 'label' => 'Alt bilgi bağlantıları', 'itemLabel' => 'label', 'fields' => array(
					array( 'key' => 'label', 'type' => 'text', 'label' => 'Yazı' ),
					array( 'key' => 'url', 'type' => 'url', 'label' => 'Bağlantı' ),
				) ),
			),
			'defaults'    => array(
				'anchor' => 'iletisim',
				'heading' => 'Bir merhaba yeter.',
				'email' => 'info@pols.com.tr',
				'copyLabel' => 'Kopyala',
				'locations' => array(
					array( 'title' => 'Merkez', 'address' => "Kızılırmak Mah., 1446. Cad., No:12/19\nÇankaya / Ankara", 'phone' => '+90 312 287 76 57', 'map' => 'https://www.google.com/maps/search/?api=1&query=K%C4%B1z%C4%B1l%C4%B1rmak+Mah+1446+Cad+No+12+%C3%87ankaya+Ankara', 'mapLabel' => 'Yol tarifi al ↗' ),
					array( 'title' => 'İstanbul Ofis', 'address' => "Hamidiye Mah., Cendere Cad., No:21\nSeba Central A Blok, Kat:6, Daire:24\nKağıthane / İstanbul", 'phone' => '', 'map' => 'https://www.google.com/maps/search/?api=1&query=Seba+Central+Cendere+Cad+21+K%C3%A2%C4%9F%C4%B1thane', 'mapLabel' => 'Yol tarifi al ↗' ),
					array( 'title' => 'Fabrika', 'address' => "Seyran Mah. Yağlısu Mevkii Küme Evler\nNo: 3-4, 70400 Ermenek / Karaman", 'phone' => '0850 216 76 57', 'map' => 'https://www.google.com/maps/search/?api=1&query=Seyran+Mah+Ya%C4%9Fl%C4%B1su+Mevkii+Ermenek+Karaman', 'mapLabel' => 'Yol tarifi al ↗' ),
				),
				'copyright' => '© 2026 Pol\'s Gıda · İyi gıda herkesin hakkı.',
				'legal' => array(
					array( 'label' => 'KVKK', 'url' => '#' ),
					array( 'label' => 'Gizlilik Politikası', 'url' => '#' ),
					array( 'label' => 'Çerez Tercihleri', 'url' => '#' ),
					array( 'label' => 'Başa dön ↑', 'url' => '#top' ),
				),
			),
		),
	);

	return $s;
}

/** Freeze Fresh fruit cut-outs shipped with the theme (from polsgurme.com),
 *  with the ink colour used for the number printed over each fruit. */
function pols_fruits() {
	return array(
		'cilek'     => array( 'label' => 'Çilek', 'file' => 'fruit-cilek.webp', 'w' => 325, 'h' => 364, 'ink' => '#B4232A' ),
		'ahududu'   => array( 'label' => 'Ahududu', 'file' => 'fruit-ahududu.webp', 'w' => 270, 'h' => 294, 'ink' => '#C0395A' ),
		'bogurtlen' => array( 'label' => 'Böğürtlen', 'file' => 'fruit-bogurtlen.webp', 'w' => 257, 'h' => 332, 'ink' => '#3F2A4A' ),
		'mango'     => array( 'label' => 'Mango', 'file' => 'fruit-mango.webp', 'w' => 400, 'h' => 325, 'ink' => '#B8620A' ),
		'muz'       => array( 'label' => 'Muz', 'file' => 'fruit-muz.webp', 'w' => 356, 'h' => 352, 'ink' => '#7A5A1E' ),
		'ananas'    => array( 'label' => 'Ananas', 'file' => 'fruit-ananas.webp', 'w' => 400, 'h' => 390, 'ink' => '#8A6A14' ),
		'portakal'  => array( 'label' => 'Portakal', 'file' => 'fruit-portakal.webp', 'w' => 400, 'h' => 399, 'ink' => '#B4560A' ),
	);
}

/** Order of the fruits riding the journey route: one more fruit per stop passed. */
function pols_journey_fruits() {
	return array( 'cilek', 'ananas', 'bogurtlen', 'portakal', 'mango', 'muz' );
}

function pols_block_defaults( $slug ) {
	$s = pols_schema();
	return isset( $s[ $slug ] ) ? $s[ $slug ]['defaults'] : array();
}

/** Attribute definitions derived from the defaults' PHP types. */
function pols_block_attributes( $slug ) {
	$attrs = array();
	foreach ( pols_block_defaults( $slug ) as $key => $value ) {
		if ( is_array( $value ) ) {
			$type = 'array';
		} elseif ( is_int( $value ) ) {
			$type = 'integer';
		} elseif ( is_bool( $value ) ) {
			$type = 'boolean';
		} else {
			$type = 'string';
		}
		$attrs[ $key ] = array( 'type' => $type, 'default' => $value );
	}
	return $attrs;
}

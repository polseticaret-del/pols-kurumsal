<?php
/**
 * Block schema: the single source for every section block.
 *
 *   title / icon / description   inserter metadata
 *   fields                       editor sidebar controls (rendered by editor.js)
 *   defaults                     attribute defaults = the approved TR copy
 *
 * Media fields store an attachment ID; a sibling "<key>File" string names the
 * bundled fallback in /seed/media, so a block renders correctly before (or
 * without) the media import. Repeater items carry the same pair.
 *
 * Field types: text, textarea, url, media (image|video), toggle, select,
 * repeater (fields, itemLabel).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function pols_schema() {
	static $s = null;
	if ( null !== $s ) {
		return $s;
	}

	$fruit_options = array();
	foreach ( pols_fruits() as $k => $f ) {
		$fruit_options[] = array( 'value' => $k, 'label' => $f['label'] );
	}

	$badge_colors = array(
		array( 'value' => 'orange-btn', 'label' => 'Turuncu (koyu)' ),
		array( 'value' => 'orange', 'label' => 'Turuncu' ),
		array( 'value' => 'forest', 'label' => 'Orman yeşili' ),
		array( 'value' => 'green-mid', 'label' => 'Yeşil' ),
		array( 'value' => 'peach', 'label' => 'Şeftali' ),
		array( 'value' => 'berry', 'label' => 'Vişne' ),
	);

	$s = array(

		'hero' => array(
			'title'       => 'Pol\'s · Giriş',
			'icon'        => 'cover-image',
			'description' => 'Kaydırdıkça oynayan video, başlık ve motto.',
			'fields'      => array(
				array( 'key' => 'titleA', 'type' => 'text', 'label' => 'Başlık (1. kısım)' ),
				array( 'key' => 'titleB', 'type' => 'text', 'label' => 'Başlık (turuncu kısım)' ),
				array( 'key' => 'motto', 'type' => 'text', 'label' => 'Motto' ),
				array( 'key' => 'mottoSub', 'type' => 'text', 'label' => 'Motto alt satırı' ),
				array( 'key' => 'imageOnly', 'type' => 'toggle', 'label' => 'Video kullanma, sadece görsel göster' ),
				array( 'key' => 'video', 'type' => 'media', 'media' => 'video', 'label' => 'Video (masaüstü, mp4)' ),
				array( 'key' => 'videoMobile', 'type' => 'media', 'media' => 'video', 'label' => 'Video (mobil, dikey mp4)' ),
				array( 'key' => 'poster', 'type' => 'media', 'media' => 'image', 'label' => 'Poster (videonun ilk karesi)' ),
				array( 'key' => 'posterMobile', 'type' => 'media', 'media' => 'image', 'label' => 'Poster (mobil)' ),
				array( 'key' => 'plate', 'type' => 'media', 'media' => 'image', 'label' => 'Bulanık zemin: videonun SON karesi (masaüstü)' ),
				array( 'key' => 'plateMobile', 'type' => 'media', 'media' => 'image', 'label' => 'Bulanık zemin: videonun SON karesi (mobil)' ),
			),
			'defaults'    => array(
				'anchor' => 'giris',
				'plate' => 0, 'plateFile' => '01-hero-end.webp',
				'plateMobile' => 0, 'plateMobileFile' => '01-hero-m-end.webp',
				'titleA' => 'Doğduğumuz topraklara',
				'titleB' => 'değer katıyoruz.',
				'motto' => '“Özünde iyilik var.”',
				'mottoSub' => 'Ermenek, 2017\'den beri',
				'imageOnly' => false,
				'video' => 0, 'videoFile' => '01-hero.mp4',
				'videoMobile' => 0, 'videoMobileFile' => '01-hero-m.mp4',
				'poster' => 0, 'posterFile' => '01-hero.webp',
				'posterMobile' => 0, 'posterMobileFile' => '01-hero-m.webp',
			),
		),

		// Motto, a short introduction and the figures, on the frosted plate
		// (content brief 2026-10-08).
		'about' => array(
			'title'       => "Pol's · Hakkımızda (slogan, giriş, rakamlar)",
			'icon'        => 'id',
			'description' => 'Slogan, kısa tanıtım metni ve rakamlar; bulanık zemin üzerinde.',
			'fields'      => array(
				array( 'key' => 'heading', 'type' => 'text', 'label' => 'Slogan' ),
				array( 'key' => 'intro', 'type' => 'textarea', 'label' => 'Tanıtım metni (paragrafları boş satırla ayırın)' ),
				array( 'key' => 'badges', 'type' => 'repeater', 'label' => 'Rakamlar', 'itemLabel' => 'big', 'fields' => array(
					array( 'key' => 'big', 'type' => 'text', 'label' => 'Büyük yazı (ör. 2017, %85, 1.000+, 30+)' ),
					array( 'key' => 'label', 'type' => 'text', 'label' => 'Alt yazı' ),
				) ),
			),
			'defaults'    => array(
				'anchor' => 'hakkimizda',
				'heading' => 'Özünde iyilik var.',
				'intro' => "Pol's'ün yolculuğu, bu anlayıştan ve doğduğumuz topraklara değer katma hedefimizden yola çıkarak 2017 yılında Karaman'ın Ermenek ilçesinde başladı.\n\nGıda ve tarım sektöründe değişen üretim dinamiklerini, gelişen teknolojileri ve tüketici beklentilerini yakından takip ederek doğal, güvenilir, kaliteli ve sürdürülebilir gıdayı daha fazla insanla buluşturmayı amaçlıyoruz.\n\nBizim için Pol's yalnızca bir gıda markası değil; kadın emeğini, sürdürülebilirliği, toprağı, çiftçiyi ve teknolojiyi aynı değer zincirinde buluşturan bir üretim yaklaşımıdır.",
				'badges' => array(
					array( 'big' => '2017', 'label' => "Ermenek'te kuruluş" ),
					array( 'big' => '%85', 'label' => 'kadın çalışan' ),
					array( 'big' => '1.000+', 'label' => 'sözleşmeli çiftçi' ),
					array( 'big' => '30+', 'label' => 'ülkeye ihracat' ),
				),
			),
		),

		// Three chapters in flow; a chapter with a photo becomes the full-bleed
		// photo chapter (copy on its pale left side).
		'values' => array(
			'title'       => "Pol's · Değerlerimiz",
			'icon'        => 'heart',
			'description' => 'Başlık, alt başlık ve metinden oluşan bölümler; görselli bölüm tam ekran fotoğraflı olur.',
			'fields'      => array(
				array( 'key' => 'label', 'type' => 'text', 'label' => 'Üst etiket' ),
				array( 'key' => 'items', 'type' => 'repeater', 'label' => 'Değerler', 'itemLabel' => 'title', 'fields' => array(
					array( 'key' => 'title', 'type' => 'text', 'label' => 'Başlık' ),
					array( 'key' => 'sub', 'type' => 'text', 'label' => 'Alt başlık (turuncu)' ),
					array( 'key' => 'text', 'type' => 'textarea', 'label' => 'Metin (paragrafları boş satırla ayırın)' ),
					array( 'key' => 'close', 'type' => 'text', 'label' => 'Kapanış cümlesi (kalın, isteğe bağlı)' ),
					array( 'key' => 'image', 'type' => 'media', 'media' => 'image', 'label' => 'Fotoğraf (isteğe bağlı, 16:9; sol tarafı sade olmalı)' ),
					array( 'key' => 'alt', 'type' => 'text', 'label' => 'Fotoğraf açıklaması (alt)' ),
				) ),
			),
			'defaults'    => array(
				'anchor' => 'degerler',
				'label' => 'Değerlerimiz',
				'items' => array(
					array( 'title' => 'Kadın istihdamı', 'sub' => "Gücümüzün %85'i kadın!",
						'text' => "Pol's olarak, güçlü ve sürdürülebilir bir çalışma kültürünün farklı bakış açıları ve güçlü ekiplerle mümkün olduğuna inanıyoruz.\n\nÜretim gücümüzün temelini oluşturan fabrikamızda çalışanlarımızın %85'ini kadınlar oluşturuyor. Kadınların iş hayatındaki varlığını ve üretime kattıkları değeri desteklemeyi yalnızca istihdam politikamızın değil, kurum kültürümüzün de önemli bir parçası olarak görüyoruz.\n\nKadın çalışanlarımızın bilgi, deneyim ve emeği; üretim süreçlerimizden kalite anlayışımıza kadar Pol's'ün başarısına değer katarken, kadınların ekonomik hayatta daha güçlü bir şekilde yer almasını destekleyen çalışma ortamımızla fırsat eşitliğini ve kapsayıcı bir iş kültürünü geliştirmeye devam ediyoruz.",
						'close' => "Pol's'te kadınların emeğiyle bugünümüzü, birlikte geleceğimizi büyütüyoruz.",
						'image' => 0, 'imageFile' => '16-kadin.webp', 'alt' => "Pol's tesisinde freeze dry çilek dilimlerini tepsilere dizen kadın çalışanlar" ),
					array( 'title' => 'Bölgesel kalkınmaya değer katıyoruz', 'sub' => "Ermenek'ten güç alıyor, bölgeyle birlikte büyüyoruz!",
						'text' => "Karaman'ın Ermenek ilçesinde bulunan üretim tesisimizle, faaliyet gösterdiğimiz bölgenin ekonomik ve sosyal gelişimine katkı sağlamayı önemsiyoruz. Bizim için sürdürülebilir büyüme yalnızca üretim kapasitemizi artırmak değil; içinde bulunduğumuz bölgeye, çalışanlarımıza, çiftçimize ve topluma kalıcı değer yaratmak anlamına geliyor.\n\nErmenek'te gerçekleştirdiğimiz üretim faaliyetlerini bölgesel kalkınmanın önemli bir parçası olarak görüyor; yarattığımız istihdam ve oluşturduğumuz ekonomik hareketlilikle bölgenin üretim gücüne katkı sağlamayı hedefliyoruz.\n\nErmenek'in yerel üretim gücünü destekleyen iş birliklerine önem veriyor, bölgenin ekonomik potansiyelinin sürdürülebilir biçimde gelişmesine katkı sunmayı hedefliyoruz.",
						'close' => 'Üretiyor, istihdam yaratıyor, iş birlikleri geliştiriyor ve birlikte büyüyoruz.',
						'image' => 0, 'imageFile' => '', 'alt' => '' ),
					array( 'title' => 'Sözleşmeli tarım', 'sub' => 'Emeği değere, üretimi geleceğe taşıyoruz!',
						'text' => "Pol's olarak, sürdürülebilir üretimin güçlü ve güvene dayalı iş birlikleriyle mümkün olduğuna inanıyoruz. Sözleşmeli tarım modelimizle üreticilerimizle uzun vadeli ve karşılıklı değer yaratma anlayışına dayalı ilişkiler kuruyor; üretim planlamasından kalite standartlarının korunmasına kadar sürecin her aşamasında birlikte hareket ediyoruz. Bu yaklaşımımızla üreticilerimizin emeğini ve deneyimini desteklerken, Pol's'ün yüksek kalite standartlarıyla güvenilir ve sürdürülebilir bir üretim yapısı oluşturuyoruz.\n\nYerel üretim gücünü geleceğe taşıma hedefiyle, üreticilerimizin bilgi ve deneyimini modern tarım uygulamaları ve kalite odaklı üretim anlayışımızla buluşturuyoruz. Toprağa, çiftçiye ve üretimin değerine duyduğumuz sorumlulukla; bugün olduğu gibi gelecekte de sürdürülebilir, izlenebilir ve yüksek standartlarda bir tarımsal üretim ekosistemi geliştirmeyi hedefliyoruz.",
						'close' => '', 'image' => 0, 'imageFile' => '', 'alt' => '' ),
				),
			),
		),

		'field-intro' => array(
			'title'       => "Pol's · Eğitim bahçelerimiz (tam ekran görsel + metin)",
			'icon'        => 'format-quote',
			'description' => 'Tam ekran arka plan; ortada başlık, alt başlık ve kısa metin.',
			'fields'      => array(
				array( 'key' => 'text', 'type' => 'text', 'label' => 'Başlık' ),
				array( 'key' => 'sub', 'type' => 'text', 'label' => 'Alt başlık (turuncu)' ),
				array( 'key' => 'body', 'type' => 'textarea', 'label' => 'Metin' ),
				array( 'key' => 'image', 'type' => 'media', 'media' => 'image', 'label' => 'Arka plan görseli' ),
			),
			'defaults'    => array(
				'anchor' => 'sozlesmeli-tarim',
				'text' => 'Eğitim bahçelerimiz.',
				'sub' => 'Bilgiyi toprakla buluşturuyor, geleceği birlikte yetiştiriyoruz.',
				'body' => "Pol's Eğitim Bahçeleri ile yerel çiftçilerimizin ve üreticilerimizin bilgi ve deneyimlerini geliştirmeyi, sürdürülebilir tarım uygulamalarını yaygınlaştırmayı hedefliyoruz. Toprağın doğru işlenmesi ve korunmasından verimli üretim yöntemlerine, hasat süreçlerinden ürün kalitesinin artırılmasına kadar tarımsal üretimin farklı aşamalarında uygulamalı eğitim ve bilgilendirme çalışmaları gerçekleştiriyoruz. Üreticilerimizi güncel tarım uygulamalarıyla buluşturarak toprağın verimliliğini koruyan, kaynakları etkin kullanan ve gelecek nesillere değer taşıyan bir üretim kültürünün gelişmesine katkı sağlıyoruz.",
				'image' => 0, 'imageFile' => '09-tarla-bg.webp',
			),
		),

		'journey' => array(
			'title'       => "Pol's · Meyvelerin yolculuğu",
			'icon'        => 'location-alt',
			'description' => 'Yatay kayan duraklar; meyve rotada ilerler, her durakta mühür basılır ve bir sonraki meyveye dönüşür.',
			'fields'      => array(
				array( 'key' => 'heading', 'type' => 'text', 'label' => 'Başlık' ),
				array( 'key' => 'intro', 'type' => 'textarea', 'label' => 'Giriş metni' ),
				array( 'key' => 'stops', 'type' => 'repeater', 'label' => 'Duraklar', 'itemLabel' => 'title', 'fields' => array(
					array( 'key' => 'title', 'type' => 'text', 'label' => 'Durak adı (1–2 kelime)' ),
					array( 'key' => 'text', 'type' => 'text', 'label' => 'Kısa slogan' ),
					array( 'key' => 'image', 'type' => 'media', 'media' => 'image', 'label' => 'Görsel (3:4)' ),
					array( 'key' => 'alt', 'type' => 'text', 'label' => 'Görsel açıklaması (alt)' ),
				) ),
				array( 'key' => 'note', 'type' => 'text', 'label' => 'Kapanış notu' ),
				array( 'key' => 'noteAccent', 'type' => 'text', 'label' => 'Kapanış notu (turuncu)' ),
			),
			'defaults'    => array(
				'anchor' => 'yolculuk',
				'heading' => 'Tarladan sofraya güven!',
				'intro' => 'Kurulduğumuz ilk günden beri kalitemizi Sözleşmeli Tarım modeliyle güvence altına alıyoruz. Meyvelerimizin yolculuğunu birlikte izleyelim.',
				'stops' => array(
					array( 'title' => 'Anlaşma', 'text' => 'Güvenle başlayan üretim', 'image' => 0, 'imageFile' => '11-anlasma.webp', 'alt' => 'Çilek tarlasının kenarında tokalaşan iki çiftçi' ),
					array( 'title' => 'Eğitim', 'text' => 'Bilgiyle şekillenen gelecek', 'image' => 0, 'imageFile' => '12-egitim.webp', 'alt' => 'Çilek sıraları arasında toprağı inceleyen eller' ),
					array( 'title' => 'Hasat', 'text' => 'Emek toprakla buluşuyor', 'image' => 0, 'imageFile' => '13-hasat.webp', 'alt' => 'Tarlada çilek hasadı yapan kadınlar' ),
					array( 'title' => 'Üretim', 'text' => 'Üretimden geleceğe değer katıyoruz', 'image' => 0, 'imageFile' => '14-uretim.webp', 'alt' => 'Üretim hattında çilek ayıklayan eldivenli eller' ),
					array( 'title' => 'Sofra', 'text' => 'Topraktan sofraya, güvenle', 'image' => 0, 'imageFile' => '15-sofra.webp', 'alt' => 'Ahşap masada kurutulmuş meyve, reçel ve helva' ),
				),
				'note' => 'Beş durak, tek söz:',
				'noteAccent' => 'kaliteyi şansa bırakmıyoruz.',
			),
		),

		'scrub' => array(
			'title'       => "Pol's · Video + metin (Sürdürülebilirlik)",
			'icon'        => 'video-alt3',
			'description' => 'Kaydırdıkça oynayan tam ekran video ve sağ altta metin.',
			'fields'      => array(
				array( 'key' => 'eyebrow', 'type' => 'text', 'label' => 'Üst etiket' ),
				array( 'key' => 'heading', 'type' => 'text', 'label' => 'Başlık' ),
				array( 'key' => 'text', 'type' => 'textarea', 'label' => 'Metin' ),
				array( 'key' => 'imageOnly', 'type' => 'toggle', 'label' => 'Video kullanma, sadece görsel göster' ),
				array( 'key' => 'video', 'type' => 'media', 'media' => 'video', 'label' => 'Video (masaüstü)' ),
				array( 'key' => 'videoMobile', 'type' => 'media', 'media' => 'video', 'label' => 'Video (mobil)' ),
				array( 'key' => 'poster', 'type' => 'media', 'media' => 'image', 'label' => 'Poster' ),
				array( 'key' => 'posterMobile', 'type' => 'media', 'media' => 'image', 'label' => 'Poster (mobil)' ),
				array( 'key' => 'plate', 'type' => 'media', 'media' => 'image', 'label' => 'Bulanık zemin: videonun SON karesi (masaüstü)' ),
				array( 'key' => 'plateMobile', 'type' => 'media', 'media' => 'image', 'label' => 'Bulanık zemin: videonun SON karesi (mobil)' ),
			),
			'defaults'    => array(
				'anchor' => 'surdurulebilirlik',
				'plate' => 0, 'plateFile' => '07-doga-end.webp',
				'plateMobile' => 0, 'plateMobileFile' => '07-doga-m-end.webp',
				'eyebrow' => 'Karbon ayak izi',
				'heading' => 'Dünyada bıraktığımız izi ölçüyoruz.',
				'text' => 'Karbon ayak izi hesaplamalarıyla çevresel etkilerimizi ölçüyor, yeşil dönüşüm sürecine katkı sağlıyoruz. Çevresel sorumluluğumuzu sürdürülebilirlik anlayışımızla bütünleştirerek, daha yaşanabilir bir gelecek için kararlı adımlarla ilerliyoruz.',
				'imageOnly' => false,
				'video' => 0, 'videoFile' => '07-doga.mp4',
				'videoMobile' => 0, 'videoMobileFile' => '07-doga-m.mp4',
				'poster' => 0, 'posterFile' => '07-doga.webp',
				'posterMobile' => 0, 'posterMobileFile' => '07-doga-m.webp',
			),
		),

		'freeze-dry' => array(
			'title'       => 'Pol\'s · Freeze Dry süreci',
			'icon'        => 'performance',
			'description' => 'Sabitlenen süreç anlatımı ve su göstergesi.',
			'fields'      => array(
				array( 'key' => 'eyebrow', 'type' => 'text', 'label' => 'Üst etiket' ),
				array( 'key' => 'heading', 'type' => 'text', 'label' => 'Başlık' ),
				array( 'key' => 'headingAccent', 'type' => 'text', 'label' => 'Başlık (turuncu)' ),
				array( 'key' => 'steps', 'type' => 'repeater', 'label' => 'Adımlar', 'itemLabel' => 'title', 'fields' => array(
					array( 'key' => 'title', 'type' => 'text', 'label' => 'Adım' ),
					array( 'key' => 'text', 'type' => 'textarea', 'label' => 'Açıklama' ),
					array( 'key' => 'image', 'type' => 'media', 'media' => 'image', 'label' => 'Görsel (16:9)' ),
					array( 'key' => 'alt', 'type' => 'text', 'label' => 'Görsel açıklaması (alt)' ),
				) ),
				array( 'key' => 'dryStep', 'type' => 'text', 'label' => 'Su göstergesinin boşaldığı adım no (1–5)' ),
				array( 'key' => 'meterLabel', 'type' => 'text', 'label' => 'Gösterge etiketi' ),
				array( 'key' => 'waterFrom', 'type' => 'text', 'label' => 'Başlangıç su oranı (%)' ),
				array( 'key' => 'waterTo', 'type' => 'text', 'label' => 'Bitiş nem oranı (%)' ),
				array( 'key' => 'note', 'type' => 'textarea', 'label' => 'Gösterge notu' ),
			),
			'defaults'    => array(
				'anchor' => 'freeze-dry',
				'eyebrow' => 'Freeze Dry',
				'heading' => 'Meyvenin kendisi.',
				'headingAccent' => 'Sadece suyu yok.',
				'steps' => array(
					array( 'title' => 'Hasat', 'text' => 'Sözleşmeli bahçelerimizden, tam olgunlukta ve özenle toplanır.', 'image' => 0, 'imageFile' => '21-fd-hasat.webp', 'alt' => 'Tarlada çilek toplayan kadınlar' ),
					array( 'title' => 'Yıkama ve ayıklama', 'text' => 'Ermenek\'teki tesisimizde yıkanır, ekibimizin elinde tek tek ayıklanır.', 'image' => 0, 'imageFile' => '22-fd-yikama.webp', 'alt' => 'Yıkama hattında su altından geçen çilekler' ),
					array( 'title' => 'Şok dondurma (IQF)', 'text' => 'Her tanesi ayrı ayrı, hızla dondurulur. Böylece meyvenin dokusu ve şekli korunur.', 'image' => 0, 'imageFile' => '23-fd-iqf.webp', 'alt' => 'Tek tek dondurulmuş, buzlanmış çilekler' ),
					array( 'title' => 'Vakumda kurutma', 'text' => 'Tepsilere dizilir, vakum kabinlerinde kurutulur. Buz, sıvıya dönüşmeden doğrudan buhara geçer.', 'image' => 0, 'imageFile' => '24-fd-kurutma.webp', 'alt' => 'Freeze dry kabinine yerleştirilen çilek tepsileri' ),
					array( 'title' => 'Paketleme', 'text' => 'Nemden korunan ambalajlara, şeker ilavesiz ve katkısız olarak paketlenir.', 'image' => 0, 'imageFile' => '25-fd-paket.webp', 'alt' => 'Kurutulmuş çilek dilimlerinin Pol\'s Freeze Fresh paketlerine doldurulması' ),
				),
				'dryStep' => '4',
				'meterLabel' => 'Çilekteki su',
				'waterFrom' => '91',
				'waterTo' => '3',
				'note' => 'Taze çilek yaklaşık %91 sudur. Kurutma sonunda %1–4 nem kalır; renk, aroma ve şekil yerinde durur.',
			),
		),

		'facts' => array(
			'title'       => 'Pol\'s · Rakam şeridi (koyu)',
			'icon'        => 'chart-bar',
			'description' => 'Üç büyük rakam ve bir cümle.',
			'fields'      => array(
				array( 'key' => 'items', 'type' => 'repeater', 'label' => 'Rakamlar', 'itemLabel' => 'big', 'fields' => array(
					array( 'key' => 'big', 'type' => 'text', 'label' => 'Büyük yazı (ör. %97)' ),
					array( 'key' => 'label', 'type' => 'text', 'label' => 'Açıklama' ),
				) ),
				array( 'key' => 'line', 'type' => 'textarea', 'label' => 'Alt cümle' ),
			),
			'defaults'    => array(
				'anchor' => 'fd-facts',
				'items' => array(
					array( 'big' => '%97', 'label' => 'meyvenin kendine has nitelikleri korunur' ),
					array( 'big' => '4.000 m²', 'label' => 'Ermenek\'te kapalı üretim tesisi' ),
					array( 'big' => 'Katkısız', 'label' => 'şeker ilavesiz, doğal atıştırmalık' ),
				),
				'line' => 'Türkiye\'de freeze dry teknolojisini kullanan sayılı üretim tesislerinden biriyiz.',
			),
		),

		'certificates' => array(
			'title'       => 'Pol\'s · Sertifikalar',
			'icon'        => 'awards',
			'description' => 'Kayan logo şeridi. Logolar "Sertifikalar" içerik türünden gelir.',
			'fields'      => array(
				array( 'key' => 'heading', 'type' => 'text', 'label' => 'Başlık' ),
			),
			'defaults'    => array(
				'anchor' => 'sertifikalar',
				'heading' => 'Uluslararası standartlarda, belgeli üretim.',
				'countLabel' => 'belge ve üyelik',
			),
		),

		'catalogs' => array(
			'title'       => 'Pol\'s · Kataloglar',
			'icon'        => 'book-alt',
			'description' => 'Üç eşit katalog kartı. Kartlar "Kataloglar" içerik türünden gelir.',
			'fields'      => array(
				array( 'key' => 'heading', 'type' => 'text', 'label' => 'Başlık' ),
				array( 'key' => 'intro', 'type' => 'textarea', 'label' => 'Giriş' ),
			),
			'defaults'    => array(
				'anchor' => 'urunler',
				'heading' => 'Kataloglarımız',
				'intro' => 'Endüstriyel üreticiler ve perakende için ayrı hazırlanmış güncel kataloglarımız.',
			),
		),

		'media' => array(
			'title'       => 'Pol\'s · Medya',
			'icon'        => 'format-video',
			'description' => 'Reklam filmi, belgesel bölümleri ve sosyal medya.',
			'fields'      => array(
				array( 'key' => 'heading', 'type' => 'text', 'label' => 'Başlık' ),
				array( 'key' => 'filmUrl', 'type' => 'url', 'label' => 'Reklam filmi bağlantısı' ),
				array( 'key' => 'filmLabel', 'type' => 'text', 'label' => 'Film yazısı' ),
				array( 'key' => 'filmPoster', 'type' => 'media', 'media' => 'image', 'label' => 'Film kapak görseli' ),
				array( 'key' => 'episodes', 'type' => 'repeater', 'label' => 'Belgesel bölümleri', 'itemLabel' => 'title', 'fields' => array(
					array( 'key' => 'title', 'type' => 'text', 'label' => 'Bölüm başlığı' ),
					array( 'key' => 'meta', 'type' => 'text', 'label' => 'Alt yazı (dizi · süre)' ),
					array( 'key' => 'url', 'type' => 'url', 'label' => 'YouTube bağlantısı' ),
				) ),
				array( 'key' => 'socials', 'type' => 'repeater', 'label' => 'Sosyal medya (LinkedIn, YouTube, Instagram logo olarak görünür)', 'itemLabel' => 'label', 'fields' => array(
					array( 'key' => 'label', 'type' => 'text', 'label' => 'Ad' ),
					array( 'key' => 'url', 'type' => 'url', 'label' => 'Bağlantı' ),
				) ),
				array( 'key' => 'feedHeading', 'type' => 'text', 'label' => 'LinkedIn akışı başlığı (boş bırakılırsa görünmez)' ),
				array( 'key' => 'feedMore', 'type' => 'text', 'label' => 'LinkedIn "tümünü gör" yazısı' ),
				array( 'key' => 'linkedinPosts', 'type' => 'repeater', 'label' => 'LinkedIn gönderileri (gönderinin linkini yapıştırın; yeni gönderiyi en üste ekleyin)', 'itemLabel' => 'url', 'fields' => array(
					array( 'key' => 'url', 'type' => 'url', 'label' => 'Gönderi linki (LinkedIn → gönderi → ··· → Gönderi bağlantısını kopyala)' ),
				) ),
			),
			'defaults'    => array(
				'anchor' => 'medya',
				'heading' => 'Bizden haberler',
				'filmUrl' => 'https://www.youtube.com/watch?v=qCuoG32CR1g',
				'filmLabel' => 'Reklam filmimizi YouTube\'da izleyin',
				'filmPoster' => 0, 'filmPosterFile' => '01-hero.webp',
				'episodes' => array(
					array( 'title' => 'Bağ Bahçe Burada, Bağımız da Burayla!', 'meta' => 'Hasat Zamanı · 10:19', 'url' => 'https://www.youtube.com/watch?v=-ZtSJUWMtfs' ),
					array( 'title' => 'Yatırımlarımız Meyvesini Veriyor', 'meta' => 'Hasat Zamanı · 9:27', 'url' => 'https://www.youtube.com/watch?v=3YKnyp4ryXc' ),
					array( 'title' => 'Burası Kadınların!', 'meta' => 'Hasat Zamanı · 9:16', 'url' => 'https://www.youtube.com/watch?v=uuTnbJ-FTIs' ),
					array( 'title' => 'Miras; Geleceğe Bıraktığımız Değer', 'meta' => 'Hasat Zamanı · 8:34', 'url' => 'https://www.youtube.com/watch?v=lDpNwANNYyU' ),
				),
				'socials' => array(
					array( 'label' => 'LinkedIn', 'url' => 'https://www.linkedin.com/company/polss' ),
					array( 'label' => 'YouTube', 'url' => 'https://www.youtube.com/channel/UCDVOf56bM8_xRs_LG5R2p7g' ),
					array( 'label' => 'Instagram', 'url' => 'https://www.instagram.com/polsgurme/' ),
				),
				'feedHeading' => '',
				'feedMore' => 'Tümünü gör',
				// linkedin.com/company/polss, 2026-09-30 (own posts, no reposts).
				'linkedinPosts' => array(
					array( 'url' => 'https://www.linkedin.com/feed/update/urn:li:activity:7500175905135267840/' ),
					array( 'url' => 'https://www.linkedin.com/feed/update/urn:li:activity:7498622165307691008/' ),
					array( 'url' => 'https://www.linkedin.com/feed/update/urn:li:activity:7478068889860624384/' ),
					array( 'url' => 'https://www.linkedin.com/feed/update/urn:li:activity:7476179791239634944/' ),
				),
			),
		),

		'contact' => array(
			'title'       => 'Pol\'s · İletişim ve alt bilgi',
			'icon'        => 'email',
			'description' => 'Turuncu kapanış: e-posta, adresler ve alt bilgi.',
			'fields'      => array(
				array( 'key' => 'heading', 'type' => 'text', 'label' => 'Başlık' ),
				array( 'key' => 'email', 'type' => 'text', 'label' => 'E-posta' ),
				array( 'key' => 'copyLabel', 'type' => 'text', 'label' => 'Kopyala butonu' ),
				array( 'key' => 'locations', 'type' => 'repeater', 'label' => 'Adresler', 'itemLabel' => 'title', 'fields' => array(
					array( 'key' => 'title', 'type' => 'text', 'label' => 'Başlık' ),
					array( 'key' => 'address', 'type' => 'textarea', 'label' => 'Adres (satır başı = yeni satır)' ),
					array( 'key' => 'phone', 'type' => 'text', 'label' => 'Telefon (görünen)' ),
					array( 'key' => 'map', 'type' => 'url', 'label' => 'Harita bağlantısı' ),
					array( 'key' => 'mapLabel', 'type' => 'text', 'label' => 'Harita yazısı' ),
				) ),
				array( 'key' => 'copyright', 'type' => 'text', 'label' => 'Telif satırı' ),
				array( 'key' => 'socials', 'type' => 'repeater', 'label' => 'Alt bilgi sosyal medya (logo olarak, ortada)', 'itemLabel' => 'label', 'fields' => array(
					array( 'key' => 'label', 'type' => 'text', 'label' => 'Ad' ),
					array( 'key' => 'url', 'type' => 'url', 'label' => 'Bağlantı' ),
				) ),
				array( 'key' => 'legal', 'type' => 'repeater', 'label' => 'Alt bilgi bağlantıları', 'itemLabel' => 'label', 'fields' => array(
					array( 'key' => 'label', 'type' => 'text', 'label' => 'Yazı' ),
					array( 'key' => 'url', 'type' => 'url', 'label' => 'Bağlantı' ),
				) ),
			),
			'defaults'    => array(
				'anchor' => 'iletisim',
				'heading' => 'Bir merhaba yeter.',
				'email' => 'info@pols.com.tr',
				'copyLabel' => 'Kopyala',
				'locations' => array(
					array( 'title' => 'Merkez', 'address' => "Kızılırmak Mah., 1446. Cad., No:12/19\n06530 Çankaya / Ankara", 'phone' => '+90 312 287 76 57', 'map' => 'https://www.google.com/maps/search/?api=1&query=K%C4%B1z%C4%B1l%C4%B1rmak+Mah+1446+Cad+No+12+%C3%87ankaya+Ankara', 'mapLabel' => 'Yol tarifi al ↗' ),
					array( 'title' => 'İstanbul Ofis', 'address' => "Hamidiye Mah., Cendere Cad., No:21\nSeba Central A Blok, Kat:6, Daire:24\n34408 Kağıthane / İstanbul", 'phone' => '', 'map' => 'https://www.google.com/maps/search/?api=1&query=Seba+Central+Cendere+Cad+21+K%C3%A2%C4%9F%C4%B1thane', 'mapLabel' => 'Yol tarifi al ↗' ),
					array( 'title' => 'Fabrika', 'address' => "Seyran Mah. Yağlısu Mevkii Küme Evler\nNo: 3-4, 70400 Ermenek / Karaman", 'phone' => '0850 216 76 57', 'map' => 'https://www.google.com/maps/search/?api=1&query=Seyran+Mah+Ya%C4%9Fl%C4%B1su+Mevkii+Ermenek+Karaman', 'mapLabel' => 'Yol tarifi al ↗' ),
				),
				'copyright' => '© 2026 Pol\'s Gıda · Özünde iyilik var.',
				'socials' => array(
					array( 'label' => 'LinkedIn', 'url' => 'https://www.linkedin.com/company/polss' ),
					array( 'label' => 'YouTube', 'url' => 'https://www.youtube.com/channel/UCDVOf56bM8_xRs_LG5R2p7g' ),
					array( 'label' => 'Instagram', 'url' => 'https://www.instagram.com/polsgurme/' ),
				),
				'legal' => array(
					array( 'label' => 'KVKK', 'url' => '#' ),
					array( 'label' => 'Gizlilik Politikası', 'url' => '#' ),
					array( 'label' => 'Çerez Tercihleri', 'url' => '#' ),
					array( 'label' => 'Başa dön ↑', 'url' => '#top' ),
				),
			),
		),
	);

	return $s;
}

/** Freeze Fresh fruit cut-outs shipped with the theme (from polsgurme.com),
 *  with the ink colour used for the number printed over each fruit. */
function pols_fruits() {
	return array(
		'cilek'     => array( 'label' => 'Çilek', 'file' => 'fruit-cilek.webp', 'w' => 325, 'h' => 364, 'ink' => '#B4232A' ),
		'ahududu'   => array( 'label' => 'Ahududu', 'file' => 'fruit-ahududu.webp', 'w' => 270, 'h' => 294, 'ink' => '#C0395A' ),
		'bogurtlen' => array( 'label' => 'Böğürtlen', 'file' => 'fruit-bogurtlen.webp', 'w' => 257, 'h' => 332, 'ink' => '#3F2A4A' ),
		'mango'     => array( 'label' => 'Mango', 'file' => 'fruit-mango.webp', 'w' => 400, 'h' => 325, 'ink' => '#B8620A' ),
		'muz'       => array( 'label' => 'Muz', 'file' => 'fruit-muz.webp', 'w' => 356, 'h' => 352, 'ink' => '#7A5A1E' ),
		'ananas'    => array( 'label' => 'Ananas', 'file' => 'fruit-ananas.webp', 'w' => 400, 'h' => 390, 'ink' => '#8A6A14' ),
		'portakal'  => array( 'label' => 'Portakal', 'file' => 'fruit-portakal.webp', 'w' => 400, 'h' => 399, 'ink' => '#B4560A' ),
	);
}

/** Order of the fruits riding the journey route: one more fruit per stop passed. */
function pols_journey_fruits() {
	return array( 'cilek', 'ananas', 'bogurtlen', 'portakal', 'mango', 'muz' );
}

function pols_block_defaults( $slug ) {
	$s = pols_schema();
	return isset( $s[ $slug ] ) ? $s[ $slug ]['defaults'] : array();
}

/** Attribute definitions derived from the defaults' PHP types. */
function pols_block_attributes( $slug ) {
	$attrs = array();
	foreach ( pols_block_defaults( $slug ) as $key => $value ) {
		if ( is_array( $value ) ) {
			$type = 'array';
		} elseif ( is_int( $value ) ) {
			$type = 'integer';
		} elseif ( is_bool( $value ) ) {
			$type = 'boolean';
		} else {
			$type = 'string';
		}
		$attrs[ $key ] = array( 'type' => $type, 'default' => $value );
	}
	return $attrs;
}

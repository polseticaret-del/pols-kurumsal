<?php
/**
 * Görünüm → Pol's Kurulum
 *
 * One button that makes a fresh WordPress look like the approved prototype:
 *   1. imports /seed/media into the Media Library (idempotent, tagged _pols_seed)
 *   2. creates Polylang languages TR (default) + EN, if Polylang is active
 *   3. creates certificate logos and TR/EN catalogue cards
 *   4. creates the TR front page and its EN translation from the block schema
 *   5. creates TR/EN menus and assigns them to the "primary" location
 * Safe to run again: existing items are reused; pages are only overwritten when
 * the "reset" box is ticked.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Flush once more on the next request, after Polylang has loaded the new
   languages from scratch and registered its /en/ rules. */
add_action( 'init', function () {
	if ( get_option( 'pols_flush_rewrite' ) ) {
		delete_option( 'pols_flush_rewrite' );
		flush_rewrite_rules( false );
	}
}, 99 );

add_action( 'admin_menu', function () {
	add_theme_page( "Pol's Kurulum", "Pol's Kurulum", 'manage_options', 'pols-setup', 'pols_setup_page' );
} );

function pols_setup_page() {
	$log = array();
	if ( isset( $_POST['pols_setup'] ) && check_admin_referer( 'pols_setup' ) && current_user_can( 'manage_options' ) ) {
		$log = pols_run_setup( ! empty( $_POST['pols_reset'] ) );
	}
	?>
	<div class="wrap">
		<h1>Pol's Kurulum</h1>
		<p>Tema ile gelen görselleri ve videoları medya kütüphanesine aktarır; sertifika logolarını, katalog kartlarını, Türkçe ve İngilizce ana sayfaları ve menüleri oluşturur. Tekrar çalıştırmak güvenlidir.</p>
		<p><?php echo function_exists( 'pll_languages_list' ) ? '✅ Polylang etkin: TR ve EN birlikte kurulur.' : '⚠️ Polylang etkin değil: yalnızca Türkçe kurulur. İki dil için önce Polylang eklentisini etkinleştirin.'; ?></p>
		<form method="post">
			<?php wp_nonce_field( 'pols_setup' ); ?>
			<p><label><input type="checkbox" name="pols_reset" value="1"> Ana sayfaların içeriğini varsayılan içerikle <strong>sıfırla</strong> (yapılan düzenlemeler silinir)</label></p>
			<p><button class="button button-primary button-hero" name="pols_setup" value="1">Kurulumu çalıştır</button></p>
		</form>
		<?php if ( $log ) : ?>
			<h2>Sonuç</h2>
			<ul style="list-style:disc;padding-left:20px"><?php foreach ( $log as $l ) { echo '<li>' . esc_html( $l ) . '</li>'; } ?></ul>
		<?php endif; ?>
	</div>
	<?php
}

/* ---------------------------------------------------------------- run -- */

function pols_run_setup( $reset = false ) {
	@set_time_limit( 300 ); // phpcs:ignore
	$log = array();

	$media = pols_setup_media( $log );
	$langs = pols_setup_languages( $log );
	pols_setup_certs( $media, $log );
	pols_setup_catalogs( $langs, $log );
	$pages = pols_setup_pages( $media, $langs, $reset, $log );
	pols_setup_menus( $langs, $log );

	if ( ! empty( $pages['tr'] ) ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $pages['tr'] );
		$log[] = 'Ana sayfa ayarlandı (Ayarlar → Okuma).';
	}

	// New languages add /en/ rewrite rules and Polylang caches the front page
	// per language; both must be rebuilt or /en/ answers 404.
	if ( function_exists( 'PLL' ) && method_exists( PLL()->model, 'clean_languages_cache' ) ) {
		PLL()->model->clean_languages_cache();
	}
	delete_transient( 'pll_languages_list' );
	flush_rewrite_rules( false );
	update_option( 'pols_flush_rewrite', 1 );
	return $log;
}

/* -------------------------------------------------------------- media -- */

function pols_setup_media( &$log ) {
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';

	$map   = array();
	$dir   = POLS_DIR . '/seed/media/';
	$added = 0;
	foreach ( glob( $dir . '*' ) as $path ) {
		$file     = basename( $path );
		$existing = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'any', 'meta_key' => '_pols_seed', 'meta_value' => $file, 'fields' => 'ids', 'numberposts' => 1 ) );
		if ( $existing ) {
			$map[ $file ] = (int) $existing[0];
			continue;
		}
		$tmp = wp_tempnam( $file );
		copy( $path, $tmp );
		$id = media_handle_sideload( array( 'name' => $file, 'tmp_name' => $tmp ), 0 );
		if ( is_wp_error( $id ) ) {
			$log[] = 'Medya hatası (' . $file . '): ' . $id->get_error_message();
			@unlink( $tmp ); // phpcs:ignore
			continue;
		}
		update_post_meta( $id, '_pols_seed', $file );
		$map[ $file ] = (int) $id;
		$added++;
	}
	$log[] = sprintf( 'Medya: %d yeni dosya eklendi, toplam %d dosya hazır.', $added, count( $map ) );
	return $map;
}

/* ---------------------------------------------------------- languages -- */

function pols_setup_languages( &$log ) {
	if ( ! function_exists( 'PLL' ) || ! function_exists( 'pll_languages_list' ) ) {
		return array();
	}
	$have = pll_languages_list( array( 'fields' => 'slug' ) );
	$want = array(
		'tr' => array( 'name' => 'Türkçe', 'slug' => 'tr', 'locale' => 'tr_TR', 'rtl' => 0, 'term_group' => 0, 'flag' => 'tr' ),
		'en' => array( 'name' => 'English', 'slug' => 'en', 'locale' => 'en_US', 'rtl' => 0, 'term_group' => 1, 'flag' => 'us' ),
	);
	foreach ( $want as $slug => $args ) {
		if ( in_array( $slug, (array) $have, true ) ) {
			continue;
		}
		$model = PLL()->model;
		$res   = isset( $model->languages ) && method_exists( $model->languages, 'add' ) ? $model->languages->add( $args ) : ( method_exists( $model, 'add_language' ) ? $model->add_language( $args ) : null );
		$log[] = is_wp_error( $res ) ? 'Dil eklenemedi (' . $slug . '): ' . $res->get_error_message() : 'Dil eklendi: ' . $args['name'];
	}
	if ( method_exists( PLL()->model, 'clean_languages_cache' ) ) {
		PLL()->model->clean_languages_cache();
	}
	$opts = get_option( 'polylang' );
	if ( is_array( $opts ) ) {
		$opts['default_lang'] = 'tr';
		$opts['hide_default'] = 1;
		$opts['force_lang']   = 1;
		update_option( 'polylang', $opts );
	}
	return pll_languages_list( array( 'fields' => 'slug' ) );
}

function pols_set_lang( $post_id, $lang ) {
	if ( function_exists( 'pll_set_post_language' ) && $lang ) {
		pll_set_post_language( $post_id, $lang );
	}
}

/* ----------------------------------------------- certificates, catalogs -- */

function pols_setup_certs( $media, &$log ) {
	$n = 0;
	foreach ( pols_seed_certs() as $i => $title ) {
		$file   = $i;
		$exists = get_posts( array( 'post_type' => 'pols_sertifika', 'post_status' => 'any', 'meta_key' => '_pols_seed', 'meta_value' => $file, 'fields' => 'ids', 'numberposts' => 1 ) );
		if ( $exists ) {
			continue;
		}
		$id = wp_insert_post( array( 'post_type' => 'pols_sertifika', 'post_status' => 'publish', 'post_title' => $title, 'menu_order' => $n ) );
		if ( $id && ! empty( $media[ $file ] ) ) {
			set_post_thumbnail( $id, $media[ $file ] );
		}
		update_post_meta( $id, '_pols_seed', $file );
		$n++;
	}
	$log[] = sprintf( 'Sertifikalar: %d logo eklendi.', $n );
}

function pols_setup_catalogs( $langs, &$log ) {
	$langs = $langs ? $langs : array( 'tr' );
	$made  = array();
	foreach ( $langs as $lang ) {
		foreach ( pols_seed_catalogs( $lang ) as $i => $c ) {
			$key    = 'cat-' . $i . '-' . $lang;
			$exists = get_posts( array( 'post_type' => 'pols_katalog', 'post_status' => 'any', 'meta_key' => '_pols_seed', 'meta_value' => $key, 'fields' => 'ids', 'numberposts' => 1, 'lang' => '' ) );
			if ( $exists ) {
				$made[ $i ][ $lang ] = (int) $exists[0];
				continue;
			}
			$id = wp_insert_post( array( 'post_type' => 'pols_katalog', 'post_status' => 'publish', 'post_title' => $c['title'], 'post_excerpt' => $c['text'], 'menu_order' => $i ) );
			foreach ( array( '_pols_tag' => 'tag', '_pols_sub' => 'sub', '_pols_color' => 'color', '_pols_pdf' => 'pdf', '_pols_link_label' => 'linkLabel', '_pols_link_url' => 'linkUrl' ) as $meta => $k ) {
				update_post_meta( $id, $meta, $c[ $k ] );
			}
			update_post_meta( $id, '_pols_seed', $key );
			pols_set_lang( $id, $lang );
			$made[ $i ][ $lang ] = $id;
		}
	}
	if ( function_exists( 'pll_save_post_translations' ) ) {
		foreach ( $made as $pair ) {
			if ( count( $pair ) > 1 ) {
				pll_save_post_translations( $pair );
			}
		}
	}
	$log[] = 'Kataloglar hazır (' . implode( ', ', array_map( 'strtoupper', $langs ) ) . ').';
}

/* -------------------------------------------------------------- pages -- */

/** Fill media IDs into a block's attributes wherever a "<key>File" names a seed file. */
function pols_attach_ids( $attrs, $media ) {
	foreach ( $attrs as $k => $v ) {
		if ( is_array( $v ) ) {
			$attrs[ $k ] = array_map( function ( $item ) use ( $media ) {
				return is_array( $item ) ? pols_attach_ids( $item, $media ) : $item;
			}, $v );
		} elseif ( is_string( $v ) && substr( $k, -4 ) === 'File' ) {
			$id_key = substr( $k, 0, -4 );
			if ( ! empty( $media[ $v ] ) ) {
				$attrs[ $id_key ] = $media[ $v ];
			}
		}
	}
	return $attrs;
}

function pols_page_blocks( $lang, $media ) {
	$order = array( 'hero', 'about', 'values', 'field-intro', 'journey', 'scrub', 'freeze-dry', 'facts', 'certificates', 'catalogs', 'media', 'contact' );
	$en    = 'en' === $lang ? pols_en_content() : array();
	$html  = '';
	foreach ( $order as $slug ) {
		$attrs = pols_block_defaults( $slug );
		if ( isset( $en[ $slug ] ) ) {
			$attrs = array_replace( $attrs, $en[ $slug ] );
		}
		$attrs = pols_attach_ids( $attrs, $media );
		$html .= serialize_block( array( 'blockName' => 'pols/' . $slug, 'attrs' => $attrs, 'innerBlocks' => array(), 'innerHTML' => '', 'innerContent' => array() ) ) . "\n\n";
	}
	return $html;
}

function pols_setup_pages( $media, $langs, $reset, &$log ) {
	$langs = $langs ? $langs : array( 'tr' );
	$ids   = array();
	$title = array( 'tr' => 'Anasayfa', 'en' => 'Home' );
	foreach ( $langs as $lang ) {
		$opt = 'pols_front_' . $lang;
		$id  = (int) get_option( $opt );
		if ( $id && get_post( $id ) ) {
			if ( $reset ) {
				wp_update_post( array( 'ID' => $id, 'post_content' => wp_slash( pols_page_blocks( $lang, $media ) ) ) );
				$log[] = 'Sayfa sıfırlandı: ' . $title[ $lang ];
			}
		} else {
			$id = wp_insert_post( array(
				'post_type'    => 'page',
				'post_status'  => 'publish',
				'post_title'   => isset( $title[ $lang ] ) ? $title[ $lang ] : 'Home',
				'post_content' => wp_slash( pols_page_blocks( $lang, $media ) ),
			) );
			update_option( $opt, $id );
			$log[] = 'Sayfa oluşturuldu: ' . $title[ $lang ];
		}
		pols_set_lang( $id, $lang );
		$ids[ $lang ] = $id;
	}
	if ( function_exists( 'pll_save_post_translations' ) && count( $ids ) > 1 ) {
		pll_save_post_translations( $ids );
	}
	return $ids;
}

/* -------------------------------------------------------------- menus -- */

function pols_setup_menus( $langs, &$log ) {
	$langs = $langs ? $langs : array( 'tr' );
	$items = array(
		'tr' => array( 'Hakkımızda' => '#hakkimizda', 'Sözleşmeli Tarım' => '#sozlesmeli-tarim', 'Sürdürülebilirlik' => '#surdurulebilirlik', 'Freeze Dry' => '#freeze-dry', 'Ürünler' => '#urunler', 'İletişim' => '#iletisim' ),
		'en' => array( 'About' => '#about', 'Contract Farming' => '#contract-farming', 'Sustainability' => '#sustainability', 'Freeze Dry' => '#freeze-dry', 'Products' => '#products', 'Contact' => '#contact' ),
	);
	$menus = array();
	foreach ( $langs as $lang ) {
		$name = 'Ana menü (' . strtoupper( $lang ) . ')';
		$menu = wp_get_nav_menu_object( $name );
		$id   = $menu ? $menu->term_id : wp_create_nav_menu( $name );
		if ( ! $menu && ! is_wp_error( $id ) ) {
			$pos = 1;
			foreach ( $items[ $lang ] as $label => $url ) {
				wp_update_nav_menu_item( $id, 0, array( 'menu-item-title' => $label, 'menu-item-url' => $url, 'menu-item-type' => 'custom', 'menu-item-status' => 'publish', 'menu-item-position' => $pos++ ) );
			}
		}
		$menus[ $lang ] = $id;
	}
	$locations            = get_theme_mod( 'nav_menu_locations', array() );
	$locations['primary'] = $menus['tr'] ?? reset( $menus );
	set_theme_mod( 'nav_menu_locations', $locations );

	$opts = get_option( 'polylang' );
	if ( is_array( $opts ) && count( $menus ) > 1 ) {
		$opts['nav_menus'][ get_stylesheet() ]['primary'] = $menus;
		update_option( 'polylang', $opts );
	}
	$log[] = 'Menüler hazır (Görünüm → Menüler).';
}

/* --------------------------------------------------- English content ---
   Draft translation of the approved TR copy. Anchors are English so the EN
   menu reads naturally. Documentary titles stay Turkish (the films are). */

function pols_en_content() {
	return array(
		'hero' => array( 'anchor' => 'home', 'titleA' => 'We add value to', 'titleB' => 'the land we were born on.', 'motto' => '“Good food is everyone\'s right.”', 'mottoSub' => 'Ermenek, since 2017' ),
		'about' => array(
			'anchor' => 'about',
			'heading' => 'Good food is everyone\'s right.',
			'headingAccent' => 'We started with it in Ermenek.',
			'body1' => 'Focusing on the global transformation in food and agriculture, we were founded in 2017 in Ermenek, Karaman. Our aim is not only to produce high-quality food, but to build a sustainable future by supporting regional development.',
			'body2' => 'We closely follow evolving production technologies and consumer needs, and lead the sector with our R&D in functional food. We keep growing with confident steps to contribute to Türkiye\'s sustainable development goals.',
			'badges' => array(
				array( 'big' => '2017', 'label' => 'founded in Ermenek', 'color' => 'orange-btn' ),
				array( 'big' => '80%', 'label' => 'women employees', 'color' => 'forest' ),
				array( 'big' => '1.000+', 'label' => 'farmers we work with', 'color' => 'peach' ),
				array( 'big' => '28', 'label' => 'export countries', 'color' => 'berry' ),
				array( 'big' => 'Purchase guarantee', 'label' => 'for our contract farmers', 'color' => 'green-mid' ),
				array( 'big' => 'Freeze dry', 'label' => 'freeze-dried in Ermenek', 'color' => 'orange' ),
			),
		),
		'values' => array(
			'anchor' => 'values',
			'label' => 'Our values',
			'items' => array(
				array( 'title' => 'Women\'s work', 'text' => '80% of our team are women. The inspiration we draw from this land is shaped, once again, by women\'s hands.' ),
				array( 'title' => 'Regional development', 'text' => 'We give local farmers regular agricultural training and strengthen local employment through controlled farming. Naturally.' ),
				array( 'title' => 'Contract farming', 'text' => 'We agree with our farmers every year and leave nothing to chance on the way from field to table.' ),
			),
		),
		'field-intro' => array( 'anchor' => 'contract-farming', 'text' => 'It all starts in a field.' ),
		'journey' => array(
			'anchor' => 'journey',
			'heading' => 'Trust from field to table.',
			'intro' => 'From day one we have secured our quality with the Contract Farming model. Let\'s follow a strawberry\'s journey together.',
			'stops' => array(
				array( 'title' => 'Agreement', 'text' => 'Before planting we sign a yearly agreement with our farmer and guarantee the purchase. Unplanned production stops here.', 'imageFile' => '11-anlasma.webp', 'image' => 0, 'alt' => 'Two farmers shaking hands at the edge of a strawberry field' ),
				array( 'title' => 'Training', 'text' => 'Our agricultural engineers are in the field from planting to harvest. Proper fertilising and spraying protect the soil and water.', 'imageFile' => '12-egitim.webp', 'image' => 0, 'alt' => 'Hands checking the soil between strawberry rows' ),
				array( 'title' => 'Harvest', 'text' => 'Our farmers\' work is protected, and raw material reaches our plant to international standards.', 'imageFile' => '13-hasat.webp', 'image' => 0, 'alt' => 'Women harvesting strawberries in the field' ),
				array( 'title' => 'Production', 'text' => 'At our plant in Ermenek we produce with a team that is 80% women, in a sustainable model for the local community.', 'imageFile' => '14-uretim.webp', 'image' => 0, 'alt' => 'Gloved hands sorting strawberries on the line' ),
				array( 'title' => 'Table', 'text' => 'From the shelf to your table; natural and trustworthy. The journey ends at your table.', 'imageFile' => '15-sofra.webp', 'image' => 0, 'alt' => 'Freeze-dried fruit, jam and halva on a wooden table' ),
			),
			'note' => 'Five stops, one promise:',
			'noteAccent' => 'we leave quality to no chance.',
		),
		'scrub' => array( 'anchor' => 'sustainability', 'heading' => 'We measure the footprint we leave.', 'text' => 'We calculate our corporate carbon footprint and protect our soil and water resources by applying proper fertilising and spraying with our contract farmers.' ),
		'freeze-dry' => array(
			'anchor' => 'freeze-dry',
			'eyebrow' => 'Freeze Dry',
			'heading' => 'The fruit itself.',
			'headingAccent' => 'Just without the water.',
			'steps' => array(
				array( 'title' => 'Harvest', 'text' => 'Picked with care at full ripeness from our contract orchards.', 'imageFile' => '21-fd-hasat.webp', 'image' => 0, 'alt' => 'Women picking strawberries in the field' ),
				array( 'title' => 'Washing and sorting', 'text' => 'Washed at our plant in Ermenek and sorted one by one by our team.', 'imageFile' => '22-fd-yikama.webp', 'image' => 0, 'alt' => 'Strawberries passing under water on the washing line' ),
				array( 'title' => 'Quick freezing (IQF)', 'text' => 'Each piece is frozen individually and fast, so the fruit keeps its texture and shape.', 'imageFile' => '23-fd-iqf.webp', 'image' => 0, 'alt' => 'Individually frozen, frosted strawberries' ),
				array( 'title' => 'Vacuum drying', 'text' => 'Laid on trays and dried in vacuum chambers. The ice turns straight into vapour without ever melting.', 'imageFile' => '24-fd-kurutma.webp', 'image' => 0, 'alt' => 'Strawberry trays loaded into a freeze-dry chamber' ),
				array( 'title' => 'Packing', 'text' => 'Packed in moisture-proof pouches, with no added sugar and no additives.', 'imageFile' => '25-fd-paket.webp', 'image' => 0, 'alt' => 'Freeze-dried strawberry slices filled into Pol\'s Freeze Fresh pouches' ),
			),
			'meterLabel' => 'Water in the strawberry',
			'note' => 'A fresh strawberry is about 91% water. After drying 1–4% moisture remains; colour, aroma and shape stay.',
		),
		'facts' => array(
			'anchor' => 'freeze-dry-facts',
			'items' => array(
				array( 'big' => '97%', 'label' => 'of the fruit\'s own qualities preserved' ),
				array( 'big' => '4.000 m²', 'label' => 'enclosed production plant in Ermenek' ),
				array( 'big' => 'Additive-free', 'label' => 'no added sugar, a natural snack' ),
			),
			'line' => 'We are one of the few production plants in Türkiye using freeze-dry technology.',
		),
		'certificates' => array( 'anchor' => 'certificates', 'heading' => 'Certified production to international standards.', 'countLabel' => 'certificates and memberships' ),
		'catalogs' => array( 'anchor' => 'products', 'heading' => 'Our catalogues', 'intro' => 'Up-to-date catalogues prepared separately for industrial producers and retail.' ),
		'media' => array(
			'anchor' => 'media',
			'heading' => 'News from us',
			'filmLabel' => 'Watch our commercial on YouTube',
			'episodes' => array(
				array( 'title' => 'Bağ Bahçe Burada, Bağımız da Burayla!', 'meta' => 'Hasat Zamanı (TR) · 10:19', 'url' => 'https://www.youtube.com/watch?v=-ZtSJUWMtfs' ),
				array( 'title' => 'Yatırımlarımız Meyvesini Veriyor', 'meta' => 'Hasat Zamanı (TR) · 9:27', 'url' => 'https://www.youtube.com/watch?v=3YKnyp4ryXc' ),
				array( 'title' => 'Burası Kadınların!', 'meta' => 'Hasat Zamanı (TR) · 9:16', 'url' => 'https://www.youtube.com/watch?v=uuTnbJ-FTIs' ),
				array( 'title' => 'Miras; Geleceğe Bıraktığımız Değer', 'meta' => 'Hasat Zamanı (TR) · 8:34', 'url' => 'https://www.youtube.com/watch?v=lDpNwANNYyU' ),
			),
		),
		'contact' => array(
			'anchor' => 'contact',
			'heading' => 'Just say hello.',
			'copyLabel' => 'Copy',
			'locations' => array(
				array( 'title' => 'Head office', 'address' => "Kızılırmak Mah., 1446. Cad., No:12/19\nÇankaya / Ankara, Türkiye", 'phone' => '+90 312 287 76 57', 'map' => 'https://www.google.com/maps/search/?api=1&query=K%C4%B1z%C4%B1l%C4%B1rmak+Mah+1446+Cad+No+12+%C3%87ankaya+Ankara', 'mapLabel' => 'Get directions ↗' ),
				array( 'title' => 'Istanbul office', 'address' => "Hamidiye Mah., Cendere Cad., No:21\nSeba Central A Blok, Kat:6, Daire:24\nKağıthane / İstanbul, Türkiye", 'phone' => '', 'map' => 'https://www.google.com/maps/search/?api=1&query=Seba+Central+Cendere+Cad+21+K%C3%A2%C4%9F%C4%B1thane', 'mapLabel' => 'Get directions ↗' ),
				array( 'title' => 'Factory', 'address' => "Seyran Mah. Yağlısu Mevkii Küme Evler\nNo: 3-4, 70400 Ermenek / Karaman, Türkiye", 'phone' => '+90 850 216 76 57', 'map' => 'https://www.google.com/maps/search/?api=1&query=Seyran+Mah+Ya%C4%9Fl%C4%B1su+Mevkii+Ermenek+Karaman', 'mapLabel' => 'Get directions ↗' ),
			),
			'copyright' => '© 2026 Pol\'s Gıda · Good food is everyone\'s right.',
			'legal' => array(
				array( 'label' => 'Privacy notice (KVKK)', 'url' => '#' ),
				array( 'label' => 'Privacy policy', 'url' => '#' ),
				array( 'label' => 'Cookie preferences', 'url' => '#' ),
				array( 'label' => 'Back to top ↑', 'url' => '#top' ),
			),
		),
	);
}

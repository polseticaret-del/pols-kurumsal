<?php
/**
 * Görünüm → Pol's Kurulum
 *
 * One button that makes a fresh WordPress look like the approved prototype:
 *   1. imports /seed/media into the Media Library (idempotent, tagged _pols_seed)
 *   2. creates Polylang languages TR (default) + EN, if Polylang is active
 *   3. creates certificate logos and TR/EN catalogue cards
 *   4. creates the TR front page and its EN translation from the block schema
 *   5. creates TR/EN menus and assigns them to the "primary" location
 * Safe to run again: existing items are reused; pages are only overwritten when
 * the "reset" box is ticked.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Flush once more on the next request, after Polylang has loaded the new
   languages from scratch and registered its /en/ rules. */
add_action( 'init', function () {
	if ( get_option( 'pols_flush_rewrite' ) ) {
		delete_option( 'pols_flush_rewrite' );
		flush_rewrite_rules( false );
	}
}, 99 );

add_action( 'admin_menu', function () {
	add_theme_page( "Pol's Kurulum", "Pol's Kurulum", 'manage_options', 'pols-setup', 'pols_setup_page' );
} );

function pols_setup_page() {
	$log = array();
	if ( isset( $_POST['pols_setup'] ) && check_admin_referer( 'pols_setup' ) && current_user_can( 'manage_options' ) ) {
		$log = pols_run_setup( ! empty( $_POST['pols_reset'] ) );
	}
	?>
	<div class="wrap">
		<h1>Pol's Kurulum</h1>
		<p>Tema ile gelen görselleri ve videoları medya kütüphanesine aktarır; sertifika logolarını, katalog kartlarını, Türkçe ve İngilizce ana sayfaları ve menüleri oluşturur. Tekrar çalıştırmak güvenlidir.</p>
		<p><?php echo function_exists( 'pll_languages_list' ) ? '✅ Polylang etkin: TR ve EN birlikte kurulur.' : '⚠️ Polylang etkin değil: yalnızca Türkçe kurulur. İki dil için önce Polylang eklentisini etkinleştirin.'; ?></p>
		<form method="post">
			<?php wp_nonce_field( 'pols_setup' ); ?>
			<p><label><input type="checkbox" name="pols_reset" value="1"> Ana sayfaların içeriğini varsayılan içerikle <strong>sıfırla</strong> (yapılan düzenlemeler silinir)</label></p>
			<p><button class="button button-primary button-hero" name="pols_setup" value="1">Kurulumu çalıştır</button></p>
		</form>
		<?php if ( $log ) : ?>
			<h2>Sonuç</h2>
			<ul style="list-style:disc;padding-left:20px"><?php foreach ( $log as $l ) { echo '<li>' . esc_html( $l ) . '</li>'; } ?></ul>
		<?php endif; ?>
	</div>
	<?php
}

/* ---------------------------------------------------------------- run -- */

function pols_run_setup( $reset = false ) {
	@set_time_limit( 300 ); // phpcs:ignore
	$log = array();

	$media = pols_setup_media( $log );
	$langs = pols_setup_languages( $log );
	pols_setup_certs( $media, $log );
	pols_setup_catalogs( $langs, $log );
	$pages = pols_setup_pages( $media, $langs, $reset, $log );
	pols_setup_menus( $langs, $log );

	if ( ! empty( $pages['tr'] ) ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $pages['tr'] );
		$log[] = 'Ana sayfa ayarlandı (Ayarlar → Okuma).';
	}

	// New languages add /en/ rewrite rules and Polylang caches the front page
	// per language; both must be rebuilt or /en/ answers 404.
	if ( function_exists( 'PLL' ) && method_exists( PLL()->model, 'clean_languages_cache' ) ) {
		PLL()->model->clean_languages_cache();
	}
	delete_transient( 'pll_languages_list' );
	flush_rewrite_rules( false );
	update_option( 'pols_flush_rewrite', 1 );
	return $log;
}

/* -------------------------------------------------------------- media -- */

function pols_setup_media( &$log ) {
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';

	$map   = array();
	$dir   = POLS_DIR . '/seed/media/';
	$added = 0;
	foreach ( glob( $dir . '*' ) as $path ) {
		$file     = basename( $path );
		$existing = get_posts( array( 'post_type' => 'attachment', 'post_status' => 'any', 'meta_key' => '_pols_seed', 'meta_value' => $file, 'fields' => 'ids', 'numberposts' => 1 ) );
		if ( $existing ) {
			$map[ $file ] = (int) $existing[0];
			continue;
		}
		$tmp = wp_tempnam( $file );
		copy( $path, $tmp );
		$id = media_handle_sideload( array( 'name' => $file, 'tmp_name' => $tmp ), 0 );
		if ( is_wp_error( $id ) ) {
			$log[] = 'Medya hatası (' . $file . '): ' . $id->get_error_message();
			@unlink( $tmp ); // phpcs:ignore
			continue;
		}
		update_post_meta( $id, '_pols_seed', $file );
		$map[ $file ] = (int) $id;
		$added++;
	}
	$log[] = sprintf( 'Medya: %d yeni dosya eklendi, toplam %d dosya hazır.', $added, count( $map ) );
	return $map;
}

/* ---------------------------------------------------------- languages -- */

function pols_setup_languages( &$log ) {
	if ( ! function_exists( 'PLL' ) || ! function_exists( 'pll_languages_list' ) ) {
		return array();
	}
	$have = pll_languages_list( array( 'fields' => 'slug' ) );
	$want = array(
		'tr' => array( 'name' => 'Türkçe', 'slug' => 'tr', 'locale' => 'tr_TR', 'rtl' => 0, 'term_group' => 0, 'flag' => 'tr' ),
		'en' => array( 'name' => 'English', 'slug' => 'en', 'locale' => 'en_US', 'rtl' => 0, 'term_group' => 1, 'flag' => 'us' ),
	);
	foreach ( $want as $slug => $args ) {
		if ( in_array( $slug, (array) $have, true ) ) {
			continue;
		}
		$model = PLL()->model;
		$res   = isset( $model->languages ) && method_exists( $model->languages, 'add' ) ? $model->languages->add( $args ) : ( method_exists( $model, 'add_language' ) ? $model->add_language( $args ) : null );
		$log[] = is_wp_error( $res ) ? 'Dil eklenemedi (' . $slug . '): ' . $res->get_error_message() : 'Dil eklendi: ' . $args['name'];
	}
	if ( method_exists( PLL()->model, 'clean_languages_cache' ) ) {
		PLL()->model->clean_languages_cache();
	}
	$opts = get_option( 'polylang' );
	if ( is_array( $opts ) ) {
		$opts['default_lang'] = 'tr';
		$opts['hide_default'] = 1;
		$opts['force_lang']   = 1;
		update_option( 'polylang', $opts );
	}
	return pll_languages_list( array( 'fields' => 'slug' ) );
}

function pols_set_lang( $post_id, $lang ) {
	if ( function_exists( 'pll_set_post_language' ) && $lang ) {
		pll_set_post_language( $post_id, $lang );
	}
}

/* ----------------------------------------------- certificates, catalogs -- */

function pols_setup_certs( $media, &$log ) {
	$n = 0;
	foreach ( pols_seed_certs() as $i => $title ) {
		$file   = $i;
		$exists = get_posts( array( 'post_type' => 'pols_sertifika', 'post_status' => 'any', 'meta_key' => '_pols_seed', 'meta_value' => $file, 'fields' => 'ids', 'numberposts' => 1 ) );
		if ( $exists ) {
			continue;
		}
		$id = wp_insert_post( array( 'post_type' => 'pols_sertifika', 'post_status' => 'publish', 'post_title' => $title, 'menu_order' => $n ) );
		if ( $id && ! empty( $media[ $file ] ) ) {
			set_post_thumbnail( $id, $media[ $file ] );
		}
		update_post_meta( $id, '_pols_seed', $file );
		$n++;
	}
	$log[] = sprintf( 'Sertifikalar: %d logo eklendi.', $n );
}

function pols_setup_catalogs( $langs, &$log ) {
	$langs = $langs ? $langs : array( 'tr' );
	$made  = array();
	foreach ( $langs as $lang ) {
		foreach ( pols_seed_catalogs( $lang ) as $i => $c ) {
			$key    = 'cat-' . $i . '-' . $lang;
			$exists = get_posts( array( 'post_type' => 'pols_katalog', 'post_status' => 'any', 'meta_key' => '_pols_seed', 'meta_value' => $key, 'fields' => 'ids', 'numberposts' => 1, 'lang' => '' ) );
			if ( $exists ) {
				$made[ $i ][ $lang ] = (int) $exists[0];
				continue;
			}
			$id = wp_insert_post( array( 'post_type' => 'pols_katalog', 'post_status' => 'publish', 'post_title' => $c['title'], 'post_excerpt' => $c['text'], 'menu_order' => $i ) );
			foreach ( array( '_pols_tag' => 'tag', '_pols_sub' => 'sub', '_pols_lede' => 'lede', '_pols_color' => 'color', '_pols_pdf' => 'pdf', '_pols_link_label' => 'linkLabel', '_pols_link_url' => 'linkUrl' ) as $meta => $k ) {
				update_post_meta( $id, $meta, $c[ $k ] );
			}
			update_post_meta( $id, '_pols_seed', $key );
			pols_set_lang( $id, $lang );
			$made[ $i ][ $lang ] = $id;
		}
	}
	if ( function_exists( 'pll_save_post_translations' ) ) {
		foreach ( $made as $pair ) {
			if ( count( $pair ) > 1 ) {
				pll_save_post_translations( $pair );
			}
		}
	}
	$log[] = 'Kataloglar hazır (' . implode( ', ', array_map( 'strtoupper', $langs ) ) . ').';
}

/* -------------------------------------------------------------- pages -- */

/** Fill media IDs into a block's attributes wherever a "<key>File" names a seed file. */
function pols_attach_ids( $attrs, $media ) {
	foreach ( $attrs as $k => $v ) {
		if ( is_array( $v ) ) {
			$attrs[ $k ] = array_map( function ( $item ) use ( $media ) {
				return is_array( $item ) ? pols_attach_ids( $item, $media ) : $item;
			}, $v );
		} elseif ( is_string( $v ) && substr( $k, -4 ) === 'File' ) {
			$id_key = substr( $k, 0, -4 );
			if ( ! empty( $media[ $v ] ) ) {
				$attrs[ $id_key ] = $media[ $v ];
			}
		}
	}
	return $attrs;
}

function pols_page_blocks( $lang, $media ) {
	$order = array( 'hero', 'about', 'values', 'field-intro', 'journey', 'scrub', 'freeze-dry', 'facts', 'certificates', 'catalogs', 'media', 'contact' );
	$en    = 'en' === $lang ? pols_en_content() : array();
	$html  = '';
	foreach ( $order as $slug ) {
		$attrs = pols_block_defaults( $slug );
		if ( isset( $en[ $slug ] ) ) {
			$attrs = array_replace( $attrs, $en[ $slug ] );
		}
		$attrs = pols_attach_ids( $attrs, $media );
		$html .= serialize_block( array( 'blockName' => 'pols/' . $slug, 'attrs' => $attrs, 'innerBlocks' => array(), 'innerHTML' => '', 'innerContent' => array() ) ) . "\n\n";
	}
	return $html;
}

function pols_setup_pages( $media, $langs, $reset, &$log ) {
	$langs = $langs ? $langs : array( 'tr' );
	$ids   = array();
	$title = array( 'tr' => 'Anasayfa', 'en' => 'Home' );
	foreach ( $langs as $lang ) {
		$opt = 'pols_front_' . $lang;
		$id  = (int) get_option( $opt );
		if ( $id && get_post( $id ) ) {
			if ( $reset ) {
				wp_update_post( array( 'ID' => $id, 'post_content' => wp_slash( pols_page_blocks( $lang, $media ) ) ) );
				$log[] = 'Sayfa sıfırlandı: ' . $title[ $lang ];
			}
		} else {
			$id = wp_insert_post( array(
				'post_type'    => 'page',
				'post_status'  => 'publish',
				'post_title'   => isset( $title[ $lang ] ) ? $title[ $lang ] : 'Home',
				'post_content' => wp_slash( pols_page_blocks( $lang, $media ) ),
			) );
			update_option( $opt, $id );
			$log[] = 'Sayfa oluşturuldu: ' . $title[ $lang ];
		}
		pols_set_lang( $id, $lang );
		$ids[ $lang ] = $id;
	}
	if ( function_exists( 'pll_save_post_translations' ) && count( $ids ) > 1 ) {
		pll_save_post_translations( $ids );
	}
	return $ids;
}

/* -------------------------------------------------------------- menus -- */

function pols_setup_menus( $langs, &$log ) {
	$langs = $langs ? $langs : array( 'tr' );
	$items = array(
		'tr' => array( 'Hakkımızda' => '#hakkimizda', 'Sözleşmeli Tarım' => '#sozlesmeli-tarim', 'Sürdürülebilirlik' => '#surdurulebilirlik', 'Freeze Dry Nedir' => '#freeze-dry', 'Ürünler' => '#urunler', 'İletişim' => '#iletisim' ),
		'en' => array( 'About' => '#about', 'Contract Farming' => '#contract-farming', 'Sustainability' => '#sustainability', 'What is Freeze Dry' => '#freeze-dry', 'Products' => '#products', 'Contact' => '#contact' ),
	);
	$menus = array();
	foreach ( $langs as $lang ) {
		$name = 'Ana menü (' . strtoupper( $lang ) . ')';
		$menu = wp_get_nav_menu_object( $name );
		$id   = $menu ? $menu->term_id : wp_create_nav_menu( $name );
		if ( ! $menu && ! is_wp_error( $id ) ) {
			$pos = 1;
			foreach ( $items[ $lang ] as $label => $url ) {
				wp_update_nav_menu_item( $id, 0, array( 'menu-item-title' => $label, 'menu-item-url' => $url, 'menu-item-type' => 'custom', 'menu-item-status' => 'publish', 'menu-item-position' => $pos++ ) );
			}
		}
		$menus[ $lang ] = $id;
	}
	$locations            = get_theme_mod( 'nav_menu_locations', array() );
	$locations['primary'] = $menus['tr'] ?? reset( $menus );
	set_theme_mod( 'nav_menu_locations', $locations );

	$opts = get_option( 'polylang' );
	if ( is_array( $opts ) && count( $menus ) > 1 ) {
		$opts['nav_menus'][ get_stylesheet() ]['primary'] = $menus;
		update_option( 'polylang', $opts );
	}
	$log[] = 'Menüler hazır (Görünüm → Menüler).';
}

/* English page copy lives in inc/en-content.php. */

<?php
/**
 * Content types edited by marketing without touching the page:
 *   Kataloglar  (pols_katalog)    card title, tag, sub line, text, colour, PDF, shop link
 *   Sertifikalar (pols_sertifika) one logo each (featured image), order = menu order
 * Catalogues are translatable in Polylang; certificate logos are shared.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'init', function () {
	register_post_type( 'pols_katalog', array(
		'labels'       => array( 'name' => 'Kataloglar', 'singular_name' => 'Katalog', 'add_new_item' => 'Yeni katalog', 'edit_item' => 'Kataloğu düzenle' ),
		'public'       => false,
		'show_ui'      => true,
		'show_in_rest' => true,
		'menu_icon'    => 'dashicons-book-alt',
		'supports'     => array( 'title', 'excerpt', 'thumbnail', 'page-attributes', 'custom-fields' ),
		'menu_position' => 21,
	) );
	register_post_type( 'pols_sertifika', array(
		'labels'       => array( 'name' => 'Sertifikalar', 'singular_name' => 'Sertifika', 'add_new_item' => 'Yeni sertifika logosu', 'edit_item' => 'Sertifikayı düzenle', 'featured_image' => 'Logo', 'set_featured_image' => 'Logoyu seç' ),
		'public'       => false,
		'show_ui'      => true,
		'show_in_rest' => true,
		'menu_icon'    => 'dashicons-awards',
		'supports'     => array( 'title', 'thumbnail', 'page-attributes' ),
		'menu_position' => 22,
	) );
	foreach ( array( '_pols_tag', '_pols_sub', '_pols_lede', '_pols_color', '_pols_pdf', '_pols_link_label', '_pols_link_url' ) as $k ) {
		register_post_meta( 'pols_katalog', $k, array( 'type' => 'string', 'single' => true, 'show_in_rest' => true, 'auth_callback' => function () { return current_user_can( 'edit_posts' ); } ) );
	}
} );

/* Polylang: catalogues follow the page language, logos do not. */
add_filter( 'pll_get_post_types', function ( $types, $is_settings ) {
	$types['pols_katalog'] = 'pols_katalog';
	unset( $types['pols_sertifika'] );
	return $types;
}, 10, 2 );

/* ---------------------------------------------------- catalogue fields -- */

add_action( 'add_meta_boxes', function () {
	add_meta_box( 'pols_katalog_fields', 'Kart bilgileri', 'pols_katalog_box', 'pols_katalog', 'normal', 'high' );
} );

function pols_katalog_box( $post ) {
	wp_nonce_field( 'pols_katalog', 'pols_katalog_nonce' );
	$v = function ( $k ) use ( $post ) { return esc_attr( get_post_meta( $post->ID, $k, true ) ); };
	$colors = array( 'forest' => 'Orman yeşili (B2B)', 'orange' => 'Turuncu (Freeze Fresh)', 'berry' => 'Vişne (Gurme)' );
	?>
	<p style="color:#555">Kart başlığı = yazı başlığı · Kart metni = "Özet" · Kapak görseli (isteğe bağlı) = "Öne çıkan görsel" · Sıra = "Sayfa özellikleri → Sıra".</p>
	<table class="form-table" role="presentation">
		<tr><th><label for="pols_tag">Etiket</label></th><td><input class="regular-text" id="pols_tag" name="_pols_tag" value="<?php echo $v( '_pols_tag' ); // phpcs:ignore ?>" placeholder="ENDÜSTRİYEL · B2B"></td></tr>
		<tr><th><label for="pols_lede">Slogan (kartın altında, kalın)</label></th><td><input class="regular-text" id="pols_lede" name="_pols_lede" value="<?php echo $v( '_pols_lede' ); // phpcs:ignore ?>" placeholder="Profesyonel çözümler sunuyoruz."></td></tr>
		<tr><th><label for="pols_sub">Kapak alt satırı</label></th><td><input class="regular-text" id="pols_sub" name="_pols_sub" value="<?php echo $v( '_pols_sub' ); // phpcs:ignore ?>" placeholder="Perakende kataloğu"></td></tr>
		<tr><th><label for="pols_color">Kapak rengi</label></th><td><select id="pols_color" name="_pols_color">
			<?php foreach ( $colors as $k => $label ) : ?>
				<option value="<?php echo esc_attr( $k ); ?>" <?php selected( get_post_meta( $post->ID, '_pols_color', true ), $k ); ?>><?php echo esc_html( $label ); ?></option>
			<?php endforeach; ?>
		</select></td></tr>
		<tr><th><label for="pols_pdf">PDF dosyası</label></th><td>
			<input class="regular-text" id="pols_pdf" name="_pols_pdf" value="<?php echo $v( '_pols_pdf' ); // phpcs:ignore ?>" placeholder="Boşsa kartta “PDF yakında” görünür">
			<button type="button" class="button" id="pols_pdf_pick">Medya'dan seç</button>
		</td></tr>
		<tr><th><label for="pols_ll">Bağlantı yazısı</label></th><td><input class="regular-text" id="pols_ll" name="_pols_link_label" value="<?php echo $v( '_pols_link_label' ); // phpcs:ignore ?>" placeholder="polsgurme.com'da satın al ↗"></td></tr>
		<tr><th><label for="pols_lu">Bağlantı adresi</label></th><td><input class="regular-text" id="pols_lu" name="_pols_link_url" value="<?php echo $v( '_pols_link_url' ); // phpcs:ignore ?>" placeholder="https://www.polsgurme.com veya mailto:…"></td></tr>
	</table>
	<script>
	(function () {
		var b = document.getElementById('pols_pdf_pick');
		if (!b || !window.wp || !wp.media) return;
		b.addEventListener('click', function () {
			var f = wp.media({ title: 'Katalog PDF', library: { type: 'application/pdf' }, multiple: false });
			f.on('select', function () { document.getElementById('pols_pdf').value = f.state().get('selection').first().get('url'); });
			f.open();
		});
	})();
	</script>
	<?php
}

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	$screen = get_current_screen();
	if ( $screen && 'pols_katalog' === $screen->post_type ) {
		wp_enqueue_media();
	}
} );

add_action( 'save_post_pols_katalog', function ( $post_id ) {
	if ( ! isset( $_POST['pols_katalog_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['pols_katalog_nonce'] ), 'pols_katalog' ) ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}
	foreach ( array( '_pols_tag', '_pols_sub', '_pols_lede', '_pols_color', '_pols_link_label' ) as $k ) {
		if ( isset( $_POST[ $k ] ) ) {
			update_post_meta( $post_id, $k, sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) );
		}
	}
	foreach ( array( '_pols_pdf', '_pols_link_url' ) as $k ) {
		if ( isset( $_POST[ $k ] ) ) {
			update_post_meta( $post_id, $k, esc_url_raw( wp_unslash( $_POST[ $k ] ) ) );
		}
	}
} );

/* ------------------------------------------------------- seed content -- */

// Current certificates (Pol's, 2026-09-30).
function pols_seed_certs() {
	return array(
		'cert-tse-iso9001.png'      => 'TSE ISO EN 9001',
		'cert-tse-fssc22000.png'    => 'TSE FSSC 22000 ISO/TS 22002-1',
		'cert-brcgs.png'            => 'BRCGS Food Safety',
		'cert-iso14064.png'         => 'ISO 14064',
		'cert-registrar-corp.png'   => 'Registrar Corp',
		'cert-ou-kosher.png'        => 'OU Kosher',
		'cert-halal-gimdes.png'     => 'GİMDES Helal',
		'cert-tse.png'              => 'TSE',
		'cert-v-label-vegan.png'    => 'V-Label Vegan',
	);
}

function pols_seed_catalogs( $lang = 'tr' ) {
	// Copy: Pol's content brief, 2026-10-08.
	if ( 'en' === $lang ) {
		return array(
			array( 'title' => 'Industrial Products', 'sub' => 'Industrial Products Catalogue', 'tag' => 'INDUSTRIAL · B2B', 'lede' => 'Professional solutions.', 'text' => 'With its frozen products, Pol’s offers practical, high-quality and reliable solutions for the fruit, vegetable and other needs of the food industry as well as HORECA and catering businesses.', 'color' => 'forest', 'pdf' => '', 'linkLabel' => 'Write to us for bulk orders', 'linkUrl' => 'mailto:info@pols.com.tr?subject=Bulk%20order', 'cover' => '' ),
			array( 'title' => "Pol's Freeze Fresh", 'sub' => 'Retail catalogue', 'tag' => 'RETAIL', 'lede' => 'We freeze the fruit and keep it fresh.', 'text' => 'With freeze-drying, we first freeze the fruit and then remove its water under vacuum, without heating it. The fruit keeps most of its shape, aroma and natural properties, and becomes light, crunchy and convenient.', 'color' => 'orange', 'pdf' => '', 'linkLabel' => 'Buy at polsgurme.com ↗', 'linkUrl' => 'https://www.polsgurme.com', 'cover' => '' ),
			array( 'title' => "Pol's Gourmet", 'sub' => 'Retail catalogue', 'tag' => 'RETAIL', 'lede' => 'A modern touch on traditional flavours.', 'text' => 'Halva, tahini, jams, creams and spreads: Pol’s Gourmet brings carefully selected ingredients and distinctive flavours together. From tahini made with locally grown sesame to products with a geographical indication, our range brings traditional tastes to the table.', 'color' => 'berry', 'pdf' => '', 'linkLabel' => 'Buy at polsgurme.com ↗', 'linkUrl' => 'https://www.polsgurme.com', 'cover' => '' ),
		);
	}
	return array(
		array( 'title' => 'Endüstriyel Ürünler', 'sub' => 'Endüstriyel Ürünler Kataloğu', 'tag' => 'ENDÜSTRİYEL · B2B', 'lede' => 'Profesyonel çözümler sunuyoruz.', 'text' => "Pol's, dondurulmuş ürünleriyle gıda endüstrisinin yanı sıra HORECA ve catering işletmelerinin meyve, sebze ve diğer ihtiyaçlarına pratik, kaliteli ve güvenilir çözümler sunuyor.", 'color' => 'forest', 'pdf' => '', 'linkLabel' => 'Toplu alım için yazın', 'linkUrl' => 'mailto:info@pols.com.tr?subject=Toplu%20al%C4%B1m', 'cover' => '' ),
		array( 'title' => "Pol's Freeze Fresh", 'sub' => 'Perakende kataloğu', 'tag' => 'PERAKENDE', 'lede' => 'Meyveyi donduruyor, tazeliğini koruyoruz.', 'text' => 'Freeze dried teknolojisinde meyveleri önce donduruyor, ardından vakum altında suyunu ısıtmadan uzaklaştırıyoruz. Böylece meyvenin şekli, aroması ve doğal özellikleri büyük ölçüde korunurken hafif, çıtır ve pratik meyveler elde ediyoruz.', 'color' => 'orange', 'pdf' => '', 'linkLabel' => "polsgurme.com'da satın al ↗", 'linkUrl' => 'https://www.polsgurme.com', 'cover' => '' ),
		array( 'title' => "Pol's Gurme", 'sub' => 'Perakende kataloğu', 'tag' => 'PERAKENDE', 'lede' => 'Geleneksel lezzetlere modern bir dokunuş.', 'text' => "Helva, tahin, reçel, krema ve sürülebilir ürünlerden oluşan Pol's Gurme; özenle seçilen hammaddeleri ve özgün lezzetleri bir araya getiriyor. Yerli susamdan üretilen tahinlerden coğrafi işaretli ürünlere uzanan seçkimizle geleneksel tatları sofralara taşıyoruz.", 'color' => 'berry', 'pdf' => '', 'linkLabel' => "polsgurme.com'da satın al ↗", 'linkUrl' => 'https://www.polsgurme.com', 'cover' => '' ),
	);
}

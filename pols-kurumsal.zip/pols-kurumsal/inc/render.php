<?php
/**
 * One render function per block. Markup mirrors the approved prototype
 * (scrollcraft/builds/pols/index.html) so pols.css and the engine apply as-is.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* ------------------------------------------------------------ helpers -- */

/** Attachment URL if an ID is set, else the bundled file in /seed/media. */
function pols_media_url( $id, $file = '' ) {
	$id = absint( $id );
	if ( $id ) {
		$url = wp_get_attachment_url( $id );
		if ( $url ) {
			return $url;
		}
	}
	return $file ? POLS_URI . '/seed/media/' . rawurlencode( $file ) : '';
}

function pols_scallop_symbol() {
	$c = '<circle cx="50" cy="50" r="40"/>';
	$pts = array( '90,50', '86.96,65.31', '78.28,78.28', '65.31,86.96', '50,90', '34.69,86.96', '21.72,78.28', '13.04,65.31', '10,50', '13.04,34.69', '21.72,21.72', '34.69,13.04', '50,10', '65.31,13.04', '78.28,21.72', '86.96,34.69' );
	foreach ( $pts as $p ) {
		list( $x, $y ) = explode( ',', $p );
		$c .= '<circle cx="' . $x . '" cy="' . $y . '" r="9.5"/>';
	}
	return '<svg width="0" height="0" style="position:absolute" aria-hidden="true"><symbol id="scallop" viewBox="0 0 100 100">' . $c . '</symbol></svg>';
}

/** Brand logo (Simple Icons paths) for a social link, picked by its host. */
function pols_social_icon( $url ) {
	$icons = array(
		'linkedin' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>',
		'youtube' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>',
		'instagram' => '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7.0301.084c-1.2768.0602-2.1487.264-2.911.5634-.7888.3075-1.4575.72-2.1228 1.3877-.6652.6677-1.075 1.3368-1.3802 2.127-.2954.7638-.4956 1.6365-.552 2.914-.0564 1.2775-.0689 1.6882-.0626 4.947.0062 3.2586.0206 3.6671.0825 4.9473.061 1.2765.264 2.1482.5635 2.9107.308.7889.72 1.4573 1.388 2.1228.6679.6655 1.3365 1.0743 2.1285 1.38.7632.295 1.6361.4961 2.9134.552 1.2773.056 1.6884.069 4.9462.0627 3.2578-.0062 3.668-.0207 4.9478-.0814 1.28-.0607 2.147-.2652 2.9098-.5633.7889-.3086 1.4578-.72 2.1228-1.3881.665-.6682 1.0745-1.3378 1.3795-2.1284.2957-.7632.4966-1.636.552-2.9124.056-1.2809.0692-1.6898.063-4.948-.0063-3.2583-.021-3.6668-.0817-4.9465-.0607-1.2797-.264-2.1487-.5633-2.9117-.3084-.7889-.72-1.4568-1.3876-2.1228C21.2982 1.33 20.628.9208 19.8378.6165 19.074.321 18.2017.1197 16.9244.0645 15.6471.0093 15.236-.005 11.977.0014 8.718.0076 8.31.0215 7.0301.0839m.1402 21.6932c-1.17-.0509-1.8053-.2453-2.2287-.408-.5606-.216-.96-.4771-1.3819-.895-.422-.4178-.6811-.8186-.9-1.378-.1644-.4234-.3624-1.058-.4171-2.228-.0595-1.2645-.072-1.6442-.079-4.848-.007-3.2037.0053-3.583.0607-4.848.05-1.169.2456-1.805.408-2.2282.216-.5613.4762-.96.895-1.3816.4188-.4217.8184-.6814 1.3783-.9003.423-.1651 1.0575-.3614 2.227-.4171 1.2655-.06 1.6447-.072 4.848-.079 3.2033-.007 3.5835.005 4.8495.0608 1.169.0508 1.8053.2445 2.228.408.5608.216.96.4754 1.3816.895.4217.4194.6816.8176.9005 1.3787.1653.4217.3617 1.056.4169 2.2263.0602 1.2655.0739 1.645.0796 4.848.0058 3.203-.0055 3.5834-.061 4.848-.051 1.17-.245 1.8055-.408 2.2294-.216.5604-.4763.96-.8954 1.3814-.419.4215-.8181.6811-1.3783.9-.4224.1649-1.0577.3617-2.2262.4174-1.2656.0595-1.6448.072-4.8493.079-3.2045.007-3.5825-.006-4.848-.0608M16.953 5.5864A1.44 1.44 0 1 0 18.39 4.144a1.44 1.44 0 0 0-1.437 1.4424M5.8385 12.012c.0067 3.4032 2.7706 6.1557 6.173 6.1493 3.4026-.0065 6.157-2.7701 6.1506-6.1733-.0065-3.4032-2.771-6.1565-6.174-6.1498-3.403.0067-6.156 2.771-6.1496 6.1738M8 12.0077a4 4 0 1 1 4.008 3.9921A3.9996 3.9996 0 0 1 8 12.0077"/></svg>',
	);
	$host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
	foreach ( $icons as $k => $svg ) {
		if ( false !== strpos( $host, $k === 'youtube' ? 'youtu' : $k ) ) {
			return $svg;
		}
	}
	return '';
}

/** LinkedIn embed URL from a post link or URN (activity, share or ugcPost). */
function pols_linkedin_embed( $url ) {
	if ( preg_match( '/urn:li:(activity|share|ugcPost):(\d+)/', (string) $url, $m ) ) {
		return 'https://www.linkedin.com/embed/feed/update/urn:li:' . $m[1] . ':' . $m[2];
	}
	// "linkedin.com/posts/polss_...-activity-7500175905135267840-abcd"
	if ( preg_match( '/activity[-:](\d{15,})/', (string) $url, $m ) ) {
		return 'https://www.linkedin.com/embed/feed/update/urn:li:activity:' . $m[1];
	}
	return '';
}

function pols_seal() {
	return '<svg aria-hidden="true"><use href="#scallop"/></svg>';
}

function pols_home_url() {
	return function_exists( 'pll_home_url' ) ? pll_home_url() : home_url( '/' );
}

/** Wrap a numeric token in a counter span: "2018" counts from 1990, "%80" and "30+" from 0. */
function pols_count_html( $big ) {
	// "%80" (TR), "80%" (EN) and "30+" all count; the sign stays where it was written.
	if ( preg_match( '/^(%?)(\d+)([%+]?)$/u', trim( $big ), $m ) ) {
		$to   = (int) $m[2];
		$from = $to > 1900 && $to < 2100 ? 1990 : 0;
		return esc_html( $m[1] ) . '<span data-sc-count="' . $from . ' ' . $to . '">' . $to . '</span>' . esc_html( $m[3] );
	}
	return esc_html( $big );
}

/** Percent in the page language: "%91" in Turkish, "91%" in English. */
function pols_pct( $n ) {
	return 'en' === pols_lang() ? $n . '%' : '%' . $n;
}

function pols_nl2br( $text ) {
	return nl2br( esc_html( $text ), false );
}

/** The frost plate for a scrub clip: its LAST frame (desktop + mobile), read by
 *  pols.js. It must be the clip's own last frame or the hand-off shows a seam. */
function pols_plate_attrs( $a ) {
	$a = wp_parse_args( $a, array( 'plate' => 0, 'plateFile' => '', 'plateMobile' => 0, 'plateMobileFile' => '' ) );
	return 'data-plate="' . esc_url( pols_media_url( $a['plate'], $a['plateFile'] ) ) . '" data-plate-mobile="' . esc_url( pols_media_url( $a['plateMobile'], $a['plateMobileFile'] ) ) . '"';
}

/* ------------------------------------------------------------- header -- */

function pols_menu_links() {
	$links     = array();
	$locations = get_nav_menu_locations();
	if ( ! empty( $locations['primary'] ) ) {
		$items = wp_get_nav_menu_items( $locations['primary'] );
		if ( $items ) {
			foreach ( $items as $it ) {
				if ( ! $it->menu_item_parent ) {
					$links[] = array( 'label' => $it->title, 'url' => $it->url );
				}
			}
		}
	}
	if ( ! $links ) {
		$fallback = 'en' === pols_lang()
			? array( 'About' => '#about', 'Contract Farming' => '#contract-farming', 'Sustainability' => '#sustainability', 'What is Freeze Dry' => '#freeze-dry', 'Products' => '#products', 'Contact' => '#contact' )
			: array( 'Hakkımızda' => '#hakkimizda', 'Sözleşmeli Tarım' => '#sozlesmeli-tarim', 'Sürdürülebilirlik' => '#surdurulebilirlik', 'Freeze Dry Nedir' => '#freeze-dry', 'Ürünler' => '#urunler', 'İletişim' => '#iletisim' );
		foreach ( $fallback as $label => $url ) {
			$links[] = array( 'label' => $label, 'url' => $url );
		}
	}
	return $links;
}

/** Front page in any language: is_front_page() is only true for the default
 *  language's page, so also accept any Polylang translation of it. */
function pols_is_front() {
	if ( is_front_page() ) {
		return true;
	}
	$front = (int) get_option( 'page_on_front' );
	$id    = (int) get_queried_object_id();
	if ( ! $front || ! $id || ! function_exists( 'pll_get_post_translations' ) ) {
		return false;
	}
	return in_array( $id, array_map( 'intval', pll_get_post_translations( $front ) ), true );
}

function pols_lang_switch() {
	if ( ! function_exists( 'pll_the_languages' ) ) {
		return '';
	}
	$langs = pll_the_languages( array( 'raw' => 1, 'hide_if_no_translation' => 0 ) );
	if ( ! $langs || count( $langs ) < 2 ) {
		return '';
	}
	$out = '<div class="lang" role="group" aria-label="' . esc_attr( pols_t( 'lang' ) ) . '">';
	foreach ( $langs as $l ) {
		$cur  = ! empty( $l['current_lang'] );
		// On the one-page front page, each language's front page is its root:
		// "/" for the default (hidden) language, "/en/" for the rest. Polylang
		// links the translated page itself (/en/home/), which works but reads
		// oddly, so build the root here.
		$default = function_exists( 'pll_default_language' ) ? pll_default_language() : 'tr';
		// Raw option, not home_url(): Polylang rewrites home_url() to the current language.
		$root    = untrailingslashit( get_option( 'home' ) );
		$url     = pols_is_front() ? $root . ( $l['slug'] === $default ? '/' : '/' . $l['slug'] . '/' ) : $l['url'];
		$out .= '<a href="' . esc_url( $url ) . '" hreflang="' . esc_attr( $l['slug'] ) . '" lang="' . esc_attr( $l['slug'] ) . '"' . ( $cur ? ' aria-current="true"' : '' ) . '>' . esc_html( strtoupper( $l['slug'] ) ) . '</a>';
	}
	return $out . '</div>';
}

function pols_render_header() {
	$links = pols_menu_links();
	$nav   = '';
	foreach ( $links as $l ) {
		$nav .= '<a href="' . esc_url( $l['url'] ) . '">' . esc_html( $l['label'] ) . '</a>';
	}
	$logo = POLS_URI . '/assets/img/pols-logo.png';
	$lang = pols_lang_switch();
	ob_start();
	?>
<a class="skip" href="#main"><?php echo esc_html( pols_t( 'skip' ) ); ?></a>
<header class="bar" id="top">
	<a class="bar__logo" href="<?php echo esc_url( pols_home_url() ); ?>" aria-label="<?php echo esc_attr( pols_t( 'home' ) ); ?>"><img src="<?php echo esc_url( $logo ); ?>" alt="Pol's" width="67" height="44"></a>
	<nav class="nav" aria-label="<?php echo esc_attr( pols_t( 'main_menu' ) ); ?>"><span class="nav__pill" aria-hidden="true"></span><?php echo $nav; // phpcs:ignore ?></nav>
	<div class="bar__end">
		<?php echo $lang; // phpcs:ignore ?>
		<button type="button" class="menu-btn" id="menu-open" aria-label="<?php echo esc_attr( pols_t( 'menu_open' ) ); ?>" aria-expanded="false" aria-controls="drawer"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M4 7h16M4 12h16M4 17h10"/></svg></button>
	</div>
</header>
<div class="drawer" id="drawer" role="dialog" aria-modal="true" aria-label="<?php echo esc_attr( pols_t( 'menu' ) ); ?>" hidden>
	<div class="drawer__top">
		<img src="<?php echo esc_url( $logo ); ?>" alt="Pol's" height="38" style="height:38px;width:auto">
		<button type="button" class="menu-btn" style="display:inline-flex" id="menu-close" aria-label="<?php echo esc_attr( pols_t( 'menu_close' ) ); ?>"><svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6L6 18"/></svg></button>
	</div>
	<nav aria-label="<?php echo esc_attr( pols_t( 'mobile_menu' ) ); ?>"><?php echo $nav; // phpcs:ignore ?></nav>
	<?php echo $lang; // phpcs:ignore ?>
</div>
<div class="toast" id="toast" role="status" aria-live="polite" hidden></div>
	<?php
	return ob_get_clean();
}

/* --------------------------------------------------------------- hero -- */

function pols_render_hero( $a ) {
	ob_start();
	?>
<section class="hero<?php echo $a['imageOnly'] ? ' is-image-only' : ''; ?>" id="<?php echo esc_attr( $a['anchor'] ); ?>" data-sc-act="scrub" data-sc-span="2.4" data-sc-dwell="0.3" data-sc-clip-map="travel" <?php echo pols_plate_attrs( $a ); // phpcs:ignore ?> aria-label="<?php echo esc_attr( $a['titleA'] . ' ' . $a['titleB'] ); ?>">
	<div data-sc-stage>
		<picture>
			<source media="(max-width: 860px)" srcset="<?php echo esc_url( pols_media_url( $a['posterMobile'], $a['posterMobileFile'] ) ); ?>">
			<img class="sc-stage__poster" src="<?php echo esc_url( pols_media_url( $a['poster'], $a['posterFile'] ) ); ?>" alt="" width="1920" height="1080" fetchpriority="high">
		</picture>
		<?php if ( ! $a['imageOnly'] ) : ?>
		<video data-sc-scrub data-sc-src="<?php echo esc_url( pols_media_url( $a['video'], $a['videoFile'] ) ); ?>" data-sc-src-mobile="<?php echo esc_url( pols_media_url( $a['videoMobile'], $a['videoMobileFile'] ) ); ?>" muted playsinline aria-hidden="true"></video>
		<?php endif; ?>
		<div class="hero__wash" aria-hidden="true"></div>
		<div class="sc-copy" data-sc-cue="0 0.72 0">
			<h1 class="sc-display" data-sc-kinetic="lines"><?php echo esc_html( $a['titleA'] ); ?> <em><?php echo esc_html( $a['titleB'] ); ?></em></h1>
			<p class="hero__motto">
				<span class="badge hero__seal" aria-hidden="true"><?php echo pols_seal(); // phpcs:ignore ?><img src="<?php echo esc_url( POLS_URI . '/assets/img/pols-logo.png' ); ?>" alt="" width="67" height="44"></span>
				<span><b><?php echo esc_html( $a['motto'] ); ?></b><small><?php echo esc_html( $a['mottoSub'] ); ?></small></span>
			</p>
		</div>
	</div>
</section>
	<?php
	return ob_get_clean();
}

/* -------------------------------------------------------------- about -- */

function pols_render_about( $a ) {
	$items = '';
	foreach ( (array) $a['badges'] as $b ) {
		$b     = wp_parse_args( $b, array( 'big' => '', 'label' => '' ) );
		$word  = ! preg_match( '/^[%\d.,+\s]+$/u', $b['big'] );
		$items .= '<li><b' . ( $word ? ' class="word"' : '' ) . '>' . pols_count_html( $b['big'] ) . '</b><small>' . esc_html( $b['label'] ) . '</small></li>';
	}
	$id = esc_attr( $a['anchor'] );
	ob_start();
	?>
<section class="sc-section stats" id="<?php echo $id; // phpcs:ignore ?>" aria-labelledby="h-<?php echo $id; // phpcs:ignore ?>">
	<div class="sc-wrap">
		<h2 class="sc-display" id="h-<?php echo $id; // phpcs:ignore ?>" data-sc-in><?php echo esc_html( $a['heading'] ); ?></h2>
		<?php if ( $items ) : ?>
		<ul class="stats__row" style="--n:<?php echo (int) max( 1, count( (array) $a['badges'] ) ); ?>" aria-label="<?php echo esc_attr( pols_t( 'badges' ) ); ?>" data-sc-in data-sc-stagger="70"><?php echo $items; // phpcs:ignore ?></ul>
		<?php endif; ?>
	</div>
</section>
	<?php
	return ob_get_clean();
}

/* ------------------------------------------------------------- values -- */

function pols_render_values( $a ) {
	$items = array_values( (array) $a['items'] );
	$n     = count( $items );
	$out   = '';
	foreach ( $items as $i => $it ) {
		// Overlapping windows; the first greets, the last one enters and holds:
		// it stays on screen through the hand-off to the field (it re-inks light).
		$from = $n > 1 ? round( $i / $n, 2 ) : 0;
		$to   = $n > 1 ? round( ( $i + 1 ) / $n + 0.03, 2 ) : 1;
		$cue  = 0 === $i ? '0 ' . ( 1 === $n ? 1 : min( 1, $to ) ) . ' 0' : ( $i === $n - 1 ? (string) max( 0, $from - 0.03 ) : max( 0, $from - 0.03 ) . ' ' . $to );
		$out .= '<div class="value" data-sc-cue="' . esc_attr( $cue ) . '"><h3>' . esc_html( $it['title'] ) . '</h3><p>' . esc_html( $it['text'] ) . '</p></div>';
	}
	$span = max( 1.6, 0.67 * $n );
	ob_start();
	?>
<section class="values" id="<?php echo esc_attr( $a['anchor'] ); ?>" data-sc-act="pin" data-sc-span="<?php echo esc_attr( $span ); ?>" aria-label="<?php echo esc_attr( $a['label'] ); ?>">
	<div data-sc-stage>
		<span class="values__label"><?php echo esc_html( $a['label'] ); ?></span>
		<?php echo $out; // phpcs:ignore ?>
	</div>
</section>
	<?php
	return ob_get_clean();
}

/* -------------------------------------------------------- field intro -- */

function pols_render_field_intro( $a ) {
	$bg = pols_media_url( $a['image'], $a['imageFile'] );
	ob_start();
	?>
<section class="on-dark field-intro" id="<?php echo esc_attr( $a['anchor'] ); ?>" style="--field-bg:url('<?php echo esc_url( $bg ); ?>')" aria-labelledby="h-<?php echo esc_attr( $a['anchor'] ); ?>">
	<?php // The field photo, fixed to the viewport; pols.js moves it to the zone start. ?>
	<div class="field-intro__bg" aria-hidden="true"></div>
	<div class="reveal-wrap" data-sc-in>
		<h2 class="sc-display" id="h-<?php echo esc_attr( $a['anchor'] ); ?>"><?php echo esc_html( $a['text'] ); ?></h2>
	</div>
</section>
	<?php
	return ob_get_clean();
}

/* ------------------------------------------------------------ journey -- */

function pols_render_journey( $a ) {
	$stops = '';
	foreach ( (array) $a['stops'] as $s ) {
		$s      = wp_parse_args( $s, array( 'title' => '', 'text' => '', 'image' => 0, 'imageFile' => '', 'alt' => '' ) );
		$stops .= '<article class="stop"><figure><img src="' . esc_url( pols_media_url( $s['image'], $s['imageFile'] ) ) . '" alt="' . esc_attr( $s['alt'] ) . '" width="900" height="1200" loading="lazy"></figure><h3>' . esc_html( $s['title'] ) . '</h3><p>' . esc_html( $s['text'] ) . '</p></article>';
	}
	$n = max( 1, count( (array) $a['stops'] ) );
	ob_start();
	?>
<section class="journey on-dark" id="<?php echo esc_attr( $a['anchor'] ); ?>" data-sc-act="pan" data-sc-span="<?php echo esc_attr( $n + 1 ); ?>" aria-label="<?php echo esc_attr( $a['heading'] ); ?>">
	<div data-sc-stage>
		<div class="rail" data-sc-pan="0">
			<svg class="route" aria-hidden="true"><path class="track"/><path class="drawn"/></svg>
			<div class="rail__lead">
				<h2 class="sc-display"><?php echo esc_html( $a['heading'] ); ?></h2>
				<p><?php echo esc_html( $a['intro'] ); ?></p>
			</div>
			<?php echo $stops; // phpcs:ignore ?>
			<p class="rail__note"><?php echo esc_html( $a['note'] ); ?> <span><?php echo esc_html( $a['noteAccent'] ); ?></span></p>
		</div>
		<div class="berry" aria-hidden="true"><?php
		$k   = 0;
		$all = pols_fruits();
		foreach ( pols_journey_fruits() as $key ) {
			$f = $all[ $key ];
			printf( '<img%s src="%s" alt="" width="%d" height="%d">', 0 === $k++ ? ' class="is-on"' : '', esc_url( POLS_URI . '/assets/img/' . $f['file'] ), (int) $f['w'], (int) $f['h'] );
		}
		?></div>
	</div>
</section>
	<?php
	return ob_get_clean();
}

/* ------------------------------------------------ scrub (sustainability) -- */

function pols_render_scrub( $a ) {
	$id = esc_attr( $a['anchor'] );
	ob_start();
	?>
<section class="sust on-dark<?php echo $a['imageOnly'] ? ' is-image-only' : ''; ?>" id="<?php echo $id; // phpcs:ignore ?>" data-sc-act="scrub" data-sc-span="2.2" data-sc-dwell="0.3" data-sc-clip-map="travel" <?php echo pols_plate_attrs( $a ); // phpcs:ignore ?> aria-labelledby="h-<?php echo $id; // phpcs:ignore ?>">
	<div data-sc-stage>
		<picture>
			<source media="(max-width: 860px)" srcset="<?php echo esc_url( pols_media_url( $a['posterMobile'], $a['posterMobileFile'] ) ); ?>">
			<img class="sc-stage__poster" src="<?php echo esc_url( pols_media_url( $a['poster'], $a['posterFile'] ) ); ?>" alt="" width="1920" height="1080" loading="lazy">
		</picture>
		<?php if ( ! $a['imageOnly'] ) : ?>
		<video data-sc-scrub data-sc-src="<?php echo esc_url( pols_media_url( $a['video'], $a['videoFile'] ) ); ?>" data-sc-src-mobile="<?php echo esc_url( pols_media_url( $a['videoMobile'], $a['videoMobileFile'] ) ); ?>" muted playsinline aria-hidden="true"></video>
		<?php endif; ?>
		<div class="sc-scrim sc-scrim--trail" aria-hidden="true"></div>
		<div class="sc-copy sc-copy--trail" data-sc-cue="0.1 0.8 0.25 0.2">
			<h2 class="sc-display" id="h-<?php echo $id; // phpcs:ignore ?>" data-sc-kinetic="lines"><?php echo esc_html( $a['heading'] ); ?></h2>
			<p class="sc-lede"><?php echo esc_html( $a['text'] ); ?></p>
		</div>
	</div>
</section>
	<?php
	return ob_get_clean();
}

/* --------------------------------------------------------- freeze dry -- */

function pols_render_freeze_dry( $a ) {
	$steps  = '';
	$frames = '';
	foreach ( array_values( (array) $a['steps'] ) as $i => $s ) {
		$s       = wp_parse_args( $s, array( 'title' => '', 'text' => '', 'image' => 0, 'imageFile' => '', 'alt' => '' ) );
		$active  = 0 === $i ? ' class="is-active"' : '';
		$steps  .= '<li' . $active . '><button type="button" data-step="' . $i . '"><i>' . sprintf( '%02d', $i + 1 ) . '</i><b>' . esc_html( $s['title'] ) . '</b></button><p>' . esc_html( $s['text'] ) . '</p></li>';
		$frames .= '<img' . $active . ' src="' . esc_url( pols_media_url( $s['image'], $s['imageFile'] ) ) . '" alt="' . esc_attr( $s['alt'] ) . '" width="1400" height="788" loading="lazy">';
	}
	$id   = esc_attr( $a['anchor'] );
	$from = (float) $a['waterFrom'];
	ob_start();
	?>
<section class="fd" id="<?php echo $id; // phpcs:ignore ?>" data-sc-act="pin" data-sc-span="3.6" data-dry-step="<?php echo esc_attr( max( 1, (int) $a['dryStep'] ) ); ?>" data-water-from="<?php echo esc_attr( $from ); ?>" data-water-to="<?php echo esc_attr( (float) $a['waterTo'] ); ?>" data-pct="<?php echo 'en' === pols_lang() ? 'after' : 'before'; ?>" aria-labelledby="h-<?php echo $id; // phpcs:ignore ?>">
	<div data-sc-stage>
		<div class="fd__grid">
			<div class="fd__text">
				<span class="fd__eyebrow"><?php echo esc_html( $a['eyebrow'] ); ?></span>
				<h2 class="sc-display" id="h-<?php echo $id; // phpcs:ignore ?>"><?php echo esc_html( $a['heading'] ); ?> <span><?php echo esc_html( $a['headingAccent'] ); ?></span></h2>
				<ol class="fd__steps"><?php echo $steps; // phpcs:ignore ?></ol>
			</div>
			<div class="fd__visual">
				<div class="fd__frames"><?php echo $frames; // phpcs:ignore ?></div>
				<div class="fd__meter">
					<span class="fd__meter-label"><?php echo esc_html( $a['meterLabel'] ); ?></span>
					<span class="fd__track"><span class="fd__fill" style="transform:scaleX(<?php echo esc_attr( $from / 100 ); ?>)"></span></span>
					<b class="fd__value"><?php echo esc_html( pols_pct( round( $from ) ) ); ?></b>
				</div>
				<p class="fd__note"><?php echo esc_html( $a['note'] ); ?></p>
			</div>
		</div>
	</div>
</section>
	<?php
	return ob_get_clean();
}

/* -------------------------------------------------------------- facts -- */

function pols_render_facts( $a ) {
	$items = '';
	foreach ( (array) $a['items'] as $it ) {
		$items .= '<li><b>' . pols_count_html( $it['big'] ) . '</b><span>' . esc_html( $it['label'] ) . '</span></li>';
	}
	ob_start();
	?>
<section class="sc-section on-dark fd-facts" id="<?php echo esc_attr( $a['anchor'] ); ?>">
	<div class="sc-wrap">
		<ul class="fd-facts__grid" data-sc-in data-sc-stagger="80"><?php echo $items; // phpcs:ignore ?></ul>
		<?php if ( $a['line'] ) : ?><p class="fd-facts__line" data-sc-in><?php echo esc_html( $a['line'] ); ?></p><?php endif; ?>
	</div>
</section>
	<?php
	return ob_get_clean();
}

/* ------------------------------------------------------- certificates -- */

function pols_cert_logos() {
	$logos = array();
	$q     = new WP_Query( array( 'post_type' => 'pols_sertifika', 'posts_per_page' => 50, 'orderby' => array( 'menu_order' => 'ASC', 'title' => 'ASC' ), 'no_found_rows' => true, 'lang' => '' ) );
	foreach ( $q->posts as $p ) {
		$url = get_the_post_thumbnail_url( $p, 'medium' );
		if ( $url ) {
			$logos[] = array( 'src' => $url, 'alt' => get_the_title( $p ) );
		}
	}
	if ( ! $logos ) {
		foreach ( pols_seed_certs() as $file => $alt ) {
			$logos[] = array( 'src' => POLS_URI . '/seed/media/' . $file, 'alt' => $alt );
		}
	}
	return $logos;
}

function pols_render_certificates( $a ) {
	$logos = pols_cert_logos();
	$lis   = '';
	foreach ( $logos as $l ) {
		$lis .= '<li><img src="' . esc_url( $l['src'] ) . '" alt="' . esc_attr( $l['alt'] ) . '" width="200" height="96" loading="lazy"></li>';
	}
	$id = esc_attr( $a['anchor'] );
	ob_start();
	?>
<section class="sc-section" id="<?php echo $id; // phpcs:ignore ?>" aria-labelledby="h-<?php echo $id; // phpcs:ignore ?>">
	<div class="sc-wrap">
		<div class="certs__head" data-sc-in data-sc-stagger="70">
			<h2 class="sc-display" id="h-<?php echo $id; // phpcs:ignore ?>"><?php echo esc_html( $a['heading'] ); ?></h2>
		</div>
	</div>
	<div class="marquee">
		<div class="marquee__track">
			<ul aria-label="<?php echo esc_attr( pols_t( 'cert_logos' ) ); ?>"><?php echo $lis; // phpcs:ignore ?></ul>
			<ul aria-hidden="true"></ul>
		</div>
	</div>
	<?php // No count and no pause button (user 2026-09-30); the strip stops on hover/focus. ?>
</section>
	<?php
	return ob_get_clean();
}

/* ----------------------------------------------------------- catalogs -- */

function pols_catalog_items() {
	$items = array();
	$q     = new WP_Query( array( 'post_type' => 'pols_katalog', 'posts_per_page' => 12, 'orderby' => array( 'menu_order' => 'ASC', 'date' => 'ASC' ), 'no_found_rows' => true ) );
	foreach ( $q->posts as $p ) {
		$items[] = array(
			'title'     => get_the_title( $p ),
			'sub'       => get_post_meta( $p->ID, '_pols_sub', true ),
			'tag'       => get_post_meta( $p->ID, '_pols_tag', true ),
			'text'      => $p->post_excerpt,
			'color'     => get_post_meta( $p->ID, '_pols_color', true ) ?: 'forest',
			'pdf'       => get_post_meta( $p->ID, '_pols_pdf', true ),
			'linkLabel' => get_post_meta( $p->ID, '_pols_link_label', true ),
			'linkUrl'   => get_post_meta( $p->ID, '_pols_link_url', true ),
			'cover'     => get_the_post_thumbnail_url( $p, 'large' ),
		);
	}
	return $items ?: pols_seed_catalogs( pols_lang() );
}

function pols_render_catalogs( $a ) {
	$cls   = array( 'forest' => 'cat--b2b', 'orange' => 'cat--ff', 'berry' => 'cat--gg' );
	$logo  = POLS_URI . '/assets/img/pols-logo.png';
	$cards = '';
	foreach ( pols_catalog_items() as $c ) {
		// No button row under the cards (user direction 2026-09-28). When a PDF
		// is uploaded, the cover itself becomes the download link.
		$cover  = $c['cover'] ? ' style="background-image:linear-gradient(0deg,rgba(0,0,0,.45),transparent 55%),url(\'' . esc_url( $c['cover'] ) . '\');background-size:cover;background-position:center"' : '';
		$inner  = '<span class="lg"><img src="' . esc_url( $logo ) . '" alt="" width="45" height="30"></span>'
			. '<div><strong>' . esc_html( $c['title'] ) . '</strong><small>' . esc_html( $c['sub'] ) . '</small></div>'
			. '<span class="badge" aria-hidden="true">' . pols_seal() . '</span>';
		$box    = $c['pdf']
			? '<a class="cat__cover" data-sc-tilt="6" href="' . esc_url( $c['pdf'] ) . '" download data-pdf aria-label="' . esc_attr( $c['title'] . ' · ' . pols_t( 'pdf_download' ) ) . '"' . $cover . '>' . $inner . '</a>'
			: '<div class="cat__cover" data-sc-tilt="6"' . $cover . '>' . $inner . '</div>';
		$cards .= '<article class="cat ' . esc_attr( isset( $cls[ $c['color'] ] ) ? $cls[ $c['color'] ] : 'cat--b2b' ) . '">'
			. $box
			. '<span class="cat__tag">' . esc_html( $c['tag'] ) . '</span><p>' . esc_html( $c['text'] ) . '</p></article>';
	}
	$id = esc_attr( $a['anchor'] );
	ob_start();
	?>
<section class="sc-section on-peach" id="<?php echo $id; // phpcs:ignore ?>" aria-labelledby="h-<?php echo $id; // phpcs:ignore ?>">
	<div class="sc-wrap">
		<div class="cats__head" data-sc-in data-sc-stagger="70">
			<h2 class="sc-display" id="h-<?php echo $id; // phpcs:ignore ?>"><?php echo esc_html( $a['heading'] ); ?></h2>
			<p class="sc-body"><?php echo esc_html( $a['intro'] ); ?></p>
		</div>
		<div class="cats" data-sc-in data-sc-stagger="80"><?php echo $cards; // phpcs:ignore ?></div>
	</div>
</section>
	<?php
	return ob_get_clean();
}

/* -------------------------------------------------------------- media -- */

function pols_render_media( $a ) {
	$eps = '';
	foreach ( array_values( (array) $a['episodes'] ) as $i => $e ) {
		$eps .= '<li><a href="' . esc_url( $e['url'] ) . '" target="_blank" rel="noopener"><span class="badge n">' . pols_seal() . '<span>' . ( $i + 1 ) . '</span></span><span><strong>' . esc_html( $e['title'] ) . '</strong><small>' . esc_html( $e['meta'] ) . '</small></span></a></li>';
	}
	$soc = '';
	$li  = '';
	foreach ( (array) $a['socials'] as $s ) {
		$icon = pols_social_icon( $s['url'] );
		$soc .= $icon
			? '<a class="social" href="' . esc_url( $s['url'] ) . '" target="_blank" rel="noopener" aria-label="' . esc_attr( $s['label'] ) . '">' . $icon . '</a>'
			: '<a class="btn btn--line" href="' . esc_url( $s['url'] ) . '" target="_blank" rel="noopener">' . esc_html( $s['label'] ) . '</a>';
		if ( ! $li && false !== strpos( (string) $s['url'], 'linkedin.' ) ) {
			$li = $s['url'];
		}
	}
	$feed = '';
	foreach ( (array) ( isset( $a['linkedinPosts'] ) ? $a['linkedinPosts'] : array() ) as $p ) {
		$src = pols_linkedin_embed( is_array( $p ) && isset( $p['url'] ) ? $p['url'] : '' );
		if ( $src ) {
			$feed .= '<li><iframe src="' . esc_url( $src ) . '" title="' . esc_attr( pols_t( 'li_post' ) ) . '" loading="lazy" allowfullscreen></iframe></li>';
		}
	}
	$id = esc_attr( $a['anchor'] );
	ob_start();
	?>
<section class="sc-section" id="<?php echo $id; // phpcs:ignore ?>" data-nav-next aria-labelledby="h-<?php echo $id; // phpcs:ignore ?>">
	<div class="sc-wrap">
		<h2 class="sc-display sc-display--md" id="h-<?php echo $id; // phpcs:ignore ?>" data-sc-in><?php echo esc_html( $a['heading'] ); ?></h2>
		<div class="media" data-sc-in data-sc-stagger="80">
			<a class="film" href="<?php echo esc_url( $a['filmUrl'] ); ?>" target="_blank" rel="noopener">
				<img src="<?php echo esc_url( pols_media_url( $a['filmPoster'], $a['filmPosterFile'] ) ); ?>" alt="" width="1920" height="1080" loading="lazy">
				<span><i><svg width="20" height="20" viewBox="0 0 24 24" fill="#fff" aria-hidden="true"><path d="M8 5.5v13l11-6.5z"/></svg></i><?php echo esc_html( $a['filmLabel'] ); ?></span>
			</a>
			<div>
				<ul class="eps" aria-label="<?php echo esc_attr( pols_t( 'episodes' ) ); ?>"><?php echo $eps; // phpcs:ignore ?></ul>
				<div class="socials"><?php echo $soc; // phpcs:ignore ?></div>
			</div>
		</div>
		<?php if ( $feed ) : ?>
		<div class="li-feed" data-sc-in>
			<div class="li-feed__head">
				<?php if ( ! empty( $a['feedHeading'] ) ) : ?><h3><?php echo esc_html( $a['feedHeading'] ); ?></h3><?php endif; ?>
				<?php if ( $li ) : ?><a href="<?php echo esc_url( $li ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $a['feedMore'] ); ?> ↗</a><?php endif; ?>
			</div>
			<ul class="li-feed__row" aria-label="<?php echo esc_attr( pols_t( 'li_feed' ) ); ?>"><?php echo $feed; // phpcs:ignore ?></ul>
		</div>
		<?php endif; ?>
	</div>
</section>
	<?php
	return ob_get_clean();
}

/* ------------------------------------------------------------ contact -- */

function pols_render_contact( $a ) {
	$locs = '';
	foreach ( (array) $a['locations'] as $l ) {
		$l     = wp_parse_args( $l, array( 'title' => '', 'address' => '', 'phone' => '', 'map' => '', 'mapLabel' => '' ) );
		$tel   = $l['phone'] ? '<a class="tel" href="tel:' . esc_attr( preg_replace( '/[^\d+]/', '', $l['phone'] ) ) . '">' . esc_html( $l['phone'] ) . '</a>' : '';
		$map   = $l['map'] ? '<a class="dir" href="' . esc_url( $l['map'] ) . '" target="_blank" rel="noopener">' . esc_html( $l['mapLabel'] ) . '</a>' : '';
		$locs .= '<div class="loc"><h3>' . esc_html( $l['title'] ) . '</h3><p>' . pols_nl2br( $l['address'] ) . '</p>' . $tel . $map . '</div>';
	}
	$legal = '';
	foreach ( (array) $a['legal'] as $g ) {
		$legal .= '<a href="' . esc_url( $g['url'] ) . '">' . esc_html( $g['label'] ) . '</a>';
	}
	$soc = '';
	foreach ( (array) ( isset( $a['socials'] ) ? $a['socials'] : array() ) as $s ) {
		$s    = wp_parse_args( $s, array( 'label' => '', 'url' => '' ) );
		$icon = pols_social_icon( $s['url'] );
		$soc .= $icon
			? '<a class="social" href="' . esc_url( $s['url'] ) . '" target="_blank" rel="noopener" aria-label="' . esc_attr( $s['label'] ) . '">' . $icon . '</a>'
			: '<a href="' . esc_url( $s['url'] ) . '" target="_blank" rel="noopener">' . esc_html( $s['label'] ) . '</a>';
	}
	$id = esc_attr( $a['anchor'] );
	ob_start();
	?>
<section class="sc-section on-orange contact" id="<?php echo $id; // phpcs:ignore ?>" aria-labelledby="h-<?php echo $id; // phpcs:ignore ?>">
	<div class="sc-wrap">
		<div data-sc-in data-sc-stagger="80">
			<h2 class="sc-display" id="h-<?php echo $id; // phpcs:ignore ?>"><?php echo esc_html( $a['heading'] ); ?></h2>
			<div class="mail">
				<a href="mailto:<?php echo esc_attr( antispambot( $a['email'] ) ); ?>"><?php echo esc_html( antispambot( $a['email'] ) ); ?></a>
				<button type="button" class="btn btn--dark copy-mail" data-email="<?php echo esc_attr( $a['email'] ); ?>"><?php echo esc_html( $a['copyLabel'] ); ?></button>
			</div>
		</div>
		<div class="locs" data-sc-in data-sc-stagger="80"><?php echo $locs; // phpcs:ignore ?></div>
		<footer class="foot">
			<div class="foot__brand"><img src="<?php echo esc_url( POLS_URI . '/assets/img/pols-logo.png' ); ?>" alt="Pol's" width="61" height="40"><span><?php echo esc_html( $a['copyright'] ); ?></span></div>
			<?php if ( $soc ) : ?><div class="foot__social" role="group" aria-label="<?php echo esc_attr( pols_t( 'socials' ) ); ?>"><?php echo $soc; // phpcs:ignore ?></div><?php endif; ?>
			<nav aria-label="<?php echo esc_attr( pols_t( 'legal' ) ); ?>"><?php echo $legal; // phpcs:ignore ?></nav>
		</footer>
	</div>
</section>
	<?php
	return ob_get_clean();
}

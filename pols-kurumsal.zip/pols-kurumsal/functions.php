<?php
/**
 * Pol's Kurumsal — block theme on the scroll-craft engine.
 *
 * inc/schema.php   one definition per block: fields (editor UI) + TR defaults
 * inc/blocks.php   registers the blocks from the schema, render callbacks
 * inc/render.php   one render function per section (markup = approved prototype)
 * inc/cpt.php      Katalog and Sertifika content types
 * inc/i18n.php     small TR/EN dictionary for theme UI strings (Polylang-aware)
 * inc/setup.php    "Pol's Kurulum": imports media, creates TR/EN pages and menus
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'POLS_VERSION', '1.3.0' );
define( 'POLS_DIR', get_template_directory() );
define( 'POLS_URI', get_template_directory_uri() );

require POLS_DIR . '/inc/i18n.php';
require POLS_DIR . '/inc/schema.php';
require POLS_DIR . '/inc/render.php';
require POLS_DIR . '/inc/blocks.php';
require POLS_DIR . '/inc/cpt.php';
require POLS_DIR . '/inc/en-content.php';
require POLS_DIR . '/inc/setup.php';

add_action( 'after_setup_theme', function () {
	add_theme_support( 'wp-block-styles' );
	add_theme_support( 'editor-styles' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'menus' );
	add_theme_support( 'custom-logo' );
	register_nav_menus( array( 'primary' => 'Ana menü (tek sayfa bölümleri)' ) );
	add_editor_style( array( 'assets/css/scrollcraft.css', 'assets/css/pols.css', 'assets/css/editor.css' ) );
	load_theme_textdomain( 'pols', POLS_DIR . '/languages' );
} );

/* Front end: engine first, page script after it, both in the footer. */
add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'pols-scrollcraft', POLS_URI . '/assets/css/scrollcraft.css', array(), POLS_VERSION );
	wp_enqueue_style( 'pols', POLS_URI . '/assets/css/pols.css', array( 'pols-scrollcraft' ), POLS_VERSION );
	wp_enqueue_script( 'pols-scrollcraft', POLS_URI . '/assets/js/scrollcraft.js', array(), POLS_VERSION, true );
	wp_enqueue_script( 'pols', POLS_URI . '/assets/js/pols.js', array( 'pols-scrollcraft' ), POLS_VERSION, true );
	wp_localize_script( 'pols', 'POLS', array(
		'copied'     => pols_t( 'copied' ),
		'soon'       => pols_t( 'pdf_soon_toast' ),
		'pause'      => pols_t( 'marquee_pause' ),
		'play'       => pols_t( 'marquee_play' ),
	) );
} );

/* Hero poster is the LCP element: preload it. */
add_action( 'wp_head', function () {
	if ( ! is_singular() ) {
		return;
	}
	$post = get_post();
	if ( $post && has_block( 'pols/hero', $post ) ) {
		foreach ( parse_blocks( $post->post_content ) as $b ) {
			if ( 'pols/hero' === $b['blockName'] ) {
				$attrs = wp_parse_args( $b['attrs'], pols_block_defaults( 'hero' ) );
				$url   = pols_media_url( $attrs['poster'], $attrs['posterFile'] );
				echo '<link rel="preload" as="image" href="' . esc_url( $url ) . '" fetchpriority="high">' . "\n";
				break;
			}
		}
	}
}, 2 );

/* The scallop symbol is used by several blocks; print it once. */
add_action( 'wp_body_open', function () {
	echo pols_scallop_symbol(); // phpcs:ignore WordPress.Security.EscapeOutput
	echo '<span data-sc-progress></span>';
} );

/* Organization structured data. */
add_action( 'wp_head', function () {
	if ( ! is_front_page() ) {
		return;
	}
	$data = array(
		'@context'    => 'https://schema.org',
		'@type'       => 'Organization',
		'name'        => "Pol's",
		'url'         => home_url( '/' ),
		'logo'        => POLS_URI . '/assets/img/pols-logo.png',
		'email'       => 'info@pols.com.tr',
		'foundingDate' => '2017',
		'slogan'      => pols_t( 'motto_plain' ),
		'sameAs'      => array(
			'https://www.linkedin.com/company/polss',
			'https://www.youtube.com/channel/UCDVOf56bM8_xRs_LG5R2p7g',
			'https://www.instagram.com/polsgurme/',
			'https://www.facebook.com/pols.freezefresh',
		),
	);
	echo '<script type="application/ld+json">' . wp_json_encode( $data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>' . "\n";
} );

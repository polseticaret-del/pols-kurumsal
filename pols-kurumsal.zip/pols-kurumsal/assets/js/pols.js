/* Pol's Kurumsal: page behaviour on top of the scroll-craft engine.
   Every feature looks for its own block and quietly skips when a page does not
   use it, so blocks can be reordered or removed in the editor. */
(function () {
  'use strict';
  if (!window.ScrollCraft) return;

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  var T = window.POLS || {};
  var clamp01 = function (x) { return x < 0 ? 0 : x > 1 ? 1 : x; };
  // Top of an element in page coordinates. offsetTop is relative to the
  // nearest positioned ancestor, and the frost zones are positioned.
  function docTop(el) { return el.getBoundingClientRect().top + scrollY; }

  /* ------------------------------------------------------- frost zones --
     Wrap consecutive section blocks into the three blurred-background zones
     (see pols.css, FROST). Done before the engine mounts, and only when the
     blocks are siblings in the expected order, so a page that reorders or
     drops blocks simply keeps plain sections. */
  function follows(a, b) { return a === b || !!(a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING); }
  function makeZone(first, last, cls, bgHtml) {
    if (!first || !last || first.parentNode !== last.parentNode || !follows(first, last)) return null;
    var z = document.createElement('div');
    z.className = 'frost ' + cls;
    first.parentNode.insertBefore(z, first);
    for (var n = first; n;) { var next = n.nextSibling; z.appendChild(n); if (n === last) break; n = next; }
    if (bgHtml) z.insertAdjacentHTML('afterbegin', bgHtml);
    return z;
  }
  var heroSec = $('.hero'), statsSec = $('.stats'), valSec = $('.values');
  var fieldSec = $('.field-intro'), journeySec = $('.journey'), sustSec = $('.sust');
  var zEarly = heroSec && makeZone(heroSec, (valSec && follows(heroSec, valSec)) ? valSec : statsSec, 'frost--early',
    '<div class="frost__bg" aria-hidden="true"><canvas></canvas><b></b><b></b>' + (fieldSec ? '<i class="frost__next"></i>' : '') + '</div>');
  var zField = fieldSec && makeZone(fieldSec, (journeySec && fieldSec.parentNode === journeySec.parentNode && follows(fieldSec, journeySec)) ? journeySec : fieldSec, 'frost--field', '');
  if (zField) zField.insertBefore($('.field-intro__bg', fieldSec), zField.firstChild);
  if (fieldSec) document.body.style.setProperty('--field-bg', fieldSec.style.getPropertyValue('--field-bg'));
  var lastSec = null;
  for (var sib = sustSec; sib; sib = sib.nextElementSibling) if (sib.tagName === 'SECTION') lastSec = sib;
  var zLate = sustSec && makeZone(sustSec, lastSec, 'frost--late', '<div class="frost__bg" aria-hidden="true"><canvas></canvas></div>');

  ScrollCraft.mount(document.body);

  var main = $('main');
  if (main && !main.id) main.id = 'main';

  var toastT;
  function toast(msg) { var t = $('#toast'); if (!t) return; t.textContent = msg; t.hidden = false; clearTimeout(toastT); toastT = setTimeout(function () { t.hidden = true; }, 2600); }

  /* ---------------------------------------------------- drawer, trapped -- */
  var drawer = $('#drawer'), openBtn = $('#menu-open'), lastFocus = null;
  if (drawer && openBtn) {
    var closeBtn = $('#menu-close');
    var focusables = function () { return $$('a, button', drawer); };
    var openDrawer = function () { lastFocus = document.activeElement; drawer.hidden = false; openBtn.setAttribute('aria-expanded', 'true'); document.body.style.overflow = 'hidden'; closeBtn.focus(); };
    var closeDrawer = function (restore) { drawer.hidden = true; openBtn.setAttribute('aria-expanded', 'false'); document.body.style.overflow = ''; if (restore && lastFocus) lastFocus.focus(); };
    openBtn.addEventListener('click', openDrawer);
    closeBtn.addEventListener('click', function () { closeDrawer(true); });
    $$('nav a', drawer).forEach(function (a) { a.addEventListener('click', function () { closeDrawer(false); }); });
    drawer.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { closeDrawer(true); return; }
      if (e.key !== 'Tab') return;
      var f = focusables(), first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    });
  }

  /* --------------------------------------------- nav: active section pill --
     Walk the sections in reading order; a section that is not itself in the
     menu belongs to the last menu section above it (values -> about, etc.). */
  var navLinks = $$('.nav a'), pill = $('.nav__pill'), current;
  var menuIds = navLinks.map(function (a) { var h = a.getAttribute('href') || ''; var i = h.indexOf('#'); return i > -1 ? h.slice(i + 1) : ''; });
  var sections = $$('main > section[id], main section[id]').filter(function (s, i, arr) { return arr.indexOf(s) === i; });
  function placePill(a) {
    if (!pill) return;
    if (!a) { pill.style.opacity = '0'; return; }
    pill.style.opacity = '1';
    pill.style.transform = 'translateX(' + a.offsetLeft + 'px) scaleX(' + (a.offsetWidth / 100) + ')';
  }
  function updateNav() {
    if (!navLinks.length) return;
    var probe = innerHeight * 0.4, key = null;
    sections.forEach(function (s) {
      if (s.getBoundingClientRect().top <= probe) {
        var k = menuIds.indexOf(s.id);
        if (k > -1) key = s.id;
      }
    });
    if (key === current) return;
    current = key;
    var active = null;
    navLinks.forEach(function (a, i) {
      if (menuIds[i] === key && key) { a.setAttribute('aria-current', 'true'); active = a; } else a.removeAttribute('aria-current');
    });
    placePill(active);
  }

  /* ----------------------------------- signature: the berry's journey -- */
  var journey = (function () {
    var act = $('.journey');
    if (!act) return null;
    var rail = $('.rail', act), svg = $('.route', act);
    var track = $('.track', svg), drawn = $('.drawn', svg), berry = $('.berry', act);
    var stops = $$('.stop', act), stamps = [], W = 0, H = 0, len = 0, amp = 0, wave = 0, pathY0 = 0;
    var fruits = $$('img', berry), fruitIdx = 0;
    function yAt(x) { return H / 2 + amp * Math.sin(x / wave * Math.PI * 2); }
    function build() {
      // The route SVG and the stamps live inside the rail, so their old size
      // would inflate scrollWidth after a resize (wide -> narrow, or a phone
      // rotation) and the rail would travel past its content into empty
      // space. Collapse them before measuring.
      svg.style.width = '0px';
      stamps.forEach(function (s) { s.remove(); }); stamps = [];
      W = rail.scrollWidth; H = svg.getBoundingClientRect().height || 100;
      amp = H * 0.32; wave = Math.max(innerWidth * 0.55, 420);
      var d = 'M0 ' + yAt(0).toFixed(1);
      for (var x = 16; x <= W; x += 16) d += ' L' + x + ' ' + yAt(x).toFixed(1);
      svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H);
      svg.style.width = W + 'px';
      track.setAttribute('d', d); drawn.setAttribute('d', d);
      len = drawn.getTotalLength();
      drawn.style.strokeDasharray = len + ' ' + len;
      // SVG elements have no offsetTop; measure against the rail, which only
      // ever moves sideways.
      pathY0 = svg.getBoundingClientRect().top - rail.getBoundingClientRect().top;
      stamps.forEach(function (s) { s.remove(); }); stamps = [];
      stops.forEach(function (stop) {
        var cx = stop.offsetLeft + stop.offsetWidth / 2;
        var s = document.createElement('span');
        s.className = 'badge stamp'; s.setAttribute('aria-hidden', 'true');
        s.innerHTML = '<svg><use href="#scallop"/></svg><svg class="tick" viewBox="0 0 24 24" fill="none" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.2 4.2L19 7"/></svg>';
        s.style.left = cx + 'px'; s.style.top = (pathY0 + yAt(cx)) + 'px';
        s.__cx = cx;
        rail.appendChild(s); stamps.push(s);
      });
      if (reduce) { drawn.style.strokeDashoffset = '0'; stamps.forEach(function (s) { s.classList.add('is-on'); }); }
    }
    function berryX() { return innerWidth * (innerWidth < 760 ? 0.4 : 0.45); }
    function update() {
      if (!W || reduce) return;
      var y = scrollY, top = docTop(act), h = act.offsetHeight, vh = innerHeight;
      var p = Math.min(1, Math.max(0, (y - top) / Math.max(h - vh, 1)));
      var over = Math.max(W - innerWidth, 0);
      var bx = berryX(), xr = bx + over * p;
      var frac = Math.min(1, Math.max(0, xr / W));
      drawn.style.strokeDashoffset = (len * (1 - frac)).toFixed(1);
      var slope = (yAt(xr + 4) - yAt(xr - 4)) / 8;
      var bw = berry.offsetWidth, bh = berry.offsetHeight;
      berry.style.transform = 'translate3d(' + (bx - bw / 2).toFixed(1) + 'px,' + (pathY0 + yAt(xr) - bh * 0.92).toFixed(1) + 'px,0) rotate(' + (Math.atan(slope) * 57.3 * 0.6).toFixed(1) + 'deg)';
      var passed = 0;
      stamps.forEach(function (s) { var on = s.__cx <= xr + 2; s.classList.toggle('is-on', on); if (on) passed++; });
      // Each stop passed swaps the rider to the next Freeze Fresh fruit.
      var k = Math.min(passed, fruits.length - 1);
      if (fruits.length && k !== fruitIdx) { fruitIdx = k; fruits.forEach(function (f, i) { f.classList.toggle('is-on', i === k); }); }
    }
    return { build: build, update: update };
  })();

  /* ------------------------------------------- freeze dry: steps + gauge -- */
  var fd = (function () {
    var sec = $('.fd');
    if (!sec) return null;
    var steps = $$('.fd__steps li', sec), frames = $$('.fd__frames img', sec);
    var fill = $('.fd__fill', sec), value = $('.fd__value', sec), idx = -1, N = steps.length;
    var dry = (parseInt(sec.getAttribute('data-dry-step'), 10) || 4) - 1;
    var from = parseFloat(sec.getAttribute('data-water-from')) || 91;
    var to = parseFloat(sec.getAttribute('data-water-to')) || 3;
    var after = sec.getAttribute('data-pct') === 'after';   // "91%" (EN) vs "%91" (TR)
    function progress() { var h = sec.offsetHeight - innerHeight; return Math.min(1, Math.max(0, (scrollY - docTop(sec)) / Math.max(h, 1))); }
    function update() {
      if (!N) return;
      var t = progress() * N, i = Math.min(N - 1, Math.floor(t));
      if (i !== idx) {
        idx = i;
        steps.forEach(function (li, k) { li.classList.toggle('is-active', k === i); });
        frames.forEach(function (im, k) { im.classList.toggle('is-active', k === i); });
      }
      var d = Math.min(1, Math.max(0, t - dry));
      var water = from - (from - to) * d;
      fill.style.transform = 'scaleX(' + (water / 100).toFixed(3) + ')';
      value.textContent = after ? Math.round(water) + '%' : '%' + Math.round(water);
    }
    $$('.fd__steps button', sec).forEach(function (b) {
      b.addEventListener('click', function () {
        var k = +b.getAttribute('data-step'), h = sec.offsetHeight - innerHeight;
        scrollTo({ top: docTop(sec) + h * (k + 0.5) / N, behavior: reduce ? 'auto' : 'smooth' });
      });
    });
    return { update: update };
  })();

  /* -------------------------------------------------------- marquee -- */
  $$('.marquee').forEach(function (mq) {
    var lists = $$('ul', mq), btn = mq.parentNode.querySelector('.marquee-toggle');
    if (lists.length > 1) { lists[1].innerHTML = lists[0].innerHTML; $$('img', lists[1]).forEach(function (i) { i.alt = ''; }); }
    if (btn) btn.addEventListener('click', function () {
      var paused = mq.classList.toggle('is-paused');
      btn.setAttribute('aria-pressed', String(paused));
      btn.textContent = paused ? (T.play || '▶') : (T.pause || 'Ⅱ');
    });
  });

  /* ----------------------------------------------------- small things -- */
  $$('[data-soon]').forEach(function (a) { a.addEventListener('click', function (e) { e.preventDefault(); toast(T.soon || ''); }); });
  $$('.copy-mail').forEach(function (b) {
    b.addEventListener('click', function () {
      var mail = b.getAttribute('data-email');
      try { navigator.clipboard.writeText(mail).then(function () { toast(T.copied || mail); }, function () { toast(mail); }); } catch (e) { toast(mail); }
    });
  });

  /* ------------------------------------------------------- frost plates --
     A plate is a scrub clip's last frame (data-plate on its section), drawn
     exactly as the <video> shows it (object-fit: cover over the stage) with
     alternating mirrored copies below so it can drift without running out.
     It moves 1:1 while the clip's stage would slide off, then eases to a slow
     drift. The clip itself blurs out into this state and fades onto it. */
  function makePlate(zone, sec, anchor, copies, rate) {
    var bg = $('.frost__bg', zone), cv = bg && $('canvas', bg), stage = $('[data-sc-stage]', sec);
    if (!cv || !stage) return null;
    var img = null, src = '', H = innerHeight;
    var ends = [sec.getAttribute('data-plate'), sec.getAttribute('data-plate-mobile') || sec.getAttribute('data-plate')];
    function draw() {
      // Same rule the engine uses to pick the -m clip.
      var mobile = matchMedia('(hover: none) and (pointer: coarse)').matches || matchMedia('(max-width: 860px)').matches;
      var want = ends[mobile ? 1 : 0];
      if (!want) return;
      if (want !== src) { src = want; img = new Image(); img.onload = draw; img.src = want; return; }
      if (!img.complete || !img.naturalWidth) return;
      var W = innerWidth, dpr = 0.5;
      H = stage.clientHeight || innerHeight;
      cv.width = Math.round(W * dpr); cv.height = Math.round(H * copies * dpr);
      cv.style.height = H * copies + 'px'; cv.style.transformOrigin = '50% ' + H / 2 + 'px';
      var c = cv.getContext('2d'), iw = img.naturalWidth, ih = img.naturalHeight;
      var s = Math.max(W / iw, H / ih), dw = iw * s, dh = ih * s, dx = (W - dw) / 2, dy = (H - dh) / 2;
      for (var k = 0; k < copies; k++) {
        c.setTransform(dpr, 0, 0, k % 2 ? -dpr : dpr, 0, (k % 2 ? (k + 1) * H : k * H) * dpr);
        c.drawImage(img, dx, dy, dw, dh);
      }
    }
    function travel(s, vh) {
      if (s <= vh) return s;
      var u = s - vh, L = vh * 0.5;
      return vh + rate * u + (1 - rate) * L * (1 - Math.exp(-u / L));
    }
    addEventListener('resize', draw, { passive: true });
    draw();
    return { bg: bg, update: function (vh) {
      var r = zone.getBoundingClientRect();
      // Travel is measured from the first section after the clip; the plate is
      // only painted once the clip is about to hand over.
      var top = anchor ? anchor.getBoundingClientRect().top : r.bottom;
      bg.style.visibility = (r.bottom > 0 && top < vh * 1.25) ? 'visible' : 'hidden';
      var s = Math.max(0, vh - top), py = reduce ? Math.min(s, vh) : travel(s, vh);
      bg.style.setProperty('--py', (-Math.min(py, H * (copies - 1))).toFixed(1) + 'px');
    } };
  }
  function nextSection(sec) { var n = sec && sec.nextElementSibling; while (n && n.tagName !== 'SECTION') n = n.nextElementSibling; return n; }
  var early = zEarly && makePlate(zEarly, heroSec, nextSection(heroSec), 4, 0.2);
  var late = zLate && makePlate(zLate, sustSec, nextSection(sustSec), 6, 0.12);
  var heroStage = heroSec && $('[data-sc-stage]', heroSec), sustStage = sustSec && $('[data-sc-stage]', sustSec);
  var fieldBg = zField && $('.field-intro__bg', zField);
  function scP(sec) { return parseFloat(sec.style.getPropertyValue('--sc-p')) || 0; }

  function updateFrost() {
    var vh = innerHeight;
    if (early) {
      early.update(vh);
      // Fully blurred, the hero hands over to the plate beneath and fades out.
      heroStage.style.opacity = (1 - clamp01((scP(heroSec) - 0.97) / 0.03)).toFixed(3);
      // Wash: bone behind the figures, warming to peach behind the values.
      var w = valSec ? clamp01((vh - valSec.getBoundingClientRect().top) / vh) : 0;
      early.bg.style.setProperty('--bone-a', (0.42 * (1 - w)).toFixed(3));
      early.bg.style.setProperty('--peach-a', (0.5 * w).toFixed(3));
    }
    if (fieldSec) {
      // Hand-off to the field: the early plate turns into the blurred field in
      // the last stretch of the values pin; the last value re-inks to light.
      var ft = fieldSec.getBoundingClientRect().top;
      var na = clamp01((1.2 * vh - ft) / (0.2 * vh)).toFixed(3);
      if (early) early.bg.style.setProperty('--next-a', na);
      if (valSec) valSec.style.setProperty('--na', na);
      if (fieldBg) {
        var z = zField.getBoundingClientRect(), jt = journeySec && zField.contains(journeySec) ? journeySec.getBoundingClientRect() : null;
        fieldBg.style.visibility = (z.top < vh && z.bottom > 0) ? 'visible' : 'hidden';
        fieldBg.style.setProperty('--fb', Math.max(clamp01(ft / (0.35 * vh)), jt ? clamp01((0.9 * vh - jt.top) / (0.5 * vh)) : 0).toFixed(3));
        if (jt && !reduce) fieldBg.style.setProperty('--jx', clamp01(-jt.top / Math.max(jt.height - vh, 1)).toFixed(4));
      }
    }
    if (sustStage) {
      // In blurred under forest, sharp for the pin, out blurred under bone
      // (= the late plate under Freeze Dry's pane), then fade onto it.
      var d = -sustSec.getBoundingClientRect().top, sp = scP(sustSec);
      var kin = d <= 0 ? 1 : clamp01(1 - d / (0.35 * vh)), ko = clamp01((sp - 0.8) / 0.2);
      sustStage.style.setProperty('--k', Math.max(kin, ko).toFixed(3));
      sustStage.style.setProperty('--ko', ko.toFixed(3));
      sustStage.style.setProperty('--wash', ko > 0 ? '251 246 240' : '30 58 39');
      sustStage.style.setProperty('--wa', (ko > 0 ? 0.55 * ko : 0.78 * kin).toFixed(3));
      if (late) { late.update(vh); sustStage.style.opacity = (1 - clamp01((sp - 0.97) / 0.03)).toFixed(3); }
    }
  }

  /* ------------------------------------------------------------ wiring -- */
  var ticking = false;
  function frame() { updateNav(); if (fd) fd.update(); if (journey) journey.update(); updateFrost(); ticking = false; }
  addEventListener('scroll', function () { if (!ticking) { ticking = true; requestAnimationFrame(frame); } }, { passive: true });
  function relayout() { if (journey) journey.build(); current = undefined; frame(); }
  addEventListener('resize', relayout, { passive: true });
  (document.fonts ? document.fonts.ready : Promise.resolve()).then(relayout);
  addEventListener('load', relayout);
  relayout();
})();

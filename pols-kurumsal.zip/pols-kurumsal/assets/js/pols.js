/* Pol's Kurumsal: page behaviour on top of the scroll-craft engine.
   Every feature looks for its own block and quietly skips when a page does not
   use it, so blocks can be reordered or removed in the editor. */
(function () {
  'use strict';
  if (!window.ScrollCraft) return;
  ScrollCraft.mount(document.body);

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
  var T = window.POLS || {};

  var main = $('main');
  if (main && !main.id) main.id = 'main';

  var toastT;
  function toast(msg) { var t = $('#toast'); if (!t) return; t.textContent = msg; t.hidden = false; clearTimeout(toastT); toastT = setTimeout(function () { t.hidden = true; }, 2600); }

  /* ---------------------------------------------------- drawer, trapped -- */
  var drawer = $('#drawer'), openBtn = $('#menu-open'), lastFocus = null;
  if (drawer && openBtn) {
    var closeBtn = $('#menu-close');
    var focusables = function () { return $$('a, button', drawer); };
    var openDrawer = function () { lastFocus = document.activeElement; drawer.hidden = false; openBtn.setAttribute('aria-expanded', 'true'); document.body.style.overflow = 'hidden'; closeBtn.focus(); };
    var closeDrawer = function (restore) { drawer.hidden = true; openBtn.setAttribute('aria-expanded', 'false'); document.body.style.overflow = ''; if (restore && lastFocus) lastFocus.focus(); };
    openBtn.addEventListener('click', openDrawer);
    closeBtn.addEventListener('click', function () { closeDrawer(true); });
    $$('nav a', drawer).forEach(function (a) { a.addEventListener('click', function () { closeDrawer(false); }); });
    drawer.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { closeDrawer(true); return; }
      if (e.key !== 'Tab') return;
      var f = focusables(), first = f[0], last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    });
  }

  /* --------------------------------------------- nav: active section pill --
     Walk the sections in reading order; a section that is not itself in the
     menu belongs to the last menu section above it (values -> about, etc.). */
  var navLinks = $$('.nav a'), pill = $('.nav__pill'), current;
  var menuIds = navLinks.map(function (a) { var h = a.getAttribute('href') || ''; var i = h.indexOf('#'); return i > -1 ? h.slice(i + 1) : ''; });
  var sections = $$('main > section[id], main section[id]').filter(function (s, i, arr) { return arr.indexOf(s) === i; });
  function placePill(a) {
    if (!pill) return;
    if (!a) { pill.style.opacity = '0'; return; }
    pill.style.opacity = '1';
    pill.style.transform = 'translateX(' + a.offsetLeft + 'px) scaleX(' + (a.offsetWidth / 100) + ')';
  }
  function updateNav() {
    if (!navLinks.length) return;
    var probe = innerHeight * 0.4, key = null;
    sections.forEach(function (s) {
      if (s.getBoundingClientRect().top <= probe) {
        var k = menuIds.indexOf(s.id);
        if (k > -1) key = s.id;
      }
    });
    if (key === current) return;
    current = key;
    var active = null;
    navLinks.forEach(function (a, i) {
      if (menuIds[i] === key && key) { a.setAttribute('aria-current', 'true'); active = a; } else a.removeAttribute('aria-current');
    });
    placePill(active);
  }

  /* ----------------------------------- signature: the berry's journey -- */
  var journey = (function () {
    var act = $('.journey');
    if (!act) return null;
    var rail = $('.rail', act), svg = $('.route', act);
    var track = $('.track', svg), drawn = $('.drawn', svg), berry = $('.berry', act);
    var stops = $$('.stop', act), stamps = [], W = 0, H = 0, len = 0, amp = 0, wave = 0, pathY0 = 0;
    function yAt(x) { return H / 2 + amp * Math.sin(x / wave * Math.PI * 2); }
    function build() {
      W = rail.scrollWidth; H = svg.getBoundingClientRect().height || 100;
      amp = H * 0.32; wave = Math.max(innerWidth * 0.55, 420);
      var d = 'M0 ' + yAt(0).toFixed(1);
      for (var x = 16; x <= W; x += 16) d += ' L' + x + ' ' + yAt(x).toFixed(1);
      svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H);
      svg.style.width = W + 'px';
      track.setAttribute('d', d); drawn.setAttribute('d', d);
      len = drawn.getTotalLength();
      drawn.style.strokeDasharray = len + ' ' + len;
      // SVG elements have no offsetTop; measure against the rail, which only
      // ever moves sideways.
      pathY0 = svg.getBoundingClientRect().top - rail.getBoundingClientRect().top;
      stamps.forEach(function (s) { s.remove(); }); stamps = [];
      stops.forEach(function (stop) {
        var cx = stop.offsetLeft + stop.offsetWidth / 2;
        var s = document.createElement('span');
        s.className = 'badge stamp'; s.setAttribute('aria-hidden', 'true');
        s.innerHTML = '<svg><use href="#scallop"/></svg><svg class="tick" viewBox="0 0 24 24" fill="none" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.2 4.2L19 7"/></svg>';
        s.style.left = cx + 'px'; s.style.top = (pathY0 + yAt(cx)) + 'px';
        s.__cx = cx;
        rail.appendChild(s); stamps.push(s);
      });
      if (reduce) { drawn.style.strokeDashoffset = '0'; stamps.forEach(function (s) { s.classList.add('is-on'); }); }
    }
    function berryX() { return innerWidth * (innerWidth < 760 ? 0.4 : 0.45); }
    function update() {
      if (!W || reduce) return;
      var y = scrollY, top = act.offsetTop, h = act.offsetHeight, vh = innerHeight;
      var p = Math.min(1, Math.max(0, (y - top) / Math.max(h - vh, 1)));
      var over = Math.max(W - innerWidth, 0);
      var bx = berryX(), xr = bx + over * p;
      var frac = Math.min(1, Math.max(0, xr / W));
      drawn.style.strokeDashoffset = (len * (1 - frac)).toFixed(1);
      var slope = (yAt(xr + 4) - yAt(xr - 4)) / 8;
      var bw = berry.offsetWidth, bh = berry.offsetHeight;
      berry.style.transform = 'translate3d(' + (bx - bw / 2).toFixed(1) + 'px,' + (pathY0 + yAt(xr) - bh * 0.92).toFixed(1) + 'px,0) rotate(' + (Math.atan(slope) * 57.3 * 0.6).toFixed(1) + 'deg)';
      stamps.forEach(function (s) { s.classList.toggle('is-on', s.__cx <= xr + 2); });
      act.classList.toggle('is-landed', !!stamps.length && stamps[stamps.length - 1].__cx <= xr + 2 && p > 0.9);
    }
    return { build: build, update: update };
  })();

  /* ------------------------------------------- freeze dry: steps + gauge -- */
  var fd = (function () {
    var sec = $('.fd');
    if (!sec) return null;
    var steps = $$('.fd__steps li', sec), frames = $$('.fd__frames img', sec);
    var fill = $('.fd__fill', sec), value = $('.fd__value', sec), idx = -1, N = steps.length;
    var dry = (parseInt(sec.getAttribute('data-dry-step'), 10) || 4) - 1;
    var from = parseFloat(sec.getAttribute('data-water-from')) || 91;
    var to = parseFloat(sec.getAttribute('data-water-to')) || 3;
    var after = sec.getAttribute('data-pct') === 'after';   // "91%" (EN) vs "%91" (TR)
    function progress() { var h = sec.offsetHeight - innerHeight; return Math.min(1, Math.max(0, (scrollY - sec.offsetTop) / Math.max(h, 1))); }
    function update() {
      if (!N) return;
      var t = progress() * N, i = Math.min(N - 1, Math.floor(t));
      if (i !== idx) {
        idx = i;
        steps.forEach(function (li, k) { li.classList.toggle('is-active', k === i); });
        frames.forEach(function (im, k) { im.classList.toggle('is-active', k === i); });
      }
      var d = Math.min(1, Math.max(0, t - dry));
      var water = from - (from - to) * d;
      fill.style.transform = 'scaleX(' + (water / 100).toFixed(3) + ')';
      value.textContent = after ? Math.round(water) + '%' : '%' + Math.round(water);
    }
    $$('.fd__steps button', sec).forEach(function (b) {
      b.addEventListener('click', function () {
        var k = +b.getAttribute('data-step'), h = sec.offsetHeight - innerHeight;
        scrollTo({ top: sec.offsetTop + h * (k + 0.5) / N, behavior: reduce ? 'auto' : 'smooth' });
      });
    });
    return { update: update };
  })();

  /* -------------------------------------------------------- marquee -- */
  $$('.marquee').forEach(function (mq) {
    var lists = $$('ul', mq), btn = mq.parentNode.querySelector('.marquee-toggle');
    if (lists.length > 1) { lists[1].innerHTML = lists[0].innerHTML; $$('img', lists[1]).forEach(function (i) { i.alt = ''; }); }
    if (btn) btn.addEventListener('click', function () {
      var paused = mq.classList.toggle('is-paused');
      btn.setAttribute('aria-pressed', String(paused));
      btn.textContent = paused ? (T.play || '▶') : (T.pause || 'Ⅱ');
    });
  });

  /* ----------------------------------------------------- small things -- */
  $$('[data-soon]').forEach(function (a) { a.addEventListener('click', function (e) { e.preventDefault(); toast(T.soon || ''); }); });
  $$('.copy-mail').forEach(function (b) {
    b.addEventListener('click', function () {
      var mail = b.getAttribute('data-email');
      try { navigator.clipboard.writeText(mail).then(function () { toast(T.copied || mail); }, function () { toast(mail); }); } catch (e) { toast(mail); }
    });
  });

  /* ------------------------------------------------------------ wiring -- */
  var ticking = false;
  function frame() { updateNav(); if (fd) fd.update(); if (journey) journey.update(); ticking = false; }
  addEventListener('scroll', function () { if (!ticking) { ticking = true; requestAnimationFrame(frame); } }, { passive: true });
  function relayout() { if (journey) journey.build(); current = undefined; frame(); }
  addEventListener('resize', relayout, { passive: true });
  (document.fonts ? document.fonts.ready : Promise.resolve()).then(relayout);
  addEventListener('load', relayout);
  relayout();
})();

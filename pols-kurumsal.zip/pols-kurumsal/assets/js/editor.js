/* Pol's Kurumsal: one generic editor for every section block.
   Fields come from inc/schema.php (localised as POLS_BLOCKS); the canvas shows
   the real server render. No build step: plain wp.* globals. */
(function (wp) {
  'use strict';
  var el = wp.element.createElement, Fragment = wp.element.Fragment;
  var be = wp.blockEditor, C = wp.components;
  var SSR = wp.serverSideRender;
  var useSelect = wp.data.useSelect;
  var CFG = window.POLS_BLOCKS || { blocks: {}, seedUrl: '' };

  /* --------------------------------------------------------- media field -- */
  function MediaField(props) {
    var id = props.id || 0, file = props.file || '', kind = props.kind || 'image';
    var media = useSelect(function (select) { return id ? select('core').getMedia(id) : null; }, [id]);
    var url = media ? media.source_url : (file ? CFG.seedUrl + file : '');
    var name = media ? (media.title && media.title.rendered) || media.source_url.split('/').pop() : (file ? file + ' (tema dosyası)' : 'Seçilmedi');
    var preview = kind === 'image' && url
      ? el('img', { src: url, alt: '', style: { width: '100%', borderRadius: 6, marginBottom: 6, display: 'block' } })
      : el('p', { style: { fontSize: 12, margin: '0 0 6px', wordBreak: 'break-all' } }, '🎞 ' + name);
    return el('div', { className: 'pols-media-field', style: { marginBottom: 16 } },
      el('p', { style: { fontWeight: 600, margin: '0 0 6px' } }, props.label),
      preview,
      el(be.MediaUploadCheck, null,
        el(be.MediaUpload, {
          allowedTypes: [kind], value: id,
          onSelect: function (m) { props.onChange(m.id); },
          render: function (o) { return el(C.Button, { variant: 'secondary', onClick: o.open }, id ? 'Değiştir' : 'Medya seç'); }
        })
      ),
      id ? el(C.Button, { variant: 'link', isDestructive: true, style: { marginLeft: 8 }, onClick: function () { props.onChange(0); } }, 'Varsayılana dön') : null
    );
  }

  /* --------------------------------------------------------- one field -- */
  function Field(f, obj, set) {
    var v = obj[f.key];
    switch (f.type) {
      case 'textarea':
        return el(C.TextareaControl, { key: f.key, label: f.label, value: v || '', rows: 4, onChange: function (x) { set(f.key, x); } });
      case 'url':
        return el(C.TextControl, { key: f.key, label: f.label, type: 'url', value: v || '', onChange: function (x) { set(f.key, x); } });
      case 'select':
        return el(C.SelectControl, { key: f.key, label: f.label, value: v, options: f.options, onChange: function (x) { set(f.key, x); } });
      case 'toggle':
        return el(C.ToggleControl, { key: f.key, label: f.label, checked: !!v, onChange: function (x) { set(f.key, x); } });
      case 'media':
        return el(MediaField, { key: f.key, label: f.label, kind: f.media, id: v, file: obj[f.key + 'File'], onChange: function (x) { set(f.key, x); } });
      case 'repeater':
        return el(Repeater, { key: f.key, field: f, value: v || [], onChange: function (x) { set(f.key, x); } });
      default:
        return el(C.TextControl, { key: f.key, label: f.label, value: v || '', onChange: function (x) { set(f.key, x); } });
    }
  }

  /* ------------------------------------------------------------ repeater -- */
  function Repeater(props) {
    var f = props.field, items = props.value;
    function update(i, key, val) { var next = items.map(function (it, k) { if (k !== i) return it; var c = Object.assign({}, it); c[key] = val; return c; }); props.onChange(next); }
    function move(i, d) { var j = i + d; if (j < 0 || j >= items.length) return; var next = items.slice(); var t = next[i]; next[i] = next[j]; next[j] = t; props.onChange(next); }
    function remove(i) { props.onChange(items.filter(function (_, k) { return k !== i; })); }
    function add() {
      var tpl = items.length ? Object.assign({}, items[items.length - 1]) : {};
      f.fields.forEach(function (sf) { if (sf.type === 'media') { tpl[sf.key] = 0; tpl[sf.key + 'File'] = ''; } else if (sf.type !== 'select') { tpl[sf.key] = ''; } });
      props.onChange(items.concat([tpl]));
    }
    return el('div', { className: 'pols-repeater', style: { marginBottom: 16 } },
      el('p', { style: { fontWeight: 600, margin: '0 0 8px' } }, f.label + ' (' + items.length + ')'),
      items.map(function (it, i) {
        var title = (i + 1) + '. ' + ((it[f.itemLabel] || '').toString().slice(0, 40) || '—');
        return el(C.PanelBody, { key: i, title: title, initialOpen: false },
          f.fields.map(function (sf) { return Field(sf, it, function (k, val) { update(i, k, val); }); }),
          el('div', { style: { display: 'flex', gap: 6, marginTop: 4 } },
            el(C.Button, { size: 'small', variant: 'secondary', disabled: i === 0, onClick: function () { move(i, -1); } }, '↑'),
            el(C.Button, { size: 'small', variant: 'secondary', disabled: i === items.length - 1, onClick: function () { move(i, 1); } }, '↓'),
            el(C.Button, { size: 'small', isDestructive: true, variant: 'secondary', onClick: function () { remove(i); } }, 'Sil')
          )
        );
      }),
      el(C.Button, { variant: 'primary', size: 'small', style: { marginTop: 8 }, onClick: add }, '+ Ekle')
    );
  }

  /* ------------------------------------------------------------ blocks -- */
  Object.keys(CFG.blocks).forEach(function (name) {
    var def = CFG.blocks[name];
    wp.blocks.registerBlockType(name, {
      apiVersion: 3,
      title: def.title,
      icon: def.icon,
      category: 'pols',
      edit: function (props) {
        var blockProps = be.useBlockProps({ className: 'pols-editor-block' });
        var set = function (k, v) { var o = {}; o[k] = v; props.setAttributes(o); };
        var simple = def.fields.filter(function (f) { return f.type !== 'repeater'; });
        var lists = def.fields.filter(function (f) { return f.type === 'repeater'; });
        var inspector = def.fields.length ? el(be.InspectorControls, null,
          simple.length ? el(C.PanelBody, { title: 'İçerik', initialOpen: true }, simple.map(function (f) { return Field(f, props.attributes, set); })) : null,
          lists.map(function (f) { return el(C.PanelBody, { key: f.key, title: f.label, initialOpen: false }, Field(f, props.attributes, set)); }),
          el(C.PanelBody, { title: 'Bağlantı adı', initialOpen: false },
            el(C.TextControl, { label: 'Bölüm kimliği (menüdeki #bağlantı)', help: 'Menüde bu bölüme giden bağlantı "#' + (props.attributes.anchor || '') + '" olmalı.', value: props.attributes.anchor || '', onChange: function (x) { set('anchor', x.replace(/[^a-z0-9-_]/gi, '').toLowerCase()); } })
          )
        ) : null;
        var preview = name === 'pols/header'
          ? el('div', { className: 'pols-header-note' }, "Pol's üst menü · bağlantılar: Görünüm → Menüler → \"Ana menü\"")
          : el(SSR, { block: name, attributes: props.attributes, httpMethod: 'POST' });
        return el(Fragment, null, inspector, el('div', blockProps, preview));
      },
      save: function () { return null; }
    });
  });
})(window.wp);
